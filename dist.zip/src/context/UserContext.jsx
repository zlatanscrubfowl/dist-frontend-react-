import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { apiFetch } from '../utils/api';
const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUserData = async (userId) => {
    try {
      const response = await apiFetch(`/user-total-observations/${userId}`);
      return response.data.userTotalObservations; // Sesuaikan dengan response dari backend
    } catch (error) {
      console.error('Error fetching user data:', error);
      return 0;
    }
  };

  const checkAuth = async () => {
    const token = localStorage.getItem('jwt_token');
    if (!token) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      // Get user profile
      const response = await apiFetch('/user', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.data) {
        // Fetch total observations
        const totalObservations = await fetchUserData(response.data.id);
        
        setUser({
          ...response.data, // Simpan semua data user
          totalObservations: totalObservations
        });
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.clear();
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Fungsi untuk memperbarui total observasi
  const updateTotalObservations = async () => {
    if (user?.id) {
      const total = await fetchUserData(user.id);
      setUser(prev => ({
        ...prev,
        totalObservations: total
      }));
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const logout = async () => {
    try {
      await apiFetch('/logout', {
        method: 'POST'
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.clear();
      setUser(null);
    }
  };

  return (
    <UserContext.Provider value={{ 
      user, 
      setUser, 
      logout, 
      isLoading, 
      checkAuth,
      updateTotalObservations 
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);