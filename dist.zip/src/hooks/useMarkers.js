import { useState, useCallback, useEffect } from 'react';
import { apiFetch } from '../utils/api';

export const useMarkers = () => {
  const [mapMarkers, setMapMarkers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch markers dari API
  useEffect(() => {
    const fetchMarkers = async () => {
      try {
        // Fetch dari kedua endpoint dan gabungkan hasilnya
        const [markersResponse, fobiMarkersResponse] = await Promise.all([
          apiFetch('/markers'),
          apiFetch('/fobi-markers')
        ]);

        const markersData = await markersResponse.json();
        const fobiMarkersData = await fobiMarkersResponse.json();

        // Gabungkan data dari kedua sumber
        const combinedMarkers = [
          ...markersData.map(marker => ({
            ...marker,
            source: marker.source || 'burungnesia' // default source jika tidak ada
          })),
          ...fobiMarkersData.map(marker => ({
            ...marker,
            source: 'fobi'
          }))
        ];

        setMapMarkers(combinedMarkers);
      } catch (error) {
        console.error('Error fetching markers:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMarkers();
  }, []);

  const filterMarkers = useCallback((markers, filterParams, searchParams) => {
    if (!markers || markers.length === 0) return [];

    return markers.filter(marker => {
      // Filter berdasarkan sumber data
      if (filterParams?.data_source?.length > 0) {
        const sourceMatch = filterParams.data_source.some(source => {
          if (source === 'burungnesia') {
            return marker.source === 'burungnesia';
          }
          if (source === 'kupunesia') {
            return marker.source === 'kupunesia';
          }
          if (source === 'fobi') {
            return marker.source === 'fobi';
          }
          return false;
        });
        if (!sourceMatch) return false;
      }

      // Filter berdasarkan lokasi jika ada parameter pencarian
      if (searchParams?.latitude && searchParams?.longitude && filterParams?.radius) {
        const distance = calculateDistance(
          searchParams.latitude,
          searchParams.longitude,
          marker.latitude,
          marker.longitude
        );
        if (distance > filterParams.radius) return false;
      }

      return true;
    });
  }, []);

  // Fungsi helper untuk menghitung jarak
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Radius bumi dalam kilometer
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const toRad = (value) => {
    return value * Math.PI / 180;
  };

  return {
    mapMarkers,
    loading,
    filterMarkers
  };
}; 