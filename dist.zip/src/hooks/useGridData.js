import { useState, useCallback, useEffect, useMemo } from 'react';
import { generateGrid, GRID_SIZES } from '../utils/gridHelpers';
import { throttle } from 'lodash';

export const useGridData = () => {
  const [gridData, setGridData] = useState({
    tiles: [],
    markers: [],
    currentZoom: 0,
    visibleBounds: null
  });
  const [loading, setLoading] = useState(false);

  // Throttle grid generation untuk setiap ukuran grid
  const throttledGenerateGrid = useMemo(() => ({
    small: throttle((markers) => generateGrid(markers, GRID_SIZES.small), 300),
    medium: throttle((markers) => generateGrid(markers, GRID_SIZES.medium), 300),
    large: throttle((markers) => generateGrid(markers, GRID_SIZES.large), 300),
    extraLarge: throttle((markers) => generateGrid(markers, GRID_SIZES.extraLarge), 300)
  }), []);

  // Update grid data dengan sistem tile-based
  const updateGridData = useCallback(async (markers, zoom, bounds) => {
    if (!markers?.length) return;
    
    setLoading(true);

    try {
      // Format markers sekali saja
      const formattedMarkers = markers.map(marker => ({
        id: marker.id || marker.checklist_id,
        checklist_id: marker.checklist_id || marker.id,
        latitude: parseFloat(marker.latitude),
        longitude: parseFloat(marker.longitude),
        source: marker.source,
        created_at: marker.created_at
      }));

      // Tentukan ukuran grid berdasarkan zoom level
      let gridSize;
      if (zoom >= 12) {
        gridSize = 'small';
      } else if (zoom >= 9) {
        gridSize = 'medium';
      } else if (zoom >= 6) {
        gridSize = 'large';
      } else {
        gridSize = 'extraLarge';
      }

      // Generate grid untuk zoom level saat ini
      const tiles = await throttledGenerateGrid[gridSize](formattedMarkers);

      setGridData(prev => ({
        ...prev,
        tiles,
        markers: formattedMarkers,
        currentZoom: zoom,
        visibleBounds: bounds
      }));

    } catch (error) {
      console.error('Error generating grid:', error);
    } finally {
      setLoading(false);
    }
  }, [throttledGenerateGrid]);

  return {
    gridData,
    loading,
    updateGridData
  };
}; 