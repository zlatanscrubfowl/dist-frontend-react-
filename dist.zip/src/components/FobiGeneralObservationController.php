<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Traits\TaxaQualityAssessmentTrait;
use App\Models\TaxaQualityAssessment;
use App\Models\FobiChecklistTaxa;
use Intervention\Image\ImageManagerStatic as Image;

class FobiGeneralObservationController extends Controller
{
    use TaxaQualityAssessmentTrait;

    private function getLocationName($latitude, $longitude)
    {
        try {
            if (!$latitude || !$longitude) {
                return 'Unknown Location';
            }

            $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat={$latitude}&lon={$longitude}&zoom=18&addressdetails=1";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'FOBi Application'); // Penting: tambahkan User-Agent

            $response = curl_exec($ch);
            $data = json_decode($response, true);

            if (isset($data['display_name'])) {
                return $data['display_name'];
            }

            return 'Unknown Location';

        } catch (\Exception $e) {
            Log::error('Error getting location name:', [
                'error' => $e->getMessage(),
                'latitude' => $latitude,
                'longitude' => $longitude
            ]);
            return 'Unknown Location';
        }
    }

    public function generateSpectrogram(Request $request)
    {
        try {
            $request->validate([
                'media' => 'required|file|mimes:mp3,wav,ogg|max:15120',
            ]);

            $soundFile = $request->file('media');
            $soundPath = $soundFile->store('sounds', 'public');
            $spectrogramPath = preg_replace('/\.(mpwav|ogg)$/i', '.png', $soundPath);

            $command = escapeshellcmd("python " . base_path('storage/app/public/spectrogram.py') . " " .
                storage_path('app/public/' . $soundPath) . " " .
                storage_path('app/public/' . $spectrogramPath));

            $output = shell_exec($command);
            Log::info('Spectrogram command output: ' . $output);

            if (!Storage::disk('public')->exists($spectrogramPath)) {
                throw new \Exception('Gagal membuat spectrogram');
            }

            return response()->json([
                'success' => true,
                'message' => 'Spectrogram berhasil dibuat',
                'spectrogramUrl' => asset('storage/' . $spectrogramPath),
                'audioUrl' => asset('storage/' . $soundPath)
            ]);

        } catch (\Exception $e) {
            Log::error('Error generating spectrogram: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat membuat spectrogram',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    private function processAudioFile($file)
    {
        try {
            $path = $file->store('sounds', 'public');
            $spectrogramPath = preg_replace('/\.(mp3|wav|ogg)$/i', '.png', $path);

            $command = escapeshellcmd("python " . base_path('storage/app/public/spectrogram.py') . " " .
                storage_path('app/public/' . $path) . " " .
                storage_path('app/public/' . $spectrogramPath));

            shell_exec($command);

            return [
                'audioPath' => $path,
                'spectrogramPath' => $spectrogramPath,
                'success' => true
            ];

        } catch (\Exception $e) {
            Log::error('Error processing audio file: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    private function processImageFile($file)
    {
        try {
            $uploadPath = storage_path('app/public/observations');
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }

            $image = Image::make($file->getRealPath());

            $image->resize(1200, 1200, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            });

            $fileName = uniqid('img_') . '.jpg';
            $relativePath = 'observations/' . $fileName;
            $fullPath = storage_path('app/public/' . $relativePath);

            $image->save($fullPath, 80);

            return [
                'imagePath' => $relativePath,
                'success' => true
            ];

        } catch (\Exception $e) {
            Log::error('Error processing image file: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    public function store(Request $request)
    {
        try {
            DB::beginTransaction();

            // Get location name from coordinates
            $location = $this->getLocationName(
                $request->input('latitude'),
                $request->input('longitude')
            );

            // Proses taxa dan dapatkan checklist ID
            $taxaId = $this->processTaxa($request);

            // Proses semua media yang diunggah
            if ($request->hasFile('media')) {
                $mediaFiles = is_array($request->file('media')) ? $request->file('media') : [$request->file('media')];

                foreach ($mediaFiles as $mediaFile) {
                    try {
                        $mediaType = strpos($mediaFile->getMimeType(), 'image') !== false ? 'photo' : 'audio';
                        $path = null;
                        $spectrogramPath = null;

                        if ($mediaType === 'photo') {
                            $result = $this->processImageFile($mediaFile);
                            if ($result['success']) {
                                $path = $result['imagePath'];
                            }
                        } else {
                            $result = $this->processAudioFile($mediaFile);
                            if ($result['success']) {
                                $path = $result['audioPath'];
                                $spectrogramPath = $result['spectrogramPath'];
                            }
                        }

                        $mediaData = [
                            'checklist_id' => $taxaId,
                            'media_type' => $mediaType,
                            'file_path' => $path,
                            'spectrogram' => $spectrogramPath,
                            'scientific_name' => $request->scientific_name,
                            'location' => $location,
                            'habitat' => $request->habitat ?? 'Unknown Habitat',
                            'description' => $request->description ?? '',
                            'date' => $request->tgl_pengamatan ?? now(),
                            'created_at' => now(),
                            'updated_at' => now()
                        ];

                        DB::table('fobi_checklist_media')->insert($mediaData);

                    } catch (\Exception $e) {
                        Log::error('Error processing media:', [
                            'error' => $e->getMessage(),
                            'trace' => $e->getTraceAsString()
                        ]);
                        throw $e;
                    }
                }
            }

            DB::commit();
                        // Buat objek taxa untuk assessment
                        $taxaData = (object)[
                            'id' => $taxaId,
                            'created_at' => $request->tgl_pengamatan ?? now(),
                            'location' => $location,
                            'media' => $request->hasFile('media'),
                            'scientific_name' => $request->scientific_name
                        ];

                        // Lakukan assessment
                        $qualityAssessment = $this->assessTaxaQuality($taxaData);

                        // Simpan hasil assessment
                        TaxaQualityAssessment::create([
                            'taxa_id' => $taxaId,
                            'grade' => $qualityAssessment['grade'],
                            'has_date' => $qualityAssessment['has_date'],
                            'has_location' => $qualityAssessment['has_location'],
                            'has_media' => $qualityAssessment['has_media'],
                            'is_wild' => $qualityAssessment['is_wild'],
                            'location_accurate' => $qualityAssessment['location_accurate'],
                            'recent_evidence' => $qualityAssessment['recent_evidence'],
                            'related_evidence' => $qualityAssessment['related_evidence'],
                            'needs_id' => $qualityAssessment['needs_id'],
                            'community_id_level' => $qualityAssessment['community_id_level']
                        ]);



            return response()->json([
                'success' => true,
                'message' => 'Data berhasil disimpan',
                'checklist_id' => $taxaId,
                'quality_assessment' => $qualityAssessment

            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error saving data: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menyimpan data',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    private function processTaxa($request)
    {
        try {
            // Dapatkan user yang sedang login
            $user = JWTAuth::parseToken()->authenticate();

            // Dapatkan taxa_id
            $taxaId = $this->getOrCreateMainTaxa($request);

            // Generate session ID berdasarkan kombinasi taxa_id, koordinat, dan user_id
            $uploadId = "obs_{$user->id}_{$taxaId}_{$request->latitude}_{$request->longitude}";

            // Cek apakah sudah ada checklist dengan kombinasi yang sama
            $existingChecklist = DB::table('fobi_checklist_taxas')
                ->where('taxa_id', $taxaId)
                ->where('user_id', $user->id)
                ->where('latitude', $request->latitude)
                ->where('longitude', $request->longitude)
                ->first();

            if ($existingChecklist) {
                return $existingChecklist->id;
            }

            // Jika belum ada, buat checklist baru
            $checklistId = DB::table('fobi_checklist_taxas')->insertGetId([
                'taxa_id' => $taxaId,
                'user_id' => $user->id,
                'media_id' => null,
                'scientific_name' => $request->scientific_name,
                'class' => $request->class ?? null,
                'order' => $request->order ?? null,
                'family' => $request->family ?? null,
                'genus' => $request->genus ?? null,
                'species' => $request->species ?? null,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'observation_details' => $request->additional_note,
                'upload_session_id' => $uploadId,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            return $checklistId;

        } catch (\Exception $e) {
            Log::error('Error processing taxa: ' . $e->getMessage());
            throw $e;
        }
    }
    // Fungsi helper untuk mendapatkan atau membuat taxa di tabel utama
    private function getOrCreateMainTaxa($request)
    {
        $existingTaxa = DB::table('taxas')
            ->where('scientific_name', $request->scientific_name)
            ->first();

        if ($existingTaxa) {
            return $existingTaxa->id;
        }

        return DB::table('taxas')->insertGetId([
            'scientific_name' => $request->scientific_name,
            'taxon_rank' => $request->taxon_rank,
            'kingdom' => $request->kingdom,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }

    private function getTaxonomyInfo($scientificName)
    {
        try {
            // Menggunakan GBIF API untuk mendapatkan informasi taksonomi
            $response = Http::get('https://api.gbif.org/v1/species/match', [
                'name' => $scientificName,
                'strict' => false
            ]);

            if ($response->successful()) {
                $data = $response->json();

                return [
                    'success' => true,
                    'data' => [
                        'scientific_name' => $data['scientificName'] ?? $scientificName,
                        'taxon_rank' => strtolower($data['rank'] ?? ''),
                        'kingdom' => $data['kingdom'] ?? '',
                        'phylum' => $data['phylum'] ?? '',
                        'class' => $data['class'] ?? '',
                        'order' => $data['order'] ?? '',
                        'family' => $data['family'] ?? '',
                        'genus' => $data['genus'] ?? '',
                        'species' => $data['species'] ?? ''
                    ]
                ];
            }

            return [
                'success' => false,
                'message' => 'Tidak dapat menemukan informasi taksonomi'
            ];

        } catch (\Exception $e) {
            Log::error('Error getting taxonomy info: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil informasi taksonomi'
            ];
        }
    }

    // Tambahkan endpoint baru untuk mendapatkan informasi taksonomi
    public function getTaxonomy(Request $request)
    {
        $request->validate([
            'scientific_name' => 'required|string'
        ]);

        $result = $this->getTaxonomyInfo($request->scientific_name);

        if ($result['success']) {
            return response()->json([
                'success' => true,
                'data' => $result['data']
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => $result['message']
        ], 404);
    }

    public function getChecklistDetail($id)
    {
        try {
            $userId = JWTAuth::user()->id;

            $checklist = DB::table('fobi_checklist_taxas')
                ->join('taxa_quality_assessments', 'fobi_checklist_taxas.id', '=', 'taxa_quality_assessments.taxa_id')
                ->join('fobi_users', 'fobi_checklist_taxas.user_id', '=', 'fobi_users.id')
                ->join('taxas', 'fobi_checklist_taxas.taxa_id', '=', 'taxas.id')
                ->where('fobi_checklist_taxas.id', $id)
                ->select(
                    'fobi_checklist_taxas.*',
                    'taxa_quality_assessments.grade',
                    'fobi_users.uname as observer_name',
                    'taxas.iucn_red_list_category',
                    'fobi_checklist_taxas.agreement_count'
                )
                ->first();

            if (!$checklist) {
                return response()->json([
                    'success' => false,
                    'message' => 'Checklist tidak ditemukan'
                ], 404);
            }

            // Ambil semua media terkait
            $medias = DB::table('fobi_checklist_media')
                ->where('checklist_id', $id)
                ->select(
                    'id',
                    DB::raw("CASE
                        WHEN media_type = 'photo' THEN 'image'
                        WHEN media_type = 'audio' THEN 'audio'
                        ELSE media_type
                    END as type"),
                    DB::raw("CONCAT('" . asset('storage/') . "/', file_path) as url"),
                    DB::raw("CASE
                        WHEN media_type = 'audio'
                        THEN CONCAT('" . asset('storage/') . "/', REPLACE(file_path, SUBSTRING_INDEX(file_path, '.', -1), 'png'))
                        ELSE NULL
                    END as spectrogramUrl")
                )
                ->get();

            // Ambil identifikasi
            $identifications = DB::table('taxa_identifications')
                ->join('fobi_users', 'taxa_identifications.user_id', '=', 'fobi_users.id')
                ->join('taxas', 'taxa_identifications.taxon_id', '=', 'taxas.id')
                ->where('taxa_identifications.checklist_id', $id)
                ->select(
                    'taxa_identifications.*',
                    'fobi_users.uname',
                    'taxas.scientific_name',
                    'taxas.taxon_rank as identification_level',
                    'fobi_users.uname as identifier_name',
                    DB::raw('(SELECT COUNT(*) FROM taxa_identifications AS ti
                        WHERE ti.agrees_with_id = taxa_identifications.id
                        AND ti.is_agreed = true) as agreement_count'),
                    DB::raw('(SELECT COUNT(*) > 0 FROM taxa_identifications AS ti
                        WHERE ti.agrees_with_id = taxa_identifications.id
                        AND ti.user_id = ' . $userId . '
                        AND ti.is_agreed = true) as user_agreed'),
                    DB::raw('(SELECT COUNT(*) > 0 FROM taxa_identifications AS ti
                        WHERE ti.agrees_with_id = taxa_identifications.id
                        AND ti.user_id = ' . $userId . '
                        AND ti.is_agreed = false) as user_disagreed'),
                        DB::raw("CASE WHEN taxa_identifications.photo_path IS NOT NULL
                    THEN CONCAT('" . asset('storage') . "/', taxa_identifications.photo_path)
                    ELSE NULL END as photo_url")
                )
                ->orderBy('taxa_identifications.is_first', 'desc')
                ->orderBy('taxa_identifications.created_at', 'desc')
                ->get();

            // Ambil verifikasi lokasi dan status liar
            $locationVerifications = DB::table('taxa_location_verifications')
                ->where('checklist_id', $id)
                ->get();

            $wildStatusVotes = DB::table('taxa_wild_status_votes')
                ->where('checklist_id', $id)
                ->get();

            // Tambahkan medias ke dalam response
            $checklist->medias = $medias;

            return response()->json([
                'success' => true,
                'data' => [
                    'checklist' => $checklist,
                    'identifications' => $identifications,
                    'location_verifications' => $locationVerifications,
                    'wild_status_votes' => $wildStatusVotes,
                ]
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching checklist detail: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan'
            ], 500);
        }
    }

    public function addIdentification(Request $request, $id)
    {
        try {
            $request->validate([
                'taxon_id' => 'required|exists:taxas,id',
                'comment' => 'nullable|string|max:500',
                'photo' => 'nullable|image|max:5120', // Max 5MB
                'identification_level' => 'required|string'
            ]);

            DB::beginTransaction();

            $user = JWTAuth::user();
            $photoPath = null;

            // Proses upload foto jika ada
            if ($request->hasFile('photo')) {
                $photo = $request->file('photo');
                $photoPath = $photo->store('identification-photos', 'public');
            }

            // Simpan identifikasi
            $identificationId = DB::table('taxa_identifications')->insertGetId([
                'checklist_id' => $id,
                'user_id' => $user->id,
                'taxon_id' => $request->taxon_id,
                'identification_level' => $request->identification_level,
                'comment' => $request->comment,
                'photo_path' => $photoPath,
                'is_first' => true,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Update quality assessment
            $this->updateQualityAssessment($id);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditambahkan',
                'data' => [
                    'id' => $identificationId,
                    'photo_url' => $photoPath ? asset('storage/' . $photoPath) : null
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error adding identification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan identifikasi'
            ], 500);
        }
    }

    // Tambahkan method untuk mengambil identifikasi dengan foto
    private function getIdentificationsWithPhotos($checklistId)
    {
        return DB::table('taxa_identifications as ti')
            ->join('fobi_users as u', 'ti.user_id', '=', 'u.id')
            ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
            ->where('ti.checklist_id', $checklistId)
            ->select(
                'ti.*',
                'u.uname as identifier_name',
                't.scientific_name',
                DB::raw("CASE WHEN ti.photo_path IS NOT NULL
                    THEN CONCAT('" . asset('storage') . "/', ti.photo_path)
                    ELSE NULL END as photo_url")
            )
            ->orderBy('ti.created_at', 'desc')
            ->get();
    }
    public function withdrawIdentification($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            // Tarik identifikasi
            DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->update(['is_withdrawn' => true]);

            // Hapus semua persetujuan terkait
            DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->delete();

            // Reset community_id_level dan grade ke default
            DB::table('taxa_quality_assessments')
                ->where('taxa_id', $checklistId)
                ->update([
                    'community_id_level' => null,
                    'grade' => 'needs ID'
                ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditarik dan pengaturan direset'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in withdrawIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menarik identifikasi'
            ], 500);
        }
    }
        private function updateChecklistTaxon($checklistId)
    {
        try {
            // Ambil identifikasi dengan persetujuan terbanyak
            $mostAgreedIdentification = DB::table('taxa_identifications as ti')
                ->select(
                    'ti.taxon_id',
                    't.scientific_name',
                    't.iucn_red_list_category',
                    't.class',
                    't.order',
                    't.family',
                    't.genus',
                    't.species',
                    DB::raw('COUNT(ti2.id) as agreement_count')
                )
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->leftJoin('taxa_identifications as ti2', function($join) {
                    $join->on('ti.id', '=', 'ti2.agrees_with_id')
                        ->where('ti2.is_agreed', '=', true);
                })
                ->where('ti.checklist_id', $checklistId)
                ->where('ti.is_first', true) // Hanya cek persetujuan untuk identifikasi pertama
                ->groupBy('ti.taxon_id', 't.scientific_name', 't.iucn_red_list_category',
                         't.class', 't.order', 't.family', 't.genus', 't.species')
                ->first();

            if ($mostAgreedIdentification) {
                // Update checklist dengan taxa yang disetujui
                $updateData = [
                    'taxa_id' => $mostAgreedIdentification->taxon_id,
                    'scientific_name' => $mostAgreedIdentification->scientific_name,
                    'class' => $mostAgreedIdentification->class,
                    'order' => $mostAgreedIdentification->order,
                    'family' => $mostAgreedIdentification->family,
                    'genus' => $mostAgreedIdentification->genus,
                    'species' => $mostAgreedIdentification->species,
                    'agreement_count' => $mostAgreedIdentification->agreement_count
                ];

                // Cek apakah memenuhi kriteria research grade
                $assessment = TaxaQualityAssessment::where('taxa_id', $checklistId)->first();

                if ($assessment && $assessment->grade === 'research grade') {
                    $updateData['iucn_status'] = $mostAgreedIdentification->iucn_red_list_category;
                }

                DB::table('fobi_checklist_taxas')
                    ->where('id', $checklistId)
                    ->update($updateData);

                // Log perubahan
                Log::info('Checklist updated:', [
                    'checklist_id' => $checklistId,
                    'new_taxa_id' => $mostAgreedIdentification->taxon_id,
                    'agreement_count' => $mostAgreedIdentification->agreement_count,
                    'is_research_grade' => $assessment ? $assessment->grade === 'research grade' : false
                ]);
            }

            return true;
        } catch (\Exception $e) {
            Log::error('Error updating checklist taxon: ' . $e->getMessage());
            throw $e;
        }
    }

    private function updateCommunityConsensus($checklistId)
    {
        // Ambil identifikasi dengan jumlah persetujuan terbanyak
        $mostAgreedIdentification = DB::table('taxa_identifications')
            ->select('taxon_id', DB::raw('COUNT(*) as agreement_count'))
            ->where('checklist_id', $checklistId)
            ->where('is_agreed', true)
            ->groupBy('taxon_id')
            ->orderBy('agreement_count', 'desc')
            ->first();

        if ($mostAgreedIdentification) {
            // Update fobi_checklist_taxas (bukan checklists)
            DB::table('fobi_checklist_taxas')
                ->where('id', $checklistId)
                ->update([
                    'taxa_id' => $mostAgreedIdentification->taxon_id,
                    'updated_at' => now()
                ]);
        }
    }
    private function evaluateAndUpdateGrade($assessment, $agreementCount)
    {
        try {
            // Ambil data checklist
            $checklist = FobiChecklistTaxa::findOrFail($assessment->taxa_id);

            // Evaluasi grade berdasarkan kriteria
            if ($this->meetsResearchGradeCriteria($assessment, $agreementCount)) {
                $assessment->grade = 'research grade';
            }
            else if ($this->meetsNeedsIdCriteria($assessment)) {
                $assessment->grade = 'needs ID';
            }
            else {
                $assessment->grade = 'casual';
            }

            $assessment->save();

            Log::info('Grade evaluation result:', [
                'taxa_id' => $assessment->taxa_id,
                'new_grade' => $assessment->grade,
                'agreement_count' => $agreementCount,
                'community_level' => $assessment->community_id_level
            ]);

        } catch (\Exception $e) {
            Log::error('Error in evaluateAndUpdateGrade:', [
                'error' => $e->getMessage(),
                'taxa_id' => $assessment->taxa_id ?? null
            ]);
            throw $e;
        }
    }

    // Tambahkan endpoint baru untuk menangani persetujuan identifikasi
    public function agreeWithIdentification($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Cek apakah sudah pernah setuju
            $existingAgreement = DB::table('taxa_identifications')
                ->where('checklist_id', $checklistId)
                ->where('user_id', $user->id)
                ->where('agrees_with_id', $identificationId)
                ->first();

            if ($existingAgreement) {
                throw new \Exception('Anda sudah menyetujui identifikasi ini');
            }

            // Ambil identifikasi yang disetujui
            $agreedIdentification = DB::table('taxa_identifications as ti')
                ->join('taxas as t', 't.id', '=', 'ti.taxon_id')
                ->join('fobi_users as u', 'u.id', '=', 'ti.user_id')
                ->where('ti.id', $identificationId)
                ->select(
                    'ti.*',
                    't.scientific_name',
                    't.iucn_red_list_category',
                    'u.uname as identifier_name'
                )
                ->first();

            // Simpan persetujuan
            $agreement = DB::table('taxa_identifications')->insert([
                'checklist_id' => $checklistId,
                'user_id' => $user->id,
                'agrees_with_id' => $identificationId,
                'taxon_id' => $agreedIdentification->taxon_id,
                'identification_level' => $agreedIdentification->identification_level,
                'is_agreed' => true,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Hitung jumlah persetujuan untuk identifikasi ini
            $agreementCount = DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->where('is_agreed', true)
                ->count();

            // Jika persetujuan mencapai 2 atau lebih, update checklist dan assessment
            if ($agreementCount >= 2) {
                // Ambil data checklist sebelumnya
                $currentChecklist = DB::table('fobi_checklist_taxas')
                    ->where('id', $checklistId)
                    ->first();

                // Simpan perubahan ke history
                DB::table('taxa_identification_histories')->insert([
                    'checklist_id' => $checklistId,
                    'taxa_id' => $agreedIdentification->taxon_id,
                    'user_id' => $user->id,
                    'action_type' => 'change',
                    'scientific_name' => $agreedIdentification->scientific_name,
                    'previous_name' => $currentChecklist->scientific_name,
                    'reason' => 'Persetujuan komunitas',
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Update checklist
                DB::table('fobi_checklist_taxas')
                    ->where('id', $checklistId)
                    ->update([
                        'taxa_id' => $agreedIdentification->taxon_id,
                        'scientific_name' => $agreedIdentification->scientific_name,
                        'agreement_count' => $agreementCount,
                        'updated_at' => now()
                    ]);

                // Update quality assessment dengan community_id_level
                $assessment = TaxaQualityAssessment::firstOrCreate(
                    ['taxa_id' => $checklistId],
                    ['grade' => 'needs ID']
                );

                $assessment->community_id_level = $agreedIdentification->identification_level;

                // Evaluasi dan update grade
                $this->evaluateAndUpdateGrade($assessment, $agreementCount);
            } else {
                // Jika belum mencapai 2 persetujuan
                $assessment = TaxaQualityAssessment::firstOrCreate(
                    ['taxa_id' => $checklistId],
                    ['grade' => 'needs ID']
                );

                // Tetap update community_id_level jika ini persetujuan pertama
                if ($agreementCount === 1) {
                    $assessment->community_id_level = $agreedIdentification->identification_level;
                }

                $assessment->save();
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'data' => [
                    'agreement_count' => $agreementCount,
                    'user_agreed' => true,
                    'checklist' => [
                        'taxa_id' => $agreedIdentification->taxon_id,
                        'scientific_name' => $agreedIdentification->scientific_name,
                        'iucn_status' => $agreedIdentification->iucn_red_list_category,
                        'agreement_count' => $agreementCount
                    ]
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in agreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    private function evaluateGrade($checklistId)
    {
        // Ambil data yang diperlukan untuk evaluasi
        $checklist = DB::table('fobi_checklist_taxas')
            ->where('id', $checklistId)
            ->first();

        $identifications = DB::table('taxa_identifications')
            ->where('checklist_id', $checklistId)
            ->get();

        // Hitung jumlah persetujuan
        $agreementCount = $identifications->where('is_agreed', true)->count();

        // Tentukan grade berdasarkan kriteria
        $newGrade = 'casual';
        if ($agreementCount >= 2) {
            $newGrade = 'research grade';
        } else if ($agreementCount >= 1) {
            $newGrade = 'needs ID';
        }

        // Update quality assessment
        DB::table('taxa_quality_assessments')
            ->updateOrInsert(
                ['taxa_id' => $checklistId],
                [
                    'grade' => $newGrade,
                    'updated_at' => now()
                ]
            );

        // Log hasil evaluasi
        Log::info('Grade evaluation result:', [
            'taxa_id' => $checklistId,
            'new_grade' => $newGrade,
            'agreement_count' => $agreementCount
        ]);
    }

    private function meetsResearchGradeCriteria($assessment, $identificationCount)
    {
        return
            $assessment->has_date &&
            $assessment->has_location &&
            $assessment->has_media &&
            $identificationCount >= 2 &&
            $assessment->is_wild &&
            $assessment->location_accurate &&
            $assessment->recent_evidence &&
            $assessment->related_evidence &&
            in_array(strtolower($assessment->community_id_level), ['species', 'subspecies', 'variety']);
    }
    private function meetsNeedsIdCriteria($assessment)
    {
        return
            $assessment->has_date &&
            $assessment->has_location &&
            $assessment->has_media;
    }

    private function determineCommunityLevel($checklistId)
    {
        $identifications = DB::table('taxa_identifications')
            ->where('checklist_id', $checklistId)
            ->select('identification_level', DB::raw('count(*) as count'))
            ->groupBy('identification_level')
            ->orderBy('count', 'desc')
            ->get();

        // Minimal 2 identifikasi yang sama untuk konsensus
        foreach ($identifications as $identification) {
            if ($identification->count >= 2) {
                return strtolower($identification->identification_level);
            }
        }

        // Jika tidak ada konsensus, ambil level tertinggi
        $firstIdentification = DB::table('taxa_identifications')
            ->where('checklist_id', $checklistId)
            ->orderBy('created_at', 'desc')
            ->first();

        return $firstIdentification ? strtolower($firstIdentification->identification_level) : null;
    }

    public function verifyLocation(Request $request, $id)
    {
        $request->validate([
            'is_accurate' => 'required|boolean',
            'comment' => 'nullable|string|max:500'
        ]);

        try {
            $userId = JWTAuth::user()->id;
            if (!$userId) {
                return response()->json(['success' => false, 'message' => 'Pengguna tidak terautentikasi'], 401);
            }

            DB::table('taxa_location_verifications')->insert([
                'checklist_id' => $id,
                'user_id' => $userId,
                'is_accurate' => $request->is_accurate,
                'comment' => $request->comment,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            return response()->json(['success' => true, 'message' => 'Verifikasi lokasi berhasil ditambahkan']);
        } catch (\Exception $e) {
            Log::error('Error verifying location: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }

    public function voteWildStatus(Request $request, $id)
    {
        $request->validate([
            'is_wild' => 'required|boolean',
            'comment' => 'nullable|string|max:500'
        ]);

        try {
            $userId = JWTAuth::user()->id;
            if (!$userId) {
                return response()->json(['success' => false, 'message' => 'Pengguna tidak terautentikasi'], 401);
            }

            DB::table('taxa_wild_status_votes')->insert([
                'checklist_id' => $id,
                'user_id' => $userId,
                'is_wild' => $request->is_wild,
                'comment' => $request->comment,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            return response()->json(['success' => true, 'message' => 'Vote status liar berhasil ditambahkan']);
        } catch (\Exception $e) {
            Log::error('Error voting wild status: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }

    public function searchTaxa(Request $request)
    {
        $query = $request->input('q');

        // Pastikan query tidak kosong sebelum melakukan pencarian
        if (empty($query)) {
            return response()->json(['success' => true, 'data' => []]);
        }

        $taxa = DB::table('taxas')
            ->where('scientific_name', 'like', '%' . $query . '%')
            ->get();

        return response()->json(['success' => true, 'data' => $taxa]);
    }
    public function addComment(Request $request, $id)
    {
        $request->validate([
            'comment' => 'required|string|max:1000',
        ]);

        $userId = JWTAuth::user()->id;
        if (!$userId) {
            return response()->json(['success' => false, 'message' => 'Pengguna tidak terautentikasi'], 401);
        }

        try {
            DB::table('checklist_comments')->insert([
                'checklist_id' => $id,
                'user_id' => $userId,
                'comment' => $request->comment,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            return response()->json(['success' => true, 'message' => 'Komentar berhasil ditambahkan']);
        } catch (\Exception $e) {
            Log::error('Error adding comment: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }
    public function rateChecklist(Request $request, $id)
    {
        $request->validate([
            'grade' => 'required|in:research grade,needs ID,casual',
        ]);

        try {
            $userId = JWTAuth::user()->id;
            if (!$userId) {
                return response()->json(['success' => false, 'message' => 'Pengguna tidak terautentikasi'], 401);
            }

            $assessment = TaxaQualityAssessment::where('taxa_id', $id)->first();
            if (!$assessment) {
                return response()->json(['success' => false, 'message' => 'Penilaian tidak ditemukan'], 404);
            }

            $assessment->update(['grade' => $request->input('grade')]);

            return response()->json(['success' => true, 'message' => 'Penilaian berhasil diperbarui']);
        } catch (\Exception $e) {
            Log::error('Error rating checklist: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }
    public function getComments($id)
    {
        try {
            $comments = DB::table('checklist_comments')
                ->where('checklist_id', $id)
                ->join('fobi_users', 'checklist_comments.user_id', '=', 'fobi_users.id')
                ->select('checklist_comments.*', 'fobi_users.uname as user_name')
                ->get();

            return response()->json(['success' => true, 'data' => $comments]);
        } catch (\Exception $e) {
            Log::error('Error fetching comments: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }


    public function assessQuality($id)
    {
        try {
            // Cek checklist dengan id yang diberikan
            $checklist = FobiChecklistTaxa::find($id);

            if (!$checklist) {
                return response()->json(['success' => false, 'message' => 'Checklist tidak ditemukan'], 404);
            }

            // Hitung jumlah identifikasi
            $identificationCount = DB::table('taxa_identifications')
                ->where('checklist_id', $id)
                ->count();

            // Ambil atau buat quality assessment
            $assessment = TaxaQualityAssessment::firstOrNew([
                'taxa_id' => $id  // Gunakan checklist id, bukan taxa_id
            ]);

            // Set nilai default berdasarkan data checklist
            if (!$assessment->exists) {
                $assessment->fill([
                    'has_date' => !empty($checklist->created_at),
                    'has_location' => !empty($checklist->latitude) && !empty($checklist->longitude),
                    'has_media' => DB::table('fobi_checklist_media')->where('checklist_id', $id)->exists(),
                    'is_wild' => true,
                    'location_accurate' => true,
                    'recent_evidence' => true,
                    'related_evidence' => true,
                    'grade' => 'needs ID'
                ]);

                // Evaluasi grade berdasarkan kriteria
                if ($this->meetsResearchGradeCriteria($assessment, $identificationCount)) {
                    $assessment->grade = 'research grade';
                } else if ($this->meetsNeedsIdCriteria($assessment)) {
                    $assessment->grade = 'needs ID';
                } else {
                    $assessment->grade = 'casual';
                }

                $assessment->save();
            }

            return response()->json([
                'success' => true,
                'data' => $assessment
            ]);
        } catch (\Exception $e) {
            Log::error('Error assessing quality: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Terjadi kesalahan'], 500);
        }
    }

    // Hapus fungsi setDefaultAssessment karena sudah diintegrasikan ke dalam assessQuality

    private function determineGrade($checklistId)
    {
        try {
            // Ambil data checklist
            $checklist = FobiChecklistTaxa::findOrFail($checklistId);

            // Hitung jumlah identifikasi
            $identificationCount = DB::table('taxa_identifications')
                ->where('checklist_id', $checklistId)
                ->count();

            // Ambil assessment yang ada
            $assessment = TaxaQualityAssessment::where('taxa_id', $checklistId)->first();

            if (!$assessment) {
                return 'needs ID';
            }

            // Tentukan grade
            if ($this->meetsResearchGradeCriteria($assessment, $identificationCount)) {
                return 'research grade';
            } else if ($this->meetsNeedsIdCriteria($assessment)) {
                return 'needs ID';
            }
            return 'casual';

        } catch (\Exception $e) {
            Log::error('Error determining grade: ' . $e->getMessage(), [
                'checklist_id' => $checklistId
            ]);
            return 'needs ID';
        }
    }
    public function updateQualityAssessment($checklistId)
    {
        try {
            // Ambil data checklist
            $checklist = DB::table('fobi_checklist_taxas')
                ->where('id', $checklistId)
                ->first();

            if (!$checklist) {
                throw new \Exception('Checklist tidak ditemukan');
            }

            // Hitung jumlah identifikasi yang setuju
            $agreementCount = DB::table('taxa_identifications')
                ->where('checklist_id', $checklistId)
                ->where('is_agreed', true)
                ->count();

            // Ambil level identifikasi komunitas
            $communityLevel = DB::table('taxa_identifications as ti')
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->where('ti.checklist_id', $checklistId)
                ->where('ti.is_agreed', true)
                ->value('t.taxon_rank');

            // Tentukan grade berdasarkan kriteria
            $newGrade = 'needs ID';
            if ($agreementCount >= 2) {
                $newGrade = 'research grade';
            }

            // Log hasil evaluasi
            Log::info('Grade evaluation result:', [
                'taxa_id' => $checklistId,
                'new_grade' => $newGrade,
                'agreement_count' => $agreementCount,
                'community_level' => $communityLevel
            ]);

            // Update atau insert quality assessment
            DB::table('taxa_quality_assessments')->updateOrInsert(
                ['checklist_id' => $checklistId],
                [
                    'grade' => $newGrade,
                    'community_id_level' => $communityLevel,
                    'updated_at' => now()
                ]
            );

            return [
                'success' => true,
                'grade' => $newGrade,
                'agreement_count' => $agreementCount,
                'community_level' => $communityLevel
            ];

        } catch (\Exception $e) {
            Log::error('Error in updateQualityAssessment: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
            public function updateImprovementStatus(Request $request, $id)
    {
        try {
            $request->validate([
                'can_be_improved' => 'required|boolean'
            ]);

            $checklist = FobiChecklistTaxa::findOrFail($id);

            // Validasi bahwa user adalah uploader
            if ($checklist->user_id !== $request->user()->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }

            // Ambil atau buat assessment berdasarkan taxa_id
            $assessment = TaxaQualityAssessment::firstOrCreate(
                ['taxa_id' => $checklist->id],
                [
                    'grade' => 'needs ID'
                ]
            );

            $assessment->can_be_improved = $request->can_be_improved;

            // Evaluasi ulang grade berdasarkan can_be_improved
            if ($request->can_be_improved) {
                // Cek kriteria untuk needs ID
                if ($this->meetsNeedsIdCriteria($assessment)) {
                    $assessment->grade = 'needs ID';
                } else {
                    $assessment->grade = 'casual';
                }
            } else {
                // Cek apakah memenuhi research grade
                if ($this->meetsResearchGradeCriteria($assessment, $checklist->id)) {
                    $assessment->grade = 'research grade';
                } else {
                    $assessment->grade = 'casual'; // Tambahkan fallback jika tidak memenuhi kriteria
                }
            }

            $assessment->save();

            return response()->json([
                'success' => true,
                'data' => $assessment,
                'message' => 'Status berhasil diperbarui'
            ]);

        } catch (\Exception $e) {
            Log::error('Error updating improvement status: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memperbarui status'
            ], 500);
        }
    }
    private function meetsAllCriteria($assessment, $checklistId)
    {
        // Cek identifikasi menggunakan checklist id
        $identificationCount = DB::table('taxa_identifications')
            ->where('checklist_id', $checklistId)
            ->count();

        $latestIdentification = DB::table('taxa_identifications')
            ->where('checklist_id', $checklistId)
            ->orderBy('created_at', 'desc')
            ->first();

        // Periksa community_id_level dari assessment
        $isSpeciesLevel = $assessment->community_id_level === 'species' || $assessment->community_id_level === 'subspecies' || $assessment->community_id_level === 'variety';

        return $assessment->has_date &&
               $assessment->has_location &&
               $assessment->has_media &&
               $assessment->is_wild &&
               $assessment->location_accurate &&
               $assessment->recent_evidence &&
               $assessment->related_evidence &&
               $isSpeciesLevel &&
               $identificationCount >= 2;
    }

    public function getRelatedLocations($taxaId)
    {
        try {
            // Ambil semua checklist dengan taxa_id yang sama
            $relatedLocations = DB::table('fobi_checklist_taxas as fct')
                ->join('taxa_quality_assessments as tqa', 'fct.id', '=', 'tqa.taxa_id')
                ->where('fct.taxa_id', $taxaId)
                ->select(
                    'fct.id',
                    'fct.latitude',
                    'fct.longitude',
                    'fct.scientific_name',
                    'fct.created_at',
                    'tqa.grade'
                )
                ->get();

            // Format response
            $formattedLocations = $relatedLocations->map(function($location) {
                return [
                    'id' => $location->id,
                    'latitude' => $location->latitude,
                    'longitude' => $location->longitude,
                    'scientific_name' => $location->scientific_name,
                    'created_at' => $location->created_at,
                    'grade' => $location->grade
                ];
            });

            return response()->json($formattedLocations);

        } catch (\Exception $e) {
            Log::error('Error getting related locations: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil lokasi terkait'
            ], 500);
        }
    }

    public function cancelAgreement($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Hapus sub-identifikasi (persetujuan)
            $deleted = DB::table('taxa_identifications')
                ->where('checklist_id', $checklistId)
                ->where('user_id', $user->id)
                ->where('agrees_with_id', $identificationId)
                ->where('is_agreed', true)
                ->delete();

            if (!$deleted) {
                throw new \Exception('Persetujuan tidak ditemukan');
            }

            // Update jumlah persetujuan
            $agreementCount = DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->where('is_agreed', true)
                ->count();

            // Hanya update community consensus
            $this->updateCommunityConsensus($checklistId);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Persetujuan berhasil dibatalkan',
                'data' => [
                    'agreement_count' => $agreementCount
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in cancelAgreement: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    // Tambahkan method untuk menolak identifikasi
    public function disagreeWithIdentification(Request $request, $checklistId, $identificationId)
    {
        $request->validate([
            'taxon_id' => 'nullable|exists:taxas,id',
            'identification_level' => 'required|string',
            'photo' => 'nullable|image|max:2048', // Validasi untuk foto
        ]);

        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Simpan foto jika ada
            $photoPath = null;
            if ($request->hasFile('photo')) {
                $photoPath = $request->file('photo')->store('identification_photos', 'public');
            }

            // Simpan penolakan identifikasi
            DB::table('taxa_identifications')->insert([
                'checklist_id' => $checklistId,
                'user_id' => $user->id,
                'taxon_id' => $request->taxon_id,
                'identification_level' => $request->identification_level,
                'comment' => $request->comment,
                'photo_path' => $photoPath,
                'is_agreed' => false,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Penolakan identifikasi berhasil disimpan'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error disagreeing with identification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menolak identifikasi'
            ], 500);
        }
    }
}
