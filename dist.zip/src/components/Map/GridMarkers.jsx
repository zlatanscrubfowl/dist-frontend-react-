import React, { useMemo } from 'react';
import { Marker, Rectangle, Popup } from 'react-leaflet';
import { getColor } from '../../utils/mapHelpers';
import { formatDate } from '../../utils/dateHelpers';

// Komponen untuk marker individual
export const SmallGridMarkers = React.memo(({ markers, icon, bounds }) => {
  if (!markers || markers.length === 0) return null;

  // Optimasi: Hanya render marker yang dalam viewport
  const visibleMarkers = useMemo(() => {
    if (!bounds) return markers;
    return markers.filter(marker => {
      const lat = parseFloat(marker.latitude);
      const lng = parseFloat(marker.longitude);
      return bounds.contains([lat, lng]);
    });
  }, [markers, bounds]);

  // Batasi jumlah marker yang dirender untuk performa
  const maxMarkers = 1000;
  const markersToRender = visibleMarkers.slice(0, maxMarkers);

  return markersToRender.map((marker) => (
    <Marker
      key={`marker-${marker.id}`}
      position={[marker.latitude, marker.longitude]}
      icon={icon}
    >
      <Popup>
        <div className="marker-popup">
          <p><strong>ID:</strong> {marker.id}</p>
          <p><strong>Source:</strong> {marker.source}</p>
          <p><strong>Date:</strong> {formatDate(marker.created_at)}</p>
        </div>
      </Popup>
    </Marker>
  ));
});

// Komponen untuk grid rectangles dengan optimasi tile-based
export const GridRectangles = React.memo(({ grid, onGridClick, bounds }) => {
  if (!grid || grid.length === 0) return null;

  // Optimasi: Hanya render grid yang dalam viewport
  const visibleGrid = useMemo(() => {
    if (!bounds) return grid;
    return grid.filter(gridItem => {
      const [[south, west], [north, east]] = gridItem.bounds;
      return bounds.intersects([[south, west], [north, east]]);
    });
  }, [grid, bounds]);

  // Batasi jumlah grid yang dirender untuk performa
  const maxGrids = 500;
  const gridsToRender = visibleGrid.slice(0, maxGrids);

  return gridsToRender.map((gridItem, index) => {
    // Ambil data pertama untuk popup
    const firstItem = gridItem.data?.[0];
    const date = firstItem?.created_at;

    return (
      <Rectangle
        key={`grid-${index}-${gridItem.bounds[0][0]}-${gridItem.bounds[0][1]}`}
        bounds={gridItem.bounds}
        pathOptions={{
          color: getColor(gridItem.count, gridItem.source),
          fillColor: getColor(gridItem.count, gridItem.source),
          fillOpacity: 0.6,
          weight: 1
        }}
        eventHandlers={{
          click: () => {
            if (onGridClick && gridItem.data?.length > 0) {
              onGridClick({
                ...gridItem,
                id: firstItem.id,
                checklist_id: firstItem.checklist_id || firstItem.id,
                source: firstItem.source || gridItem.source
              });
            }
          }
        }}
      >
        <Popup>
          <div>
            <p><strong>Total:</strong> {gridItem.count}</p>
            <p><strong>Source:</strong> {gridItem.source}</p>
            {date && <p><strong>Latest:</strong> {formatDate(date)}</p>}
          </div>
        </Popup>
      </Rectangle>
    );
  });
});

// Tambahkan displayName untuk debugging
SmallGridMarkers.displayName = 'SmallGridMarkers';
GridRectangles.displayName = 'GridRectangles'; 