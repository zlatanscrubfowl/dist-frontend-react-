import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faXmark } from '@fortawesome/free-solid-svg-icons';
import { getSourceLogo } from '../../utils/mapHelpers';

export const Sidebar = React.memo(({ data, onClose, onLoadMore }) => {
  const { selectedGrid, species, currentPage } = data;
  const itemsPerPage = 7;
  const paginatedData = selectedGrid?.data?.slice(0, currentPage * itemsPerPage);

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollTop + clientHeight >= scrollHeight - 5) {
      onLoadMore();
    }
  };

  return (
    <div
      className="fixed md:relative top-0 left-0 w-full md:w-1/4 h-full md:h-[70vh] overflow-y-auto bg-[#5f8b8b] p-2 box-border text-white text-sm z-[100]"
      onScroll={handleScroll}
    >
      <button
        onClick={onClose}
        className="absolute top-2 right-5 z-1000 hover:text-gray-200"
      >
        <FontAwesomeIcon icon={faXmark} />
      </button>

      {/* Grid Data */}
      {paginatedData?.map((item, index) => (
        <div key={index} className="p-2 border-b border-gray-300 flex items-center">
          <img
            src={getSourceLogo(item.source)}
            alt={`${item.source} logo`}
            className="w-8 h-8 mr-2"
          />
          <div>
            <p>ID: {item.id}</p>
            <p>Source: {item.source}</p>
            <p>Date: {new Date(item.created_at).toLocaleDateString()}</p>
            {item.count && <p>Count: {item.count}</p>}
          </div>
        </div>
      ))}

      {/* Species Data */}
      {species.length > 0 && (
        <>
          <h3 className="mt-4 mb-2 font-medium">Species:</h3>
          {species.map((species, index) => (
            <div key={index} className="p-2 border-b border-gray-300">
              <p>Name ID: {species.nameId}</p>
              <p>Name Latin: {species.nameLat}</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
});

Sidebar.displayName = 'Sidebar'; 