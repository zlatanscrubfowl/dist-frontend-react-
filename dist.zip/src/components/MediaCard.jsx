import React, { useState, useRef, useEffect } from 'react';
import LocationPicker from './Observations/LocationPicker';
import Modal from './Observations/LPModal';
import { Swiper, SwiperSlide } from 'swiper/react';
import { FreeMode } from 'swiper/modules';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
    faDna, 
    faCalendar, 
    faLocationDot,
    faTree,
    faNoteSticky,
    faMusic,
    faPlay,
    faPause
} from '@fortawesome/free-solid-svg-icons';
import 'swiper/css';
import 'swiper/css/free-mode';
import './MediaCard.css';
import SpectrogramModal from './SpectrogramModal';
import QualityBadge from './QualityBadge';
import PropTypes from 'prop-types';
import { apiFetch } from '../utils/api';


function MediaCard({ observation, isSelected, onSelect, onUpdate, onDelete, bulkFormData, qualityGrade, uploadSessionId }) {
    const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [audioTime, setAudioTime] = useState(0);
    const [audioDuration, setAudioDuration] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isBuffering, setIsBuffering] = useState(false);
    const [error, setError] = useState(null);
    const [isSpectrogramModalOpen, setIsSpectrogramModalOpen] = useState(false);

    const audioRef = useRef(null);
    const spectrogramRef = useRef(null);
    const progressRef = useRef(null);
    const audioUrlRef = useRef(null);
    const spectrogramContainerRef = useRef(null);
    const [spectrogramWidth, setSpectrogramWidth] = useState(0);
    const swiperRef = useRef(null);

    const [formData, setFormData] = useState({
        scientific_name: '',
        date: '',
        location: '',
        habitat: '',
        description: '',
        type_sound: '',
        source: '',
        status: '',
        upload_session_id: uploadSessionId
    });

    useEffect(() => {
        if (isSelected && bulkFormData) {
            setFormData(prev => ({
                ...prev,
                ...bulkFormData
            }));
        }
    }, [bulkFormData, isSelected]);

    useEffect(() => {
        setFormData(prev => ({
            ...prev,
            upload_session_id: uploadSessionId
        }));
    }, [uploadSessionId]);

    const getAudioUrl = () => {
        if (!observation?.file) return '';
        return URL.createObjectURL(observation.file);
    };

    const [audioUrl, setAudioUrl] = useState('');

    useEffect(() => {
        const url = getAudioUrl();
        setAudioUrl(url);

        return () => {
            if (url) URL.revokeObjectURL(url);
        };
    }, [observation.file]);

    useEffect(() => {
        if (!audioRef.current) return;

        const audio = audioRef.current;

        const handlePlay = () => {
            setIsPlaying(true);
            setError(null);
        };

        const handlePause = () => setIsPlaying(false);
        
        const handleEnded = () => {
            setIsPlaying(false);
            if (progressRef.current) {
                progressRef.current.style.width = '0%';
            }
            if (swiperRef.current?.swiper) {
                swiperRef.current.swiper.setTranslate(0);
            }
        };

        const handleWaiting = () => setIsBuffering(true);
        
        const handleCanPlay = () => setIsBuffering(false);
        
        const handleError = (e) => {
            console.error('Audio error:', e);
            setError('Terjadi kesalahan saat memutar audio');
            setIsPlaying(false);
            setIsBuffering(false);
        };

        audio.addEventListener('play', handlePlay);
        audio.addEventListener('pause', handlePause);
        audio.addEventListener('ended', handleEnded);
        audio.addEventListener('waiting', handleWaiting);
        audio.addEventListener('canplay', handleCanPlay);
        audio.addEventListener('error', handleError);

        return () => {
            audio.removeEventListener('play', handlePlay);
            audio.removeEventListener('pause', handlePause);
            audio.removeEventListener('ended', handleEnded);
            audio.removeEventListener('waiting', handleWaiting);
            audio.removeEventListener('canplay', handleCanPlay);
            audio.removeEventListener('error', handleError);
        };
    }, []);

    useEffect(() => {
        if (spectrogramRef.current) {
            const updateWidth = () => {
                setSpectrogramWidth(spectrogramRef.current.scrollWidth);
            };
            updateWidth();
            window.addEventListener('resize', updateWidth);
            return () => window.removeEventListener('resize', updateWidth);
        }
    }, [observation.spectrogramUrl]);

    useEffect(() => {
        if (audioRef.current && swiperRef.current?.swiper) {
            const audio = audioRef.current;
            const swiper = swiperRef.current.swiper;
            
            const handleTimeUpdate = () => {
                const progress = audio.currentTime / audio.duration;
                const slideSize = swiper.size;
                const totalWidth = swiper.virtualSize - slideSize;
                
                swiper.translateTo(-totalWidth * progress, 300, true);
            };

            audio.addEventListener('timeupdate', handleTimeUpdate);
            return () => audio.removeEventListener('timeupdate', handleTimeUpdate);
        }
    }, []);
    const handleTimeUpdate = () => {
        if (audioRef.current) {
            const currentTime = audioRef.current.currentTime;
            const duration = audioRef.current.duration;
            
            if (isNaN(duration)) return;
            
            setAudioTime(currentTime);
            
            if (progressRef.current) {
                const progress = (currentTime / duration) * 100;
                progressRef.current.style.transform = `scaleX(${progress / 100})`;
            }

            if (swiperRef.current?.swiper) {
                const swiper = swiperRef.current.swiper;
                const slideSize = swiper.size;
                const totalWidth = swiper.virtualSize - slideSize;
                const progress = currentTime / duration;
                
                requestAnimationFrame(() => {
                    swiper.translateTo(-totalWidth * progress, 300, true);
                });
            }
        }
    };
    
    const handleLoadedMetadata = () => {
        try {
            if (audioRef.current) {
                const duration = audioRef.current.duration;
                if (!isNaN(duration)) {
                    setAudioDuration(duration);
                }
            }
        } catch (error) {
            console.error('Error loading metadata:', error);
        }
    };

    const handleSpectrogramClick = (e) => {
        if (audioRef.current && swiperRef.current?.swiper) {
            const swiper = swiperRef.current.swiper;
            const rect = swiper.el.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const width = rect.width;
            const clickPosition = x / width;
            
            const newTime = audioRef.current.duration * clickPosition;
            if (!isNaN(newTime)) {
                audioRef.current.currentTime = newTime;
                
                const totalWidth = swiper.virtualSize - swiper.size;
                swiper.setTranslate(-totalWidth * clickPosition);
                
                if (!isPlaying) {
                    audioRef.current.play()
                        .catch(error => {
                            console.error('Error playing audio:', error);
                            setError('Gagal memutar audio');
                        });
                }
            }
        }
    };

    const handleLocationSave = (lat, lng, name) => {
        onUpdate({
            latitude: lat,
            longitude: lng,
            locationName: name
        });
        setIsLocationModalOpen(false);
    };

    const [suggestions, setSuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [page, setPage] = useState(1);
    const [isLoadingMore, setIsLoadingMore] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const suggestionsRef = useRef(null);

    const handleInputChange = async (e) => {
        const { name, value } = e.target;
        
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));

        if (name === 'scientific_name') {
            if (value.length > 2) {
                try {
                    setPage(1);
                    setHasMore(true);
                    
                    const response = await apiFetch(`/taxonomy/search?q=${encodeURIComponent(value)}&page=${1}`, {
                        method: 'GET',
                        headers: {
                            'Authorization': `Bearer ${localStorage.getItem('jwt_token')}`,
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        }
                    });

                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }

                    const contentType = response.headers.get("content-type");
                    if (!contentType || !contentType.includes("application/json")) {
                        throw new TypeError("Response bukan JSON yang valid!");
                    }

                    const data = await response.json();
                    
                    if (data.success) {
                        setSuggestions(data.data.slice(0, 5));
                        setShowSuggestions(true);
                        setHasMore(data.data.length >= 5);
                    } else {
                        setSuggestions([]);
                        setShowSuggestions(false);
                        setHasMore(false);
                    }
                } catch (error) {
                    console.error('Error fetching suggestions:', error);
                    setSuggestions([]);
                    setShowSuggestions(false);
                    setHasMore(false);
                }
            } else {
                setSuggestions([]);
                setShowSuggestions(false);
                setHasMore(false);
            }
        }
    };

    const loadMoreSuggestions = async () => {
        if (!hasMore || isLoadingMore) return;

        try {
            setIsLoadingMore(true);
            const nextPage = page + 1;
            const value = formData.scientific_name;

            const response = await apiFetch(`/taxonomy/search?q=${encodeURIComponent(value)}&page=${nextPage}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('jwt_token')}`,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();

            if (data.success) {
                setSuggestions(prev => [...prev, ...data.data.slice(0, 5)]);
                setPage(nextPage);
                setHasMore(data.data.length >= 5);
            }
        } catch (error) {
            console.error('Error loading more suggestions:', error);
        } finally {
            setIsLoadingMore(false);
        }
    };

    const handleSuggestionsScroll = (e) => {
        const element = e.target;
        if (element.scrollHeight - element.scrollTop === element.clientHeight) {
            loadMoreSuggestions();
        }
    };

    const handleSuggestionClick = (suggestion) => {
        const updatedData = {
            ...formData,
            ...suggestion
        };
        
        setFormData(updatedData);
        onUpdate(updatedData);
        setSuggestions([]);
        setShowSuggestions(false);
    };

    const handleSave = () => {
        onUpdate({
            ...formData,
            upload_session_id: uploadSessionId
        });
        setIsEditing(false);
    };

    const handleSpectrogramModalOpen = () => {
        setIsSpectrogramModalOpen(true);
    };

    const togglePlay = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                audioRef.current.play()
                    .catch(error => {
                        console.error('Error playing audio:', error);
                        setError('Gagal memutar audio');
                    });
            }
        }
    };

    useEffect(() => {
        if (onUpdate) {
            onUpdate({
                ...formData,
                scientific_name: formData.scientific_name || '',
                upload_session_id: uploadSessionId
            });
        }
    }, [formData, uploadSessionId]);

    return (
        <div className={`media-card ${isSelected ? 'selected' : ''}`}>
            <div className="media-preview">
                {observation.type === 'image' ? (
                    <div className="image-container">
                        <img
                            src={URL.createObjectURL(observation.file)}
                            alt="Preview"
                            className="image-preview"
                        />
                        <div className="selection-checkbox">
                            <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => onSelect()}
                            />
                        </div>
                    </div>
                ) : (
                    <div className="audio-container">
                        <div className="selection-checkbox">
                            <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => onSelect()}
                            />
                        </div>
                        
                        {audioUrl && (
                            <audio
                                ref={audioRef}
                                src={audioUrl}
                                preload="auto"
                                onTimeUpdate={handleTimeUpdate}
                                onLoadedMetadata={handleLoadedMetadata}
                            >
                                Your browser does not support the audio element.
                            </audio>
                        )}

                        <div className="spectrogram-wrapper relative">
                            {observation.spectrogramUrl ? (
                                <>
                                    <button 
                                        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
                                                  bg-black/50 hover:bg-black/70 text-white rounded-full p-4 z-10
                                                  transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                        onClick={togglePlay}
                                    >
                                        <FontAwesomeIcon 
                                            icon={isPlaying ? faPause : faPlay} 
                                            className="w-6 h-6"
                                        />
                                    </button>

                                    <Swiper
                                        ref={swiperRef}
                                        className="spectrogram-swiper"
                                        modules={[FreeMode]}
                                        freeMode={{
                                            enabled: true,
                                            momentum: true,
                                            momentumRatio: 0.8,
                                            momentumVelocityRatio: 0.6
                                        }}
                                        slidesPerView="auto"
                                        resistance={true}
                                        resistanceRatio={0}
                                        touchRatio={1.5}
                                        speed={300}
                                        cssMode={false}
                                    >
                                        <SwiperSlide>
                                            <div className="spectrogram-container z-2">
                                                <div className="frequency-labels">
                                                    <span>20 kHz</span>
                                                    <span>15 kHz</span>
                                                    <span>10 kHz</span>
                                                    <span>5 kHz</span>
                                                    <span>0 kHz</span>
                                                </div>
                                                <img
                                                    src={observation.spectrogramUrl}
                                                    alt="Spectrogram"
                                                    className="spectrogram-image cursor-pointer z-2"
                                                    onClick={(e) => {
                                                        handleSpectrogramClick(e);
                                                        handleSpectrogramModalOpen();
                                                    }}
                                                />
                                                <div 
                                                    ref={progressRef}
                                                    className="progress-overlay"
                                                />
                                            </div>
                                        </SwiperSlide>
                                    </Swiper>

                                    <SpectrogramModal
                                        isOpen={isSpectrogramModalOpen}
                                        onClose={() => setIsSpectrogramModalOpen(false)}
                                        spectrogramUrl={observation.spectrogramUrl}
                                        progressRef={progressRef}
                                        handleSpectrogramClick={handleSpectrogramClick}
                                        audioDuration={audioDuration}
                                    />
                                </>
                            ) : (
                                <div className="spectrogram-loading">
                                    <div className="loading-spinner" />
                                    <span>Generating spectrogram...</span>
                                </div>
                            )}
                        </div>

                        <div className="audio-controls flex items-center justify-between px-4 py-2 bg-gray-100 rounded-b-lg">
                            <button 
                                className="play-pause-btn flex items-center space-x-2"
                                onClick={togglePlay}
                            >
                                <FontAwesomeIcon 
                                    icon={isPlaying ? faPause : faPlay} 
                                    className="w-4 h-4"
                                />
                                <span>{isPlaying ? 'Pause' : 'Play'}</span>
                            </button>

                            <div className="time-info text-sm">
                                <span>{formatTime(audioTime)} / {formatTime(audioDuration)}</span>
                            </div>

                            <span className="format-info text-sm">
                                {observation?.file?.type?.split('/')[1]?.toUpperCase() || 'AUDIO'}
                            </span>
                        </div>

                        {error && <div className="error-message text-red-500 text-sm mt-2">{error}</div>}
                        {isBuffering && (
                            <div className="buffering-message text-gray-500 text-sm mt-2">
                                <div className="loading-spinner" />
                                <span>Buffering...</span>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className="form-container">
                <div className="form-group space-y-4">
                    <div className="relative">
                        <div className="flex items-center space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                            <FontAwesomeIcon icon={faDna} className="text-gray-500 w-5 h-5" />
                            <input
                                type="text"
                                name="scientific_name"
                                placeholder="Nama Spesies"
                                className="w-full focus:outline-none text-gray-700"
                                value={formData.scientific_name}
                                onChange={handleInputChange}
                                onBlur={() => {
                                    setTimeout(() => setShowSuggestions(false), 200);
                                }}
                            />
                        </div>

                        {showSuggestions && suggestions.length > 0 && (
                            <div 
                                ref={suggestionsRef}
                                className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-y-auto"
                                onScroll={handleSuggestionsScroll}
                            >
                                {suggestions.map((suggestion, index) => (
                                    <div
                                        key={index}
                                        className="p-2 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-b-0"
                                        onClick={() => handleSuggestionClick(suggestion)}
                                    >
                                        <div className="font-medium truncate">
                                            {suggestion.scientific_name}
                                        </div>
                                        <div className="text-sm text-gray-600 truncate">
                                            {suggestion.kingdom} › {suggestion.family}
                                        </div>
                                    </div>
                                ))}
                                {isLoadingMore && (
                                    <div className="p-2 text-center text-gray-500">
                                        <div className="loading-spinner inline-block mr-2" />
                                        Memuat...
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    {formData.kingdom && (
                        <div className="mt-2 text-sm text-gray-600">
                            <div className="grid grid-cols-2 gap-2">
                                <div>Kingdom: {formData.kingdom}</div>
                                <div>Phylum: {formData.phylum}</div>
                                <div>Class: {formData.class}</div>
                                <div>Order: {formData.order}</div>
                                <div>Family: {formData.family}</div>
                                <div>Genus: {formData.genus}</div>
                                <div>Species: {formData.species}</div>
                                <div>Rank: {formData.taxon_rank}</div>
                            </div>
                        </div>
                    )}

                    <div className="flex items-center space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                        <FontAwesomeIcon icon={faCalendar} className="text-gray-500 w-5 h-5" />
                        <input
                            type="date"
                            name="date"
                            className="w-full focus:outline-none text-gray-700"
                            value={formData.date}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="flex items-center space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                        <FontAwesomeIcon icon={faLocationDot} className="text-gray-500 w-5 h-5" />
                        <button
                            onClick={() => setIsLocationModalOpen(true)}
                            className="w-full text-left text-gray-700 hover:text-gray-900"
                        >
                            {observation.locationName || 'Pilih lokasi'}
                        </button>
                    </div>

                    <div className="flex items-center space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                        <FontAwesomeIcon icon={faTree} className="text-gray-500 w-5 h-5" />
                        <input
                            type="text"
                            name="habitat"
                            placeholder="Habitat"
                            className="w-full focus:outline-none text-gray-700"
                            value={formData.habitat}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="flex space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                        <FontAwesomeIcon icon={faNoteSticky} className="text-gray-500 w-5 h-5 mt-1" />
                        <textarea
                            name="description"
                            placeholder="Keterangan"
                            rows="3"
                            className="w-full focus:outline-none text-gray-700 resize-none"
                            value={formData.description}
                            onChange={handleInputChange}
                        />
                    </div>

                    {observation.type === 'audio' && (
                        <>
                            <div className="flex items-center space-x-3 rounded-lg border border-gray-200 p-3 hover:border-gray-300">
                                <FontAwesomeIcon icon={faMusic} className="text-gray-500 w-5 h-5" />
                                <select
                                    name="type_sound"
                                    className="w-full focus:outline-none text-gray-700 bg-transparent"
                                    value={formData.type_sound}
                                    onChange={handleInputChange}
                                >
                                    <option value="">Pilih tipe suara</option>
                                    <option value="song">Song</option>
                                    <option value="call">Call</option>
                                </select>
                            </div>
                        </>
                    )}
                </div>

                <div className="action-buttons">
                    <button
                        onClick={onDelete}
                        className="delete-button"
                    >
                        Hapus
                    </button>
                </div>
            </div>

            <input 
                type="hidden" 
                name="upload_session_id" 
                value={uploadSessionId} 
            />

            <Modal
                isOpen={isLocationModalOpen}
                onClose={() => setIsLocationModalOpen(false)}
            >
                <LocationPicker onSave={handleLocationSave} />
            </Modal>
        </div>
    );
}

const formatTime = (seconds) => {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
};

MediaCard.propTypes = {
    uploadSessionId: PropTypes.string.isRequired
};

export default MediaCard;