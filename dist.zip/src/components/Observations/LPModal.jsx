import React from 'react';

function Modal({ isOpen, onClose, children }) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-600">
            <div className="bg-white p-6 rounded shadow-lg w-screen mt-10">
                {children}
                <button onClick={onClose} className="text-black p-1 rounded mt-2 absolute right-5 top-16 text-sm">close X</button>
            </div>
        </div>
    );
}

export default Modal;