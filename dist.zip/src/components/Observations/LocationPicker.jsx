import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

function LocationPicker({ onSave }) {
    const [position, setPosition] = useState([0, 0]);
    const [locationName, setLocationName] = useState('');

    const fetchLocationName = async (lat, lng) => {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
            const data = await response.json();
            setLocationName(data.display_name || 'Lokasi tidak ditemukan');
        } catch (error) {
            console.error('Error fetching location name:', error);
            setLocationName('Error mendapatkan nama lokasi');
        }
    };

    const LocationMarker = () => {
        useMapEvents({
            click(e) {
                setPosition([e.latlng.lat, e.latlng.lng]);
                fetchLocationName(e.latlng.lat, e.latlng.lng);
            },
        });

        return position === null ? null : (
            <Marker position={position}></Marker>
        );
    };

    return (
        <div className='mt-10 z-700'>
            <MapContainer center={[0, 0]} zoom={2} style={{ height: '400px', width: '100%' }}>
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <LocationMarker />
            </MapContainer>
            <p className="mt-2">{locationName}</p>
            <button onClick={() => onSave(position[0], position[1], locationName)} className="bg-green-500 text-white p-2 rounded mt-2">Simpan</button>
        </div>
    );
}

export default LocationPicker;