<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\KupunesiaChecklist;
use App\Models\KupunesiaIdentification;
use App\Models\DataQualityAssessmentKupnes;
use App\Traits\QualityAssessmentTrait;

class KupunesiaObservationController extends Controller
{
    use QualityAssessmentTrait;

    public function getChecklistDetail($id)
    {
        try {
            Log::info('Fetching checklist detail for ID: ' . $id); // Debug log

            // Ambil data checklist dengan relasi yang benar
            $checklist = DB::table('fobi_checklists_kupnes as fc')
                ->join('fobi_users as fu', 'fc.fobi_user_id', '=', 'fu.id')
                ->leftJoin('data_quality_assessments_kupnes as dqa', 'fc.id', '=', 'dqa.observation_id')
                ->leftJoin('fobi_checklist_faunasv2 as fcf', 'fc.id', '=', 'fcf.checklist_id')
                ->leftJoin(DB::connection('third')->getDatabaseName().'.faunas as f', 'fcf.fauna_id', '=', 'f.id')
                ->where('fc.id', $id)
                ->select(
                    'fc.*',
                    'fu.uname as observer_name',
                    'dqa.grade as quality_grade',
                    'dqa.has_media',
                    'dqa.has_date',
                    'dqa.has_location',
                    'dqa.is_wild',
                    'dqa.location_accurate',
                    'dqa.needs_id',
                    'dqa.community_id_level',
                    'f.nameId',
                    'f.nameLat',
                    'f.family'
                )
                ->first();

            // Convert stdClass object to array
            $checklist = json_decode(json_encode($checklist), true);

            Log::info('Checklist query result:', ['checklist' => $checklist]); // Debug log

            if (!$checklist) {
                Log::info('Checklist not found for ID: ' . $id); // Debug log
                return response()->json([
                    'success' => false,
                    'message' => 'Checklist tidak ditemukan'
                ], 404);
            }

            // Ambil media dan format URL yang benar
            $medias = DB::table('fobi_checklist_fauna_imgs_kupnes')
                ->where('checklist_id', $id)
                ->get()
                ->map(function($media) {
                    return [
                        'id' => $media->id,
                        'checklist_id' => $media->checklist_id,
                        'fauna_id' => $media->fauna_id,
                        'url' => asset('storage/' . $media->images),
                        'status' => $media->status,
                        'created_at' => $media->created_at,
                        'updated_at' => $media->updated_at
                    ];
                })
                ->toArray();

            // Ambil identifikasi dan format data
            $identifications = DB::table('kupunesia_identifications as ki')
                ->join('fobi_users as u', 'ki.user_id', '=', 'u.id')
                ->leftJoin('fobi_checklist_faunasv2 as fcf', 'ki.taxon_id', '=', 'fcf.fauna_id')
                ->leftJoin(DB::connection('third')->getDatabaseName().'.faunas as f', 'fcf.fauna_id', '=', 'f.id')
                ->where('ki.observation_id', $id)
                ->where('ki.observation_type', 'kupunesia')
                ->select(
                    'ki.*',
                    'u.uname as identifier_name',
                    'f.nameLat as fauna_name',
                    'f.nameId as fauna_name_id',
                    DB::raw('(SELECT COUNT(*) FROM kupunesia_identifications WHERE agrees_with_id = ki.id) as agreement_count')
                )
                ->get()
                ->map(function($identification) {
                    return [
                        'id' => $identification->id,
                        'observation_id' => $identification->observation_id,
                        'user_id' => $identification->user_id,
                        'taxon_id' => $identification->taxon_id,
                        'identifier_name' => $identification->identifier_name,
                        'fauna_name' => $identification->fauna_name,
                        'fauna_name_id' => $identification->fauna_name_id,
                        'comment' => $identification->comment,
                        'agreement_count' => $identification->agreement_count,
                        'created_at' => $identification->created_at,
                        'is_withdrawn' => $identification->is_withdrawn ?? false,
                        'user_agreed' => $identification->user_agreed ?? false
                    ];
                })
                ->toArray();

            $locationVerifications = DB::table('location_verifications')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->get()
                ->toArray();

            $wildStatusVotes = DB::table('wild_status_votes')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->get()
                ->toArray();

            return response()->json([
                'success' => true,
                'data' => [
                    'checklist' => $checklist,
                    'medias' => $medias,
                    'identifications' => $identifications,
                    'location_verifications' => $locationVerifications,
                    'wild_status_votes' => $wildStatusVotes
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching checklist detail: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil detail checklist'
            ], 500);
        }
    }

    public function addIdentification(Request $request, $id)
    {
        try {
            // Log request data untuk debugging
            Log::info('Identification request data:', $request->all());

            $validated = $request->validate([
                'fauna_id' => 'required|integer',
                'source' => 'required|string|in:taxas,faunas',
                'comment' => 'nullable|string|max:500'
            ]);

            // Mulai transaksi database
            DB::beginTransaction();

            try {
                // Cek keberadaan fauna berdasarkan sumber
                if ($validated['source'] === 'taxas') {
                    $fauna = DB::table('taxas')->where('id', $validated['fauna_id'])->first();
                } else {
                    $fauna = DB::connection('third')->table('faunas')->where('id', $validated['fauna_id'])->first();
                }

                if (!$fauna) {
                    throw new \Exception('Data fauna tidak ditemukan');
                }

                $identification = KupunesiaIdentification::create([
                    'observation_id' => $id,
                    'observation_type' => 'kupunesia', // Sesuai kolom di tabel
                    'user_id' => auth()->id(),
                    'taxon_id' => $validated['fauna_id'], // Sesuai kolom di tabel
                    'identification_level' => 'species', // Default value
                    'comment' => $validated['comment'],
                    'agreement_count' => 0, // Default value
                    'is_valid' => 1, // Default value
                    'is_main' => 0, // Default value
                    'is_first' => 0, // Default value
                    'is_withdrawn' => 0, // Default value
                    'user_agreed' => 0 // Default value
                ]);

                DB::commit();

                // Tambahkan data fauna ke response
                $responseData = $identification->toArray();
                $responseData['fauna_name'] = $validated['source'] === 'taxas' ? $fauna->scientific_name : $fauna->nameLat;
                $responseData['fauna_name_id'] = $validated['source'] === 'taxas' ? $fauna->common_name : $fauna->nameId;
                $responseData['identifier_name'] = auth()->user()->name;

                return response()->json([
                    'success' => true,
                    'message' => 'Identifikasi berhasil ditambahkan',
                    'data' => $responseData
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                Log::error('Database error while adding identification: ' . $e->getMessage());
                throw $e;
            }

        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Validation error: ' . json_encode($e->errors()));
            return response()->json([
                'success' => false,
                'message' => 'Data tidak valid',
                'errors' => $e->errors()
            ], 422);

        } catch (\Exception $e) {
            Log::error('Error adding identification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan identifikasi'
            ], 500);
        }
    }

    public function agreeWithIdentification($id, $identificationId)
    {
        try {
            DB::beginTransaction();

            // Log untuk debugging
            \Log::info('Agreement Request:', [
                'observation_id' => $id,
                'identification_id' => $identificationId,
                'user_id' => auth()->id()
            ]);

            // Cek apakah identifikasi ada dan valid
            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->where('observation_id', $id)
                ->first();

            \Log::info('Found Identification:', ['identification' => $identification]);

            if (!$identification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Identifikasi tidak ditemukan'
                ], 404);
            }

            // Cek apakah ini identifikasi user sendiri
            if ($identification->user_id === auth()->id()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tidak bisa menyetujui identifikasi sendiri'
                ], 400);
            }

            // Update identifikasi
            DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->update([
                    'agreement_count' => DB::raw('agreement_count + 1'),
                    'user_agreed' => 1,
                    'agrees_with_id' => auth()->id(),
                    'updated_at' => now()
                ]);

            // Ambil data yang sudah diupdate
            $updatedIdentification = DB::table('kupunesia_identifications as ki')
                ->join('fobi_users as fu', 'ki.user_id', '=', 'fu.id')
                ->join('kupunesia_faunas as kf', 'ki.taxon_id', '=', 'kf.id')
                ->select(
                    'ki.*',
                    'fu.uname as identifier_name',
                    'kf.nameLat as scientific_name',
                    'kf.nameId as cname_species'
                )
                ->where('ki.id', $identificationId)
                ->first();

            \Log::info('Updated Identification:', ['updated' => $updatedIdentification]);

            if (!$updatedIdentification) {
                throw new \Exception('Gagal mengambil data identifikasi yang diupdate');
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Berhasil menyetujui identifikasi',
                'data' => [
                    'id' => $updatedIdentification->id,
                    'user_id' => $updatedIdentification->user_id,
                    'taxon_id' => $updatedIdentification->taxon_id,
                    'scientific_name' => $updatedIdentification->scientific_name,
                    'fauna_name' => $updatedIdentification->scientific_name,
                    'fauna_name_id' => $updatedIdentification->cname_species,
                    'comment' => $updatedIdentification->comment,
                    'agreement_count' => $updatedIdentification->agreement_count,
                    'user_agreed' => true,
                    'identifier_name' => $updatedIdentification->identifier_name,
                    'created_at' => $updatedIdentification->created_at,
                    'updated_at' => $updatedIdentification->updated_at
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Error in agreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menyetujui identifikasi'
            ], 500);
        }
    }

    private function isFirstIdentification($checklistId)
    {
        return DB::table('kupunesia_identifications')
            ->where('observation_id', $checklistId)
            ->where('observation_type', 'kupunesia')
            ->where('agrees_with_id', null)
            ->count() === 0;
    }

    public function withdrawIdentification($id, $identificationId)
    {
        try {
            $userId = auth()->id();

            // Cek apakah identifikasi ada dan milik user yang sedang login
            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->where('observation_id', $id)
                ->where('user_id', $userId)
                ->first();

            if (!$identification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Identifikasi tidak ditemukan atau bukan milik Anda'
                ], 404);
            }

            DB::beginTransaction();

            try {
                // Update status identifikasi menjadi withdrawn
                DB::table('kupunesia_identifications')
                    ->where('id', $identificationId)
                    ->update([
                        'is_withdrawn' => true,
                        'updated_at' => now()
                    ]);

                // Hapus semua persetujuan untuk identifikasi ini
                DB::table('kupunesia_identifications')
                    ->where('agrees_with_id', $identificationId)
                    ->delete();

                // Update quality assessment
                $this->updateQualityAssessment($id);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Identifikasi berhasil ditarik'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error withdrawing identification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menarik identifikasi'
            ], 500);
        }
    }

    public function cancelAgreement($id, $identificationId)
    {
        try {
            DB::beginTransaction();

            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->where('observation_id', $id)
                ->first();

            if (!$identification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Identifikasi tidak ditemukan'
                ], 404);
            }

            // Reset agreement
            DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->update([
                    'agreement_count' => DB::raw('GREATEST(agreement_count - 1, 0)'),
                    'user_agreed' => 0,
                    'agrees_with_id' => null,
                    'updated_at' => now()
                ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Berhasil membatalkan persetujuan'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error canceling agreement: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat membatalkan persetujuan'
            ], 500);
        }
    }

    public function disagreeWithIdentification(Request $request, $id, $identificationId)
    {
        try {
            $request->validate([
                'fauna_id' => 'required|integer',
                'comment' => 'required|string'
            ]);

            $userId = auth()->id();

            // Cek apakah identifikasi yang tidak disetujui ada
            $targetIdentification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->where('observation_id', $id)
                ->first();

            if (!$targetIdentification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Identifikasi tidak ditemukan'
                ], 404);
            }

            DB::beginTransaction();

            try {
                // Tambah identifikasi baru sebagai ketidaksetujuan
                $newIdentificationId = DB::table('kupunesia_identifications')->insertGetId([
                    'observation_id' => $id,
                    'observation_type' => 'kupunesia',
                    'user_id' => $userId,
                    'fauna_id' => $request->fauna_id,
                    'comment' => $request->comment,
                    'disagrees_with_id' => $identificationId,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Update quality assessment
                $this->updateQualityAssessment($id);

                DB::commit();

                // Ambil data identifikasi yang baru dibuat
                $newIdentification = DB::table('kupunesia_identifications as ki')
                    ->join('fobi_users as u', 'ki.user_id', '=', 'u.id')
                    ->join(DB::connection('third')->getDatabaseName().'.faunas as f', 'ki.fauna_id', '=', 'f.id')
                    ->where('ki.id', $newIdentificationId)
                    ->select(
                        'ki.*',
                        'u.uname',
                        'f.nameLat as fauna_name',
                        'f.nameId as fauna_name_id',
                        'u.uname as identifier_name',
                        'u.created_at as identifier_joined_date',
                        DB::raw('(SELECT COUNT(*) FROM kupunesia_identifications WHERE user_id = u.id) as identifier_identification_count'),
                        DB::raw('0 as agreement_count'),
                        DB::raw('false as user_agreed')
                    )
                    ->first();

                return response()->json([
                    'success' => true,
                    'message' => 'Ketidaksetujuan berhasil ditambahkan',
                    'data' => $newIdentification
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error disagreeing with identification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan ketidaksetujuan'
            ], 500);
        }
    }

    public function searchFauna(Request $request)
    {
        try {
            // Validasi parameter pencarian
            $validator = \Validator::make($request->all(), [
                'q' => 'required|string|min:2'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Parameter pencarian tidak valid',
                    'errors' => $validator->errors()
                ], 422);
            }

            $query = $request->get('q');
            $results = [];

            // 1. Cari di tabel faunas (database third)
            $faunas = DB::connection('third')->table('faunas')
                ->where('nameLat', 'LIKE', "%{$query}%")
                ->orWhere('nameId', 'LIKE', "%{$query}%")
                ->select(
                    'id as kupnes_fauna_id',
                    'nameLat',
                    'nameId',
                    'family',
                    DB::raw("'faunas' as source")
                )
                ->take(10)
                ->get();

            // Format hasil pencarian
            $results = $faunas->map(function($item) {
                return [
                    'id' => $item->kupnes_fauna_id,
                    'nameLat' => $item->nameLat,
                    'nameId' => $item->nameId,
                    'family' => $item->family,
                    'source' => $item->source
                ];
            })->toArray();

            return response()->json([
                'success' => true,
                'data' => $results
            ]);

        } catch (\Exception $e) {
            Log::error('Error searching fauna: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mencari fauna'
            ], 500);
        }
    }

    public function getLocationName($latitude, $longitude)
    {
        try {
            if (!$latitude || !$longitude) {
                return 'Lokasi tidak diketahui';
            }

            $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat={$latitude}&lon={$longitude}&zoom=18&addressdetails=1";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Kupunesia Application');

            $response = curl_exec($ch);
            $data = json_decode($response, true);

            if (isset($data['display_name'])) {
                return $data['display_name'];
            }

            return 'Lokasi tidak diketahui';

        } catch (\Exception $e) {
            Log::error('Error getting location name:', [
                'error' => $e->getMessage(),
                'latitude' => $latitude,
                'longitude' => $longitude
            ]);
            return 'Lokasi tidak diketahui';
        }
    }

    public function getUserObservations(Request $request)
    {
        try {
            $userId = auth()->id();
            $perPage = $request->input('per_page', 50);

            $observations = DB::table('fobi_checklists_kupnes as fc')
                ->join('data_quality_assessments_kupnes as dqa', 'fc.id', '=', 'dqa.observation_id')
                ->join('fobi_users as fu', 'fc.fobi_user_id', '=', 'fu.id')
                ->leftJoin(DB::connection('third')->getDatabaseName().'.faunas as f', 'fc.fauna_id', '=', 'f.id')
                ->where('fc.fobi_user_id', $userId)
                ->select(
                    'fc.*',
                    'dqa.grade',
                    'dqa.has_media',
                    'dqa.is_wild',
                    'dqa.location_accurate',
                    'dqa.recent_evidence',
                    'dqa.related_evidence',
                    'dqa.needs_id',
                    'fu.uname as observer_name',
                    'f.nameLat as fauna_name',
                    'f.nameId as fauna_name_id',
                    DB::raw('(SELECT COUNT(DISTINCT user_id) FROM kupunesia_identifications WHERE observation_id = fc.id) as identifications_count')
                )
                ->orderBy('fc.created_at', 'desc')
                ->paginate($perPage);

            // Proses setiap observasi untuk menambahkan media
            foreach ($observations as $observation) {
                $medias = DB::table('fobi_checklist_fauna_imgs_kupnes')
                    ->where('checklist_id', $observation->id)
                    ->get();

                $observation->images = [];
                foreach ($medias as $media) {
                    $observation->images[] = [
                        'id' => $media->id,
                        'url' => asset('storage/' . $media->images)
                    ];
                }

                // Hitung jumlah observasi untuk fauna ini
                $observation->kupunesia_count = DB::table('fobi_checklists_kupnes')
                    ->where('fauna_id', $observation->fauna_id)
                    ->count();
            }

            return response()->json([
                'success' => true,
                'data' => $observations->items(),
                'meta' => [
                    'current_page' => $observations->currentPage(),
                    'per_page' => $observations->perPage(),
                    'total' => $observations->total(),
                    'last_page' => $observations->lastPage()
                ],
                'links' => [
                    'first' => $observations->url(1),
                    'last' => $observations->url($observations->lastPage()),
                    'prev' => $observations->previousPageUrl(),
                    'next' => $observations->nextPageUrl()
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching user observations: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil data observasi pengguna'
            ], 500);
        }
    }

    public function verifyLocation(Request $request, $id)
    {
        try {
            $request->validate([
                'is_accurate' => 'required|boolean',
                'comment' => 'nullable|string'
            ]);

            $userId = auth()->id();

            // Cek apakah sudah pernah memverifikasi
            $existingVerification = DB::table('location_verifications')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->where('user_id', $userId)
                ->first();

            if ($existingVerification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda sudah memverifikasi lokasi ini'
                ], 400);
            }

            DB::beginTransaction();

            try {
                // Simpan verifikasi lokasi
                DB::table('location_verifications')->insert([
                    'observation_id' => $id,
                    'observation_type' => 'kupunesia',
                    'user_id' => $userId,
                    'is_accurate' => $request->is_accurate,
                    'comment' => $request->comment,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Update status verifikasi di quality assessment
                $this->updateLocationAccuracy($id);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Verifikasi lokasi berhasil disimpan'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error verifying location: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memverifikasi lokasi'
            ], 500);
        }
    }

    public function voteWildStatus(Request $request, $id)
    {
        try {
            $request->validate([
                'is_wild' => 'required|boolean',
                'comment' => 'nullable|string'
            ]);

            $userId = auth()->id();

            // Cek apakah sudah pernah memberikan vote
            $existingVote = DB::table('wild_status_votes')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->where('user_id', $userId)
                ->first();

            if ($existingVote) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda sudah memberikan vote untuk status liar ini'
                ], 400);
            }

            DB::beginTransaction();

            try {
                // Simpan vote status liar
                DB::table('wild_status_votes')->insert([
                    'observation_id' => $id,
                    'observation_type' => 'kupunesia',
                    'user_id' => $userId,
                    'is_wild' => $request->is_wild,
                    'comment' => $request->comment,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Update status liar di quality assessment
                $this->updateWildStatus($id);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Vote status liar berhasil disimpan'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error voting wild status: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memberikan vote status liar'
            ], 500);
        }
    }

    private function updateLocationAccuracy($checklistId)
    {
        try {
            $verifications = DB::table('location_verifications')
                ->where('observation_id', $checklistId)
                ->where('observation_type', 'kupunesia')
                ->get();

            $totalVerifications = $verifications->count();
            $accurateCount = $verifications->where('is_accurate', true)->count();

            // Update quality assessment berdasarkan mayoritas vote
            DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $checklistId)
                ->update([
                    'location_accurate' => $totalVerifications > 0 ? ($accurateCount > ($totalVerifications / 2)) : true,
                    'updated_at' => now()
                ]);

        } catch (\Exception $e) {
            Log::error('Error updating location accuracy: ' . $e->getMessage());
            throw $e;
        }
    }

    private function updateWildStatus($checklistId)
    {
        try {
            $votes = DB::table('wild_status_votes')
                ->where('observation_id', $checklistId)
                ->where('observation_type', 'kupunesia')
                ->get();

            $totalVotes = $votes->count();
            $wildCount = $votes->where('is_wild', true)->count();

            // Update quality assessment berdasarkan mayoritas vote
            DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $checklistId)
                ->update([
                    'is_wild' => $totalVotes > 0 ? ($wildCount > ($totalVotes / 2)) : true,
                    'updated_at' => now()
                ]);

        } catch (\Exception $e) {
            Log::error('Error updating wild status: ' . $e->getMessage());
            throw $e;
        }
    }

    public function verifyEvidence(Request $request, $id)
    {
        try {
            $request->validate([
                'is_recent' => 'required|boolean',
                'is_related' => 'required|boolean',
                'comment' => 'nullable|string'
            ]);

            $userId = auth()->id();

            // Cek apakah sudah pernah memverifikasi
            $existingVerification = DB::table('evidence_verifications')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->where('user_id', $userId)
                ->first();

            if ($existingVerification) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda sudah memverifikasi bukti ini'
                ], 400);
            }

            DB::beginTransaction();

            try {
                // Simpan verifikasi bukti
                DB::table('evidence_verifications')->insert([
                    'observation_id' => $id,
                    'observation_type' => 'kupunesia',
                    'user_id' => $userId,
                    'is_recent' => $request->is_recent,
                    'is_related' => $request->is_related,
                    'comment' => $request->comment,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Update status bukti di quality assessment
                $this->updateEvidenceStatus($id);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Verifikasi bukti berhasil disimpan'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error verifying evidence: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memverifikasi bukti'
            ], 500);
        }
    }

    private function updateEvidenceStatus($checklistId)
    {
        try {
            $verifications = DB::table('evidence_verifications')
                ->where('observation_id', $checklistId)
                ->where('observation_type', 'kupunesia')
                ->get();

            $totalVerifications = $verifications->count();
            $recentCount = $verifications->where('is_recent', true)->count();
            $relatedCount = $verifications->where('is_related', true)->count();

            // Update quality assessment berdasarkan mayoritas vote
            DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $checklistId)
                ->update([
                    'recent_evidence' => $totalVerifications > 0 ? ($recentCount > ($totalVerifications / 2)) : true,
                    'related_evidence' => $totalVerifications > 0 ? ($relatedCount > ($totalVerifications / 2)) : true,
                    'updated_at' => now()
                ]);

        } catch (\Exception $e) {
            Log::error('Error updating evidence status: ' . $e->getMessage());
            throw $e;
        }
    }

    public function getStats($id)
    {
        try {
            // Ambil statistik identifikasi
            $identificationStats = DB::table('kupunesia_identifications')
                ->where('observation_id', $id)
                ->where('observation_type', 'kupunesia')
                ->selectRaw('
                    COUNT(DISTINCT CASE WHEN agrees_with_id IS NULL THEN user_id END) as identifier_count,
                    COUNT(DISTINCT CASE WHEN agrees_with_id IS NOT NULL THEN user_id END) as agreeing_users_count,
                    COUNT(CASE WHEN agrees_with_id IS NOT NULL THEN 1 END) as total_agreements
                ')
                ->first();

            // Ambil statistik verifikasi
            $verificationStats = [
                'location' => DB::table('location_verifications')
                    ->where('observation_id', $id)
                    ->where('observation_type', 'kupunesia')
                    ->count(),
                'wild_status' => DB::table('wild_status_votes')
                    ->where('observation_id', $id)
                    ->where('observation_type', 'kupunesia')
                    ->count(),
                'evidence' => DB::table('evidence_verifications')
                    ->where('observation_id', $id)
                    ->where('observation_type', 'kupunesia')
                    ->count()
            ];

            // Ambil quality assessment
            $qualityAssessment = DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $id)
                ->first();

            return response()->json([
                'success' => true,
                'data' => [
                    'identification_stats' => $identificationStats,
                    'verification_stats' => $verificationStats,
                    'quality_assessment' => $qualityAssessment
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting stats: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil statistik'
            ], 500);
        }
    }

    public function getIdentificationHistory($id)
    {
        try {
            $history = DB::table('kupunesia_identifications as ki')
                ->join('fobi_users as u', 'ki.user_id', '=', 'u.id')
                ->join(DB::connection('third')->getDatabaseName().'.faunas as f', 'ki.fauna_id', '=', 'f.id')
                ->where('ki.observation_id', $id)
                ->orderBy('ki.created_at', 'asc')
                ->select(
                    'ki.*',
                    'u.uname as identifier_name',
                    'f.nameLat as fauna_name',
                    'f.nameId as fauna_name_id'
                )
                ->get();

            return response()->json([
                'success' => true,
                'data' => $history
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting identification history: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil riwayat identifikasi'
            ], 500);
        }
    }

    public function addComment(Request $request, $id)
    {
        try {
            $request->validate([
                'comment' => 'required|string',
                'parent_id' => 'nullable|integer'
            ]);

            $userId = auth()->id();

            DB::beginTransaction();

            try {
                // Simpan komentar
                $commentId = DB::table('kupunesia_comments')->insertGetId([
                    'observation_id' => $id,
                    'user_id' => $userId,
                    'parent_id' => $request->parent_id,
                    'comment' => $request->comment,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                // Ambil data komentar yang baru dibuat
                $comment = DB::table('kupunesia_comments as kc')
                    ->join('fobi_users as u', 'kc.user_id', '=', 'u.id')
                    ->where('kc.id', $commentId)
                    ->select(
                        'kc.*',
                        'u.uname as user_name'
                    )
                    ->first();

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Komentar berhasil ditambahkan',
                    'data' => $comment
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error adding comment: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan komentar'
            ], 500);
        }
    }

    public function getComments($id)
    {
        try {
            $comments = DB::table('kupunesia_comments as kc')
                ->join('fobi_users as u', 'kc.user_id', '=', 'u.id')
                ->where('kc.observation_id', $id)
                ->select(
                    'kc.*',
                    'u.uname as user_name'
                )
                ->orderBy('kc.created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $comments
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting comments: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil komentar'
            ], 500);
        }
    }

    public function flagObservation(Request $request, $id)
    {
        try {
            $request->validate([
                'reason' => 'required|string',
                'details' => 'nullable|string'
            ]);

            $userId = auth()->id();

            // Cek apakah sudah pernah melaporkan
            $existingFlag = DB::table('kupunesia_flags')
                ->where('observation_id', $id)
                ->where('user_id', $userId)
                ->first();

            if ($existingFlag) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda sudah melaporkan observasi ini'
                ], 400);
            }

            DB::beginTransaction();

            try {
                // Simpan flag
                DB::table('kupunesia_flags')->insert([
                    'observation_id' => $id,
                    'user_id' => $userId,
                    'reason' => $request->reason,
                    'details' => $request->details,
                    'status' => 'pending',
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Laporan berhasil dikirim'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error flagging observation: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat melaporkan observasi'
            ], 500);
        }
    }

    public function deleteComment($id, $commentId)
    {
        try {
            $userId = auth()->id();

            // Cek apakah komentar ada dan milik user yang login
            $comment = DB::table('kupunesia_comments')
                ->where('id', $commentId)
                ->where('observation_id', $id)
                ->where('user_id', $userId)
                ->first();

            if (!$comment) {
                return response()->json([
                    'success' => false,
                    'message' => 'Komentar tidak ditemukan atau bukan milik Anda'
                ], 404);
            }

            DB::beginTransaction();

            try {
                // Hapus komentar
                DB::table('kupunesia_comments')
                    ->where('id', $commentId)
                    ->delete();

                DB::commit();

                return response()->json([
                    'success' => true,
                    'message' => 'Komentar berhasil dihapus'
                ]);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Error deleting comment: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menghapus komentar'
            ], 500);
        }
    }

    // Akan dilanjutkan dengan method-method lainnya...
}
