<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Tymon\JWTAuth\Facades\JWTAuth;

class FobiObservationApiController extends Controller
{
    public function storeChecklistAndFauna(Request $request)
    {
        try {
            $request->validate([
                'latitude' => 'required|numeric',
                'longitude' => 'required|numeric',
                'tujuan_pengamatan' => 'required|integer',
                'fauna_id.*' => 'required|integer',
                'count.*' => 'required|integer',
                'notes.*' => 'nullable|string',
                'breeding.*' => 'required|boolean',
                'observer' => 'nullable|string',
                'breeding_note.*' => 'nullable|string',
                'breeding_type_id.*' => 'nullable|integer',
                'completed' => 'nullable|integer',
                'start_time' => 'nullable|date_format:H:i',
                'end_time' => 'nullable|date_format:H:i',
                'active' => 'nullable|integer',
                'additional_note' => 'nullable|string',
                'tgl_pengamatan' => 'nullable|date',
                'images.*.*' => 'nullable|file|mimes:jpeg,png,jpg,gif|max:2048',
                'sounds.*.*' => 'nullable|file|mimes:mp3,wav|max:15120',
            ]);

            Log::info('Request data:', $request->all());

            $userId = JWTAuth::parseToken()->authenticate()->id;
            $fobiUser = DB::table('fobi_users')->where('id', $userId)->first();

            if (!$fobiUser) {
                return response()->json(['error' => 'User tidak ditemukan.'], 404);
            }

            $burungnesiaUserId = $fobiUser->burungnesia_user_id;

            DB::transaction(function () use ($request, $userId, $burungnesiaUserId) {
                $checklistId = DB::table('fobi_checklists')->insertGetId([
                    'fobi_user_id' => $userId,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'tujuan_pengamatan' => $request->tujuan_pengamatan,
                    'observer' => $request->observer,
                    'additional_note' => $request->additional_note,
                    'active' => $request->active,
                    'tgl_pengamatan' => $request->tgl_pengamatan,
                    'start_time' => $request->start_time,
                    'end_time' => $request->end_time,
                    'completed' => $request->completed,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // Pastikan data adalah array
                $faunaIds = is_array($request->fauna_id) ? $request->fauna_id : [$request->fauna_id];
                $counts = is_array($request->count) ? $request->count : [$request->count];
                $notes = is_array($request->notes) ? $request->notes : [$request->notes];
                $breedings = is_array($request->breeding) ? $request->breeding : [$request->breeding];
                $breedingNotes = is_array($request->breeding_note) ? $request->breeding_note : [$request->breeding_note];
                $breedingTypeIds = is_array($request->breeding_type_id) ? $request->breeding_type_id : [$request->breeding_type_id];

                foreach ($faunaIds as $index => $faunaId) {
                    DB::table('fobi_checklist_faunasV1')->insert([
                        'checklist_id' => $checklistId,
                        'fauna_id' => $faunaId,
                        'count' => $counts[$index],
                        'notes' => $notes[$index],
                        'breeding' => $breedings[$index],
                        'breeding_note' => $breedingNotes[$index],
                        'breeding_type_id' => $breedingTypeIds[$index],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    if ($request->hasFile("images.$index")) {
                        foreach ($request->file("images.$index") as $imageFile) {
                            $imagePath = $imageFile->store('uploads', 'public');
                            DB::table('fobi_checklist_fauna_imgs')->insert([
                                'checklist_id' => $checklistId,
                                'fauna_id' => $faunaId,
                                'images' => asset('storage/' . $imagePath),
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    }

                    if ($request->hasFile("sounds.$index")) {
                        foreach ($request->file("sounds.$index") as $soundFile) {
                            $soundPath = $soundFile->store('sounds', 'public');
                            $spectrogramPath = preg_replace('/\.(mp3|wav|ogg)$/i', '.png', $soundPath);
                            $command = escapeshellcmd("python " . base_path('storage/app/public/spectrogram.py') . " " . storage_path('app/public/' . $soundPath) . " " . storage_path('app/public/' . $spectrogramPath));
                            shell_exec($command);

                            DB::table('fobi_checklist_sounds')->insert([
                                'checklist_id' => $checklistId,
                                'fauna_id' => $faunaId,
                                'sounds' => asset('storage/' . $soundPath),
                                'spectrogram' => asset('storage/' . $spectrogramPath),
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    }
                }

                $checklistIdSecond = DB::connection('second')->table('checklists')->insertGetId([
                    'user_id' => $burungnesiaUserId,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'tujuan_pengamatan' => $request->tujuan_pengamatan,
                    'observer' => $request->observer,
                    'additional_note' => $request->additional_note,
                    'active' => $request->active,
                    'tgl_pengamatan' => $request->tgl_pengamatan,
                    'start_time' => $request->start_time,
                    'end_time' => $request->end_time,
                    'completed' => $request->completed,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                foreach ($faunaIds as $index => $faunaId) {
                    DB::connection('second')->table('checklist_fauna')->insert([
                        'checklist_id' => $checklistIdSecond,
                        'fauna_id' => $faunaId,
                        'count' => $counts[$index],
                        'notes' => $notes[$index],
                        'breeding' => $breedings[$index],
                        'breeding_note' => $breedingNotes[$index],
                        'breeding_type_id' => $breedingTypeIds[$index],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            });

            return response()->json(['success' => 'Data berhasil diunggah ke kedua database!'], 201);
        } catch (\Exception $e) {
            Log::error('Error uploading data: ' . $e->getMessage());
            return response()->json(['error' => 'Terjadi kesalahan saat mengunggah data.'], 500);
        }
    }

    public function getFaunaId(Request $request)
    {
        try {
            $name = $request->input('name');

            // Coba cari di database second (Burungnesia) terlebih dahulu
            $faunas = DB::connection('second')
                ->table('faunas')
                ->where('nameId', 'like', "%{$name}%")
                ->orWhere('nameLat', 'like', "%{$name}%")
                ->select('id', 'nameId', 'nameLat')
                ->limit(10)
                ->get();

            if ($faunas->isEmpty()) {
                // Jika tidak ditemukan, coba cari di database fobi
                $faunas = DB::table('faunas')
                    ->where('nameId', 'like', "%{$name}%")
                    ->orWhere('nameLat', 'like', "%{$name}%")
                    ->select('id', 'nameId', 'nameLat')
                    ->limit(10)
                    ->get();
            }

            return response()->json([
                'success' => true,
                'data' => $faunas->map(function($fauna) {
                    return [
                        'id' => $fauna->id,
                        'nameId' => $fauna->nameId,
                        'nameLat' => $fauna->nameLat,
                        'displayName' => $fauna->nameId
                    ];
                })
            ]);

        } catch (\Exception $e) {
            Log::error('Error searching fauna: ' . $e->getMessage());

            // Jika terjadi error pada database second, langsung coba database fobi
            try {
                $faunas = DB::table('faunas')
                    ->where('nameId', 'like', "%{$name}%")
                    ->orWhere('nameLat', 'like', "%{$name}%")
                    ->select('id', 'nameId', 'nameLat')
                    ->limit(10)
                    ->get();

                return response()->json([
                    'success' => true,
                    'data' => $faunas->map(function($fauna) {
                        return [
                            'id' => $fauna->id,
                            'nameId' => $fauna->nameId,
                            'nameLat' => $fauna->nameLat,
                            'displayName' => $fauna->nameId
                        ];
                    })
                ]);

            } catch (\Exception $innerE) {
                Log::error('Error searching fauna in both databases: ' . $innerE->getMessage());
                return response()->json([
                    'success' => false,
                    'error' => 'Terjadi kesalahan saat mencari data fauna.'
                ], 500);
            }
        }
    }
    public function generateSpectrogram(Request $request)
    {
        try {
            $request->validate([
                'sounds.*' => 'required|file|mimes:mp3,wav,ogg|max:15120',
            ]);

            $spectrogramUrls = [];

            foreach ($request->file('sounds') as $soundFile) {
                $soundPath = $soundFile->store('sounds', 'public');
                $spectrogramPath = preg_replace('/\.(mp3|wav|ogg)$/i', '.png', $soundPath);

                $command = escapeshellcmd("python " . base_path('storage/app/public/spectrogram.py') . " " . storage_path('app/public/' . $soundPath) . " " . storage_path('app/public/' . $spectrogramPath));
                shell_exec($command);

                $spectrogramUrls[] = asset('storage/' . $spectrogramPath);
            }

            return response()->json(['spectrogramUrls' => $spectrogramUrls], 200);
        } catch (\Exception $e) {
            Log::error('Error generating spectrogram: ' . $e->getMessage());
            return response()->json(['error' => 'Terjadi kesalahan saat membuat spektrogram.'], 500);
        }
    }
}
