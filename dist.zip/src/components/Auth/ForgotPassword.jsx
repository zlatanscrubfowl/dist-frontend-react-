import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { apiFetch } from '../../utils/api';
import './Auth.css';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState({ type: '', message: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: '', message: '' });

    try {
      // Gunakan endpoint yang benar
      const response = await fetch('http://localhost:8000/api/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Email tidak terdaftar');
        }
        throw new Error(data.message || 'Gagal mengirim email reset password');
      }

      setStatus({
        type: 'success',
        message: 'Link reset password telah dikirim ke email Anda'
      });
      setEmail('');

    } catch (err) {
      console.error('Error:', err);
      setStatus({
        type: 'error',
        message: err.message || 'Terjadi kesalahan, silakan coba lagi'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <h2>Lupa Password</h2>
            <p className="auth-subtitle">
              Masukkan email Anda untuk menerima link reset password
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="auth-input"
                placeholder="Masukkan email Anda"
                disabled={loading}
              />
            </div>

            {status.message && (
              <p className={`message ${status.type}`}>
                {status.message}
              </p>
            )}

            <button 
              type="submit" 
              className="auth-button"
              disabled={loading}
            >
              {loading ? 'Mengirim...' : 'Kirim Link Reset'}
            </button>

            <div className="auth-footer">
              <Link to="/login" className="back-to-login">
                ← Kembali ke Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;