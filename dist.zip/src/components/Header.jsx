import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBell, faEnvelope, faUserCircle, faBars, faSearch, faArrowLeft, faArrowRight, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { useUser } from '../context/UserContext'; // Import useUser
import axios from 'axios';
import { apiFetch } from '../utils/api';
import { calculateDistance } from '../utils/geoHelpers';

const Header = ({ onSearch }) => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const { user, setUser } = useUser();
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useState({
        search: '',
        location: '',
        latitude: '',
        longitude: '',
        searchType: 'all',
        boundingbox: null,
        calculatedRadius: null
    });
    const [filterParams, setFilterParams] = useState({
        start_date: '',
        end_date: '',
        grade: '',
        has_media: false,
        media_type: '',
        data_source: ['fobi', 'burungnesia', 'kupunesia']
    });
    const [locationSuggestions, setLocationSuggestions] = useState([]);
    const [isLoadingLocation, setIsLoadingLocation] = useState(false);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
    const toggleSearch = () => setIsSearchOpen(!isSearchOpen);
    const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

    const handleLogout = async () => {
      try {
        await apiFetch('/logout', {
          method: 'POST'
        });
        localStorage.clear();
        setUser(null);
        navigate('/');
      } catch (error) {
        console.error('Logout error:', error);
      }
    };

    const checkUserAuth = () => {
      const token = localStorage.getItem('jwt_token');
      const storedUser = {
        id: localStorage.getItem('user_id'),
        uname: localStorage.getItem('username'),
        totalObservations: localStorage.getItem('totalObservations'),
      };

      if (token && storedUser.id) {
        setUser(storedUser);
      } else {
        setUser(null);
      }
    };

    useEffect(() => {
      checkUserAuth();
    }, [setUser]);

    const handleLocationSearch = async (locationName) => {
      if (!locationName) {
        setLocationSuggestions([]);
        return;
      }
  
      setIsLoadingLocation(true);
      try {
        // Batas koordinat Indonesia
        const viewbox = {
          minLon: 95.0,  // Batas barat
          maxLon: 141.0, // Batas timur
          minLat: -11.0, // Batas selatan
          maxLat: 6.0,   // Batas utara
        };
  
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?` +
          `format=json&` +
          `q=${encodeURIComponent(locationName)}&` +
          `limit=5&` +
          `addressdetails=1&` +
          `bounded=1&` +
          `countrycodes=id&` +
          `viewbox=${viewbox.minLon},${viewbox.minLat},${viewbox.maxLon},${viewbox.maxLat}&` +
          `bounded=1`
        );
        const data = await response.json();
  
        // Filter dan urutkan hasil berdasarkan relevansi dan tipe area
        const filteredData = data
          .filter(item => {
            const lat = parseFloat(item.lat);
            const lon = parseFloat(item.lon);
            return (
              lat >= viewbox.minLat &&
              lat <= viewbox.maxLat &&
              lon >= viewbox.minLon &&
              lon <= viewbox.maxLon
            );
          })
          .map(item => {
            // Hitung radius berdasarkan bounding box
            const bbox = item.boundingbox.map(coord => parseFloat(coord));
            const areaWidth = calculateDistance(bbox[0], bbox[2], bbox[0], bbox[3]);
            const areaHeight = calculateDistance(bbox[0], bbox[2], bbox[1], bbox[2]);
            const radius = Math.max(areaWidth, areaHeight) / 2;
  
            // Tentukan tipe area dan sesuaikan radius minimum
            let minRadius = 1; // km
            if (item.type === 'administrative') {
              if (item.address?.state) minRadius = 5;
              if (item.address?.county) minRadius = 10;
              if (item.address?.region) minRadius = 50;
              if (item.address?.province) minRadius = 100;
            }
  
            return {
              ...item,
              calculatedRadius: Math.max(radius, minRadius)
            };
          })
          .sort((a, b) => {
            // Prioritaskan hasil berdasarkan tipe dan importance
            if (a.type === 'administrative' && b.type !== 'administrative') return -1;
            if (b.type === 'administrative' && a.type !== 'administrative') return 1;
            return b.importance - a.importance;
          });
  
        setLocationSuggestions(filteredData.map(item => ({
          display_name: item.display_name
            .replace(', Indonesia', '')
            .replace(/,([^,]*)$/, ''),
          lat: item.lat,
          lon: item.lon,
          boundingbox: item.boundingbox,
          type: item.type,
          importance: item.importance,
          address: item.address,
          radius: item.calculatedRadius
        })));
      } catch (error) {
        console.error('Error searching location:', error);
      } finally {
        setIsLoadingLocation(false);
      }
    };
  
    const handleLocationSelect = (location) => {
      const lat = parseFloat(location.lat).toFixed(6);
      const lon = parseFloat(location.lon).toFixed(6);
      const bbox = location.boundingbox.map(coord => parseFloat(coord));
  
      setSearchParams({
        ...searchParams,
        location: location.display_name,
        latitude: lat,
        longitude: lon,
        radius: location.radius,
        boundingbox: bbox
      });
  
      setLocationSuggestions([]);
    };
  
    // Fungsi pencarian yang akan mentrigger StatsBar
    const handleSearch = () => {
        if (typeof onSearch === 'function') {
            onSearch({
                ...searchParams,
                data_source: filterParams.data_source,
                has_media: filterParams.has_media,
                media_type: filterParams.media_type,
                start_date: filterParams.start_date,
                end_date: filterParams.end_date,
                grade: filterParams.grade
            });
        }
        setIsSearchOpen(false);
    };

    // Tambahkan fungsi untuk handle filter
    const handleFilter = () => {
        if (typeof onSearch === 'function') {
            onSearch({
                ...searchParams,
                ...filterParams,
                grade: filterParams.grade.toLowerCase(),
                data_source: filterParams.data_source,
                has_media: filterParams.has_media,
                media_type: filterParams.media_type,
                start_date: filterParams.start_date,
                end_date: filterParams.end_date
            });
        }
        setIsSearchOpen(false);
    };

  return (
<header className="fixed top-0 left-0 w-full bg-[#f2f2f2] shadow-md z-[55] h-14 border-b-4 border-[#679995]">
      <div className="container mx-auto px-4 h-full">
        <div className="flex items-center justify-between h-full">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img src="/FOBI.png" alt="Logo" className="h-8" />
          </Link>

          {/* Navigation - Desktop */}
          <nav className="hidden md:block">
            <ul className="flex space-x-6 text-xs mt-7">
              <li><Link to="/" className="hover:text-[#679995] transition-colors">Jelajahi</Link></li>
              <li><Link to="/user-observations" className="hover:text-[#679995] transition-colors">Eksplorasi Saya</Link></li>
              <li><Link to="/bantu-ident" className="hover:text-[#679995] transition-colors">Bantu Ident</Link></li>
              <li><Link to="/community" className="hover:text-[#679995] transition-colors">Komunitas</Link></li>
            </ul>
          </nav>

          {/* User Menu - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Upload Button - Selalu Tampil */}
            <Link 
              to="/pilih-observasi"
              className="bg-[#679995] text-white px-4 py-2 rounded-md hover:bg-[#527b78] text-sm font-medium transition duration-150 ease-in-out"
            >
              Observasi Baru
            </Link>

            {user ? (
              <>
                {/* User Profile dengan Dropdown */}
                <div className="relative">
                  <button 
                    onClick={toggleDropdown}
                    className="flex items-center space-x-2 cursor-pointer"
                  >
                    <FontAwesomeIcon icon={faUserCircle} className="text-xl text-[#679995]" />
                    <div className="flex flex-col">
                      <span className="text-sm font-medium">{user.uname}</span>
                      <span className="text-xs text-gray-600">{user.totalObservations} Observasi</span>
                    </div>
                  </button>

                  {/* Dropdown Menu */}
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                      <button 
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                      >
                        <FontAwesomeIcon icon={faSignOutAlt} className="mr-2" />
                        <span>Logout</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Notifications & Messages */}
                <div className="flex items-center space-x-4">
                  {/* Notifications */}
                  <Link 
                    to="/notifications" 
                    className="relative group"
                  >
                    <FontAwesomeIcon 
                      icon={faBell} 
                      className="text-gray-600 group-hover:text-[#679995] transition-colors text-xl"
                    />
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center group-hover:bg-red-600 transition-colors">
                      2
                    </span>
                  </Link>

                  {/* Messages */}
                  <Link 
                    to="/messages" 
                    className="relative group"
                  >
                    <FontAwesomeIcon 
                      icon={faEnvelope} 
                      className="text-gray-600 group-hover:text-[#679995] transition-colors text-xl"
                    />
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center group-hover:bg-red-600 transition-colors">
                      3
                    </span>
                  </Link>
                </div>
              </>
            ) : (
              <div className="relative">
                <button 
                  onClick={toggleDropdown}
                  className="flex items-center space-x-2 cursor-pointer text-gray-700 hover:text-[#679995]"
                >
                  <FontAwesomeIcon icon={faUserCircle} className="text-xl" />
                  <span>Masuk</span>
                </button>

                {/* Dropdown untuk Guest */}
                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                    <Link 
                      to="/login" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Login
                    </Link>
                    <Link 
                      to="/register" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Daftar
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Mobile Controls */}
          <div className="flex items-center space-x-3 md:hidden">
            <button onClick={toggleSearch} className="p-2 text-gray-600">
              <FontAwesomeIcon icon={faSearch} className="text-xl" />
            </button>
            <button onClick={toggleSidebar} className="p-2 text-gray-600">
              <FontAwesomeIcon icon={faBars} className="text-xl" />
            </button>
          </div>
        </div>
      </div>
      
            {isSearchOpen && (
        <div className="fixed inset-0 z-40 bg-white">
          <div className="p-4">
            <button className="text-gray-600 mb-4" onClick={toggleSearch}>
              <FontAwesomeIcon icon={faArrowLeft} className="text-xl" />
            </button>
            
            <div className="space-y-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Spesies/ genus/ famili"
                  value={searchParams.search}
                  onChange={(e) => setSearchParams({...searchParams, search: e.target.value})}
                  className="w-full p-3 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#679995]"
                />
              </div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Lokasi"
                  value={searchParams.location}
                  onChange={(e) => {
                    setSearchParams({...searchParams, location: e.target.value});
                    handleLocationSearch(e.target.value);
                  }}
                  className="w-full p-3 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#679995]"
                />
                
                {/* Loading indicator */}
                {isLoadingLocation && (
                  <div className="absolute right-3 top-3">
                    <div className="w-5 h-5 border-2 border-[#679995] border-t-transparent rounded-full animate-spin"></div>
                  </div>
                )}
                
                {/* Saran Lokasi */}
                {locationSuggestions.length > 0 && (
                  <div className="absolute z-50 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {locationSuggestions.map((location, index) => (
                      <button
                        key={index}
                        onClick={() => handleLocationSelect(location)}
                        className="w-full p-3 text-left text-sm hover:bg-gray-100 border-b last:border-b-0"
                      >
                        {location.display_name}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Filter Options */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Filter Data</span>
                </div>

                {/* Grade Filter */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">Grade</label>
                  <select
                    value={filterParams.grade}
                    onChange={(e) => setFilterParams({...filterParams, grade: e.target.value})}
                    className="w-full p-2 border rounded text-sm"
                  >
                    <option value="">Semua Grade</option>
                    <option value="research grade">ID Lengkap</option>
                    <option value="needs id">Bantu Iden</option>
                    <option value="low quality id">ID Kurang</option>
                    <option value="casual">Casual</option>
                  </select>
                </div>

                {/* Data Source Filter */}
                <div className="space-y-2">
                  {['fobi', 'burungnesia', 'kupunesia'].map((source) => (
                    <label key={source} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={filterParams.data_source.includes(source)}
                        onChange={(e) => {
                          const newSources = e.target.checked
                            ? [...filterParams.data_source, source]
                            : filterParams.data_source.filter(s => s !== source);
                          setFilterParams({...filterParams, data_source: newSources});
                        }}
                        className="mr-2"
                      />
                      <span className="text-sm text-gray-700 capitalize">{source}</span>
                    </label>
                  ))}
                </div>

                {/* Media Type Filter */}
                <select
                  value={filterParams.media_type}
                  onChange={(e) => setFilterParams({...filterParams, media_type: e.target.value})}
                  className="w-full p-2 border rounded text-sm"
                >
                  <option value="">Semua Media</option>
                  <option value="photo">Foto</option>
                  <option value="audio">Audio</option>
                </select>

                {/* Has Media Checkbox */}
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filterParams.has_media}
                    onChange={(e) => setFilterParams({...filterParams, has_media: e.target.checked})}
                    className="mr-2"
                  />
                  <span className="text-sm">Hanya tampilkan dengan media</span>
                </label>
              </div>

              {/* Tombol Pencarian */}
              <div className="flex space-x-2">
                <button
                  onClick={handleSearch}
                  className="flex-1 bg-[#679995] text-white py-2 px-4 rounded-lg text-sm hover:bg-[#5a8884] transition-colors"
                >
                  <FontAwesomeIcon icon={faArrowRight} className="mr-2" />
                  Cari
                </button>
              </div>

              {/* Filter section */}
              <div className="mt-4">
                {/* Tombol terapkan filter */}
                <button
                  onClick={handleFilter}
                  className="w-full bg-[#679995] text-white py-2 px-4 rounded-lg text-sm hover:bg-[#5a8884] transition-colors mt-4"
                >
                  Terapkan Filter
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={toggleSidebar} />
          <div className="fixed right-0 top-0 bottom-0 w-72 bg-white shadow-xl">
            <div className="p-4">
              {/* User Profile Section */}
              {user ? (
                <div className="flex items-center space-x-3 mb-6 pb-4 border-b">
                  <FontAwesomeIcon icon={faUserCircle} className="text-[#679995] text-3xl" />
                  <div>
                    <p className="font-medium text-gray-700">{user.uname}</p>
                    <p className="text-sm text-gray-500">{user.totalObservations} Observasi</p>
                  </div>
                </div>
              ) : (
                <div className="mb-6 pb-4 border-b space-y-3">
                  <p className="text-gray-600">Guest</p>
                  <div className="space-y-2">
                    <Link 
                      to="/login" 
                      className="block w-full text-center py-2 text-[#679995] border border-[#679995] rounded-lg hover:bg-[#679995] hover:text-white transition-colors"
                    >
                      Login
                    </Link>
                    <Link 
                      to="/register" 
                      className="block w-full text-center py-2 bg-[#679995] text-white rounded-lg hover:bg-[#5a8884] transition-colors"
                    >
                      Daftar
                    </Link>
                  </div>
                </div>
              )}

              {/* Navigation */}
              <nav className="space-y-4">
                <Link to="/" className="flex items-center py-2 text-gray-700 hover:text-[#679995] transition-colors">
                  Jelajahi
                </Link>
                <Link to="/user-observations" className="flex items-center py-2 text-gray-700 hover:text-[#679995] transition-colors">
                  Eksplorasi Saya
                </Link>
                <Link to="/bantu-ident" className="flex items-center py-2 text-gray-700 hover:text-[#679995] transition-colors">
                  Bantu Ident
                </Link>
                <Link to="/community" className="flex items-center py-2 text-gray-700 hover:text-[#679995] transition-colors">
                  Komunitas
                </Link>

                {user && (
                  <>
                    <div className="border-t pt-4 mt-4 space-y-4">
                      <Link to="/notifications" className="flex items-center space-x-3 py-2 text-gray-700 hover:text-[#679995] transition-colors">
                        <FontAwesomeIcon icon={faBell} />
                        <span>Notifikasi</span>
                        <span className="bg-red-500 text-white text-xs rounded-full px-2 ml-auto">2</span>
                      </Link>
                      <Link to="/messages" className="flex items-center space-x-3 py-2 text-gray-700 hover:text-[#679995] transition-colors">
                        <FontAwesomeIcon icon={faEnvelope} />
                        <span>Pesan</span>
                        <span className="bg-red-500 text-white text-xs rounded-full px-2 ml-auto">3</span>
                      </Link>
                      <button 
                        onClick={handleLogout}
                        className="w-full text-left flex items-center space-x-3 py-2 text-gray-700 hover:text-[#679995] transition-colors"
                      >
                        <FontAwesomeIcon icon={faSignOutAlt} />
                        <span>Keluar</span>
                      </button>
                    </div>
                  </>
                )}
              </nav>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
