import React from 'react';
import { Link } from 'react-router-dom';

function TopTaxa({ observationTaxa, identificationTaxa }) {
    const TaxaCard = ({ taxa }) => (
        <Link 
            to={`/taxa/${taxa.id}`}
            className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
        >
            <div className="aspect-square relative">
                {taxa.image_url ? (
                    <img 
                        src={`http://localhost:8000/storage/${taxa.image_url}`}
                        alt={taxa.scientific_name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = '/images/no-image.png';
                        }}
                    />
                ) : (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                        <span className="text-gray-400">Tidak ada gambar</span>
                    </div>
                )}
            </div>
            <div className="p-3">
                <p className="text-sm font-medium text-gray-900 italic">
                    {taxa.scientific_name}
                </p>
                <p className="text-xs text-gray-600">
                    {taxa.genus} | {taxa.family}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                    {taxa.count} {taxa.type === 'observation' ? 'observasi' : 'identifikasi'}
                </p>
            </div>
        </Link>
    );

    return (
        <div className="space-y-6">
            {/* Observasi Section */}
            <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-4">
                    5 Taksa teratas observasi saya
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {observationTaxa.map((taxa, index) => (
                        <TaxaCard 
                            key={`obs-${taxa.id}-${index}`} 
                            taxa={{...taxa, type: 'observation'}} 
                        />
                    ))}
                    {observationTaxa.length === 0 && (
                        <div className="col-span-full text-center text-gray-500 py-4">
                            Belum ada observasi
                        </div>
                    )}
                </div>
            </div>

            {/* Identifikasi Section */}
            <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-4">
                    5 Taksa teratas identifikasi saya
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {identificationTaxa.map((taxa, index) => (
                        <TaxaCard 
                            key={`id-${taxa.id}-${index}`} 
                            taxa={{...taxa, type: 'identification'}} 
                        />
                    ))}
                    {identificationTaxa.length === 0 && (
                        <div className="col-span-full text-center text-gray-500 py-4">
                            Belum ada identifikasi
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default TopTaxa; 