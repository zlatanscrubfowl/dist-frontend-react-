     // src/components/HelpPage.jsx
     import React from 'react';

     const HelpPage = () => {
       return (
         <div className="content">
           <h1>Bantu Ident</h1>
           {/* Konten bantuan identifikasi */}
         </div>
       );
     };

     export default HelpPage;