<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\FobiUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    public function getHomeProfile($id)
    {
        try {
            // Ambil data user
            $user = FobiUser::select(
                'id',
                'fname',
                'lname',
                'uname',
                'email',
                'phone',
                'organization',
                'bio',
                'profile_picture',
                'created_at'
            )->where('id', $id)->first();

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'Pengguna tidak ditemukan'
                ], 404);
            }

            // Hitung total observasi
            $observationCount = DB::table('fobi_checklist_taxas')
                ->where('user_id', $id)
                ->count();

            // Hitung total spesies
            $speciesCount = DB::table('fobi_checklist_taxas')
                ->where('user_id', $id)
                ->distinct('taxa_id')
                ->count();

            // Hitung total identifikasi
            $identificationCount = DB::table('taxa_identifications')
                ->where('user_id', $id)
                ->count();

            // Ambil data followers
            $followers = FobiUser::select('id', 'uname', 'profile_picture')
                ->whereIn('id', function($query) use ($id) {
                    $query->select('follower_id')
                        ->from('user_followers')
                        ->where('user_id', $id);
                        })->take(4)->get();

            // Ambil data following
            $following = FobiUser::select('id', 'uname', 'profile_picture')
                ->whereIn('id', function($query) use ($id) {
                    $query->select('user_id')
                        ->from('user_followers')
                        ->where('follower_id', $id);
                })->take(4)->get();

            return response()->json([
               'success' => true,
               'data' => [
                   'user' => $user,
                   'stats' => [
                       'observasi' => number_format($observationCount),
                       'spesies' => number_format($speciesCount),
                       'identifikasi' => number_format($identificationCount)
                   ],
                   'social' => [
                       'followers' => $followers,
                       'following' => $following,
                       'followerCount' => DB::table('user_followers')->where('user_id', $id)->count(),
                       'followingCount' => DB::table('user_followers')->where('follower_id', $id)->count()
                   ]
               ]
           ]);
        } catch (\Exception $e) {
           \Log::error('Error in getHomeProfile:', [
               'id' => $id,
               'error' => $e->getMessage()
           ]);
            return response()->json([
               'success' => false,
               'message' => 'Terjadi kesalahan saat mengambil data profil'
           ], 500);
       }
   }
   public function getObservations($id, Request $request)
{
    try {
        \Log::info('Received request for observations:', [
            'id' => $id,
            'page' => $request->query('page'),
            'search' => $request->query('search')
        ]);

        $user = DB::table('fobi_users')->find($id);
        if (!$user) {
            \Log::error('User tidak ditemukan:', ['id' => $id]);
            return response()->json([
                'success' => false,
                'message' => 'User tidak ditemukan'
            ], 404);
        }

        // Ambil observasi dari fobi_checklist_taxas
        $fobiObservations = DB::table('fobi_checklist_taxas as fct')
            ->join('taxas as t', 't.id', '=', 'fct.taxa_id')
            ->where('fct.user_id', $id)
            ->select(
                'fct.id',
                'fct.photo_url',
                't.nama_latin',
                't.nama_umum',
                'fct.created_at',
                DB::raw("'fobi' as source")
            );

        // Ambil observasi burung
        $birdObservations = DB::table('fobi_checklists as fc')
            ->join('burungnesia.fauna as bf', 'bf.id', '=', 'fc.fauna_id')
            ->where('fc.fobi_user_id', $id)
            ->select(
                'fc.id',
                'fc.photo_url',
                'bf.nama_latin',
                'bf.nama_umum',
                'fc.created_at',
                DB::raw("'burung' as source")
            );

        // Ambil observasi kupu-kupu
        $butterflyObservations = DB::table('fobi_checklists_kupnes as fck')
            ->join('kupunesia.fauna as kf', 'kf.id', '=', 'fck.fauna_id')
            ->where('fck.fobi_user_id', $id)
            ->select(
                'fck.id',
                'fck.photo_url',
                'kf.nama_latin',
                'kf.nama_umum',
                'fck.created_at',
                DB::raw("'kupu-kupu' as source")
            );

        // Gabungkan semua observasi dan urutkan berdasarkan tanggal
        $allObservations = $fobiObservations
            ->union($birdObservations)
            ->union($butterflyObservations)
            ->orderBy('created_at', 'desc')
            ->paginate(12);
        return response()->json([
           'success' => true,
           'data' => $allObservations
       ]);
    } catch (\Exception $e) {
       return response()->json([
           'success' => false,
           'message' => 'Gagal mengambil data observasi'
       ], 500);
   }
}

public function getIdentifications($id)
{
   try {
       $identifications = DB::table('taxa_identifications as ti')
           ->join('taxas as t', 't.id', '=', 'ti.taxa_id')
           ->join('fobi_users as fu', 'fu.id', '=', 'ti.observer_id')
           ->where('ti.user_id', $id)
           ->select(
               'ti.id',
               'ti.photo_url',
               't.nama_latin',
               't.nama_umum',
               'ti.created_at',
               'fu.uname as observer_username',
               'ti.status',
               'ti.notes'
           )
           ->orderBy('ti.created_at', 'desc')
           ->paginate(12);
        return response()->json([
           'success' => true,
           'data' => $identifications
       ]);
    } catch (\Exception $e) {
       return response()->json([
           'success' => false,
           'message' => 'Gagal mengambil data identifikasi'
       ], 500);
   }
}

public function getSpecies($id)
{
   try {
       $user = FobiUser::findOrFail($id);
        // Ambil spesies dari FOBI
       $fobiSpecies = DB::table('fobi_checklist_taxas as fct')
           ->join('taxas as t', 't.id', '=', 'fct.taxa_id')
           ->where('fct.user_id', $id)
           ->select(
               't.id',
               't.nama_latin',
               't.nama_umum',
               DB::raw('COUNT(*) as jumlah_observasi'),
               DB::raw("'fobi' as source")
           )
           ->groupBy('t.id', 't.nama_latin', 't.nama_umum');
        // Ambil spesies burung
       $birdSpecies = DB::table('fobi_checklists as fc')
           ->join('burungnesia.fauna as bf', 'bf.id', '=', 'fc.fauna_id')
           ->where('fc.fobi_user_id', $id)
           ->select(
               'bf.id',
               'bf.nama_latin',
               'bf.nama_umum',
               DB::raw('COUNT(*) as jumlah_observasi'),
               DB::raw("'burung' as source")
           )
           ->groupBy('bf.id', 'bf.nama_latin', 'bf.nama_umum');
        // Ambil spesies kupu-kupu
       $butterflySpecies = DB::table('fobi_checklists_kupnes as fck')
           ->join('kupunesia.fauna as kf', 'kf.id', '=', 'fck.fauna_id')
           ->where('fck.fobi_user_id', $id)
           ->select(
               'kf.id',
               'kf.nama_latin',
               'kf.nama_umum',
               DB::raw('COUNT(*) as jumlah_observasi'),
               DB::raw("'kupu-kupu' as source")
           )
           ->groupBy('kf.id', 'kf.nama_latin', 'kf.nama_umum');
        // Gabungkan semua spesies
       $allSpecies = $fobiSpecies
           ->union($birdSpecies)
           ->union($butterflySpecies)
           ->orderBy('jumlah_observasi', 'desc')
           ->paginate(12);
        return response()->json([
           'success' => true,
           'data' => $allSpecies
       ]);
    } catch (\Exception $e) {
       return response()->json([
           'success' => false,
           'message' => 'Gagal mengambil data spesies'
       ], 500);
   }
}
public function updateProfile(Request $request)
{
    try {
        $user = auth()->user();

        if ($request->hasFile('profile_picture')) {
            $file = $request->file('profile_picture');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->storeAs('public/profile_pictures', $filename);
            $user->profile_picture = '/storage/profile_pictures/' . $filename;
        }

        if ($request->has('bio')) {
            $user->bio = $request->bio;
        }

        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'Profil berhasil diperbarui'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Gagal memperbarui profil'
        ], 500);
    }
}
public function getUserActivities($id, Request $request)
{
    try {
        $period = $request->query('period', 'year');

        // Set rentang waktu berdasarkan periode
        $endDate = now();
        $startDate = match($period) {
            'week' => now()->subWeek(),
            'month' => now()->subMonth(),
            'year' => now()->subYear(),
            default => now()->subYear(),
        };

        // Aktivitas FOBI
        $fobiActivities = DB::table('fobi_checklist_taxas')
            ->where('user_id', $id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count'),
                DB::raw("'fobi' as source")
            )
            ->groupBy('date');

        // Aktivitas Burungnesia
        $birdActivities = DB::table('fobi_checklists')
            ->where('fobi_user_id', $id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count'),
                DB::raw("'bird' as source")
            )
            ->groupBy('date');

        // Aktivitas Kupunesia
        $butterflyActivities = DB::table('fobi_checklists_kupnes')
            ->where('fobi_user_id', $id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count'),
                DB::raw("'butterfly' as source")
            )
            ->groupBy('date');

        // Aktivitas Identifikasi
        $identificationActivities = DB::table('taxa_identifications')
            ->where('user_id', $id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as count'),
                DB::raw("'identification' as source")
            )
            ->groupBy('date');

        // Gabungkan semua data
        $allActivities = $fobiActivities
            ->union($birdActivities)
            ->union($butterflyActivities)
            ->union($identificationActivities)
            ->get();

        // Format data untuk grafik
        $formattedData = collect($allActivities)
            ->groupBy('date')
            ->map(function ($items) {
                return [
                    'date' => $items->first()->date,
                    'sources' => [
                        'fobi' => $items->where('source', 'fobi')->sum('count'),
                        'bird' => $items->where('source', 'bird')->sum('count'),
                        'butterfly' => $items->where('source', 'butterfly')->sum('count'),
                        'identification' => $items->where('source', 'identification')->sum('count')
                   ]
               ];
           })
           ->values();
        return response()->json([
           'success' => true,
           'data' => $formattedData
       ]);
    } catch (\Exception $e) {
       return response()->json([
           'success' => false,
           'message' => 'Gagal mengambil data aktivitas'
       ], 500);
   }
}
public function getTopTaxa($id)
{
    try {
        // Top 5 observasi - Optimasi query
        $topObservations = DB::table('fobi_checklist_taxas as fct')
            ->select(
                'taxas.id',
                'taxas.scientific_name',
                'taxas.genus',
                'taxas.family',
                DB::raw('MIN(fcm.file_path) as image_url'), // Ambil satu gambar saja
                DB::raw('COUNT(DISTINCT fct.id) as count')
            )
            ->join('taxas', 'fct.taxa_id', '=', 'taxas.id')
            ->leftJoin('fobi_checklist_media as fcm', function($join) {
                $join->on('fcm.checklist_id', '=', 'fct.id')
                     ->whereRaw('fcm.id = (SELECT MIN(id) FROM fobi_checklist_media WHERE checklist_id = fct.id)');
            })
            ->where('fct.user_id', $id)
            ->groupBy('taxas.id', 'taxas.scientific_name', 'taxas.genus', 'taxas.family')
            ->orderByDesc('count')
            ->limit(5)
            ->get();

        // Top 5 Identifikasi - Optimasi query
        $topIdentifications = DB::table('taxa_identifications as ti')
            ->select(
                'taxas.id',
                'taxas.scientific_name',
                'taxas.genus',
                'taxas.family',
                DB::raw('MIN(fcm.file_path) as image_url'), // Ambil satu gambar saja
                DB::raw('COUNT(DISTINCT ti.id) as count')
            )
            ->join('taxas', 'ti.taxon_id', '=', 'taxas.id')
            ->join('fobi_checklist_taxas as fct', 'ti.checklist_id', '=', 'fct.id')
            ->leftJoin('fobi_checklist_media as fcm', function($join) {
                $join->on('fcm.checklist_id', '=', 'fct.id')
                     ->whereRaw('fcm.id = (SELECT MIN(id) FROM fobi_checklist_media WHERE checklist_id = fct.id)');
            })
            ->where('ti.user_id', $id)
            ->groupBy('taxas.id', 'taxas.scientific_name', 'taxas.genus', 'taxas.family')
            ->orderByDesc('count')
            ->limit(5)
            ->get();

        // Cache hasil query selama 5 menit
        $result = [
            'success' => true,
            'data' => [
                'observations' => $topObservations,
                'identifications' => $topIdentifications
            ]
        ];

        return response()->json($result)->header('Cache-Control', 'public, max-age=300');

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Gagal mengambil data taksa teratas'
        ], 500);
    }
}

public function getUserObservations($id, Request $request)
{
    try {
        $user = DB::table('fobi_users')->find($id);
        if (!$user) {
            return response()->json(['success' => false, 'message' => 'User tidak ditemukan'], 404);
        }

        $search = strtolower($request->query('search', ''));
        $searchType = $request->query('search_type', 'all');
        $dateFilter = $request->query('date', '');
        $perPage = $request->query('per_page', 5);
        $page = $request->query('page', 1);
        $isMapRequest = $request->query('map', false);

        // Query untuk observasi FOBI
        $fobiObservations = DB::table('fobi_checklist_taxas as fct')
            ->select([
                DB::raw('DISTINCT fct.id'),
                'fct.scientific_name as nama_latin',
                't.cname_species as nama_umum',
                'fct.latitude',
                'fct.longitude',
                'fct.created_at as observation_date',
                DB::raw('(SELECT file_path FROM fobi_checklist_media WHERE checklist_id = fct.id ORDER BY id ASC LIMIT 1) as photo_url'),
                'fct.family',
                'fct.order as ordo',
                DB::raw("'fobi' as source")
            ])
            ->join('taxas as t', 't.id', '=', 'fct.taxa_id')
            ->where('fct.user_id', $id);

        $allObservations = collect($fobiObservations->get());

        // Cek dan tambahkan data Burungnesia
        if ($user->burungnesia_user_id) {
            try {
                // Query untuk Burungnesia dari tabel FOBI
                $birdObservationsFobi = DB::table('fobi_checklists as fc')
                    ->select([
                        DB::raw('DISTINCT fc.id'),
                        'f.nameLat as nama_latin',
                        'f.nameId as nama_umum',
                        'fc.latitude',
                        'fc.longitude',
                        'fc.tgl_pengamatan as observation_date',
                        DB::raw('(SELECT images FROM fobi_checklist_fauna_imgs WHERE checklist_id = fc.id ORDER BY id ASC LIMIT 1) as photo_url'),
                        'f.family',
                        'of.ordo',
                        DB::raw("'bird' as source")
                    ])
                    ->join('fobi_checklist_faunasV1 as fcf', 'fc.id', '=', 'fcf.checklist_id')
                    ->join('faunas as f', 'fcf.fauna_id', '=', 'f.id')
                    ->leftJoin('order_faunas as of', 'f.family', '=', 'of.famili')
                    ->where('fc.fobi_user_id', $id);

                $allObservations = $allObservations->concat($birdObservationsFobi->get());

                // Query untuk Burungnesia dari database second
                if (DB::connection('second')->getDatabaseName()) {
                    $birdObservationsSecond = DB::connection('second')
                        ->table('checklists as c')
                        ->select([
                            DB::raw('DISTINCT c.id'),
                            'f.nameLat as nama_latin',
                            'f.nameId as nama_umum',
                            'c.latitude',
                            'c.longitude',
                            'c.created_at as observation_date',
                            DB::raw('NULL as photo_url'),
                            'f.family',
                            'of.ordo',
                            DB::raw("'bird' as source")
                        ])
                        ->join('checklist_fauna as cf', 'c.id', '=', 'cf.checklist_id')
                        ->join('faunas as f', 'cf.fauna_id', '=', 'f.id')
                        ->leftJoin('order_faunas as of', 'f.family', '=', 'of.famili')
                        ->where('c.user_id', $user->burungnesia_user_id);

                    $allObservations = $allObservations->concat($birdObservationsSecond->get());
                }
            } catch (\Exception $e) {
                \Log::warning('Error fetching bird observations: ' . $e->getMessage());
            }
        }

        // Cek dan tambahkan data Kupunesia
        if ($user->kupunesia_user_id) {
            try {
                // Query untuk Kupunesia dari tabel FOBI
                $butterflyObservationsFobi = DB::table('fobi_checklists_kupnes as fck')
                    ->select([
                        DB::raw('DISTINCT fck.id'),
                        'f.nameLat as nama_latin',
                        'f.nameId as nama_umum',
                        'fck.latitude',
                        'fck.longitude',
                        'fck.tgl_pengamatan as observation_date',
                        DB::raw('(SELECT images FROM fobi_checklist_fauna_imgs_kupnes WHERE checklist_id = fck.id ORDER BY id ASC LIMIT 1) as photo_url'),
                        'f.family',
                        DB::raw("'butterfly' as source")
                    ])
                    ->join('fobi_checklist_faunasv2 as fcf', 'fck.id', '=', 'fcf.checklist_id')
                    ->join('faunas as f', 'fcf.fauna_id', '=', 'f.id')
                    ->where('fck.fobi_user_id', $id);

                $allObservations = $allObservations->concat($butterflyObservationsFobi->get());

                // Query untuk Kupunesia dari database third
                if (DB::connection('third')->getDatabaseName()) {
                    $butterflyObservationsThird = DB::connection('third')
                        ->table('checklists as c')
                        ->select([
                            DB::raw('DISTINCT c.id'),
                            'f.nameLat as nama_latin',
                            'f.nameId as nama_umum',
                            'c.latitude',
                            'c.longitude',
                            'c.created_at as observation_date',
                            DB::raw('(SELECT images FROM checklist_fauna_imgs WHERE checklist_id = c.id ORDER BY id ASC LIMIT 1) as photo_url'),
                            'f.family',
                            DB::raw("'butterfly' as source")
                        ])
                        ->join('checklist_fauna as cf', 'c.id', '=', 'cf.checklist_id')
                        ->join('faunas as f', 'cf.fauna_id', '=', 'f.id')
                        ->where('c.user_id', $user->kupunesia_user_id);

                    $allObservations = $allObservations->concat($butterflyObservationsThird->get());
                }
            } catch (\Exception $e) {
                \Log::warning('Error fetching butterfly observations: ' . $e->getMessage());
            }
        }

        // Filter berdasarkan pencarian jika bukan request map
        if (!$isMapRequest && ($search || $dateFilter)) {
            $allObservations = $allObservations->filter(function($item) use ($search, $searchType, $dateFilter) {
                // Filter tanggal
                if ($dateFilter) {
                    $itemDate = substr($item->observation_date, 0, 10); // Ambil hanya bagian YYYY-MM-DD
                    if ($itemDate !== $dateFilter) {
                        return false;
                    }
                }

                // Filter pencarian teks
                if ($search) {
                    switch ($searchType) {
                        case 'species':
                            return str_contains(strtolower($item->nama_latin), $search) ||
                                   str_contains(strtolower($item->nama_umum), $search);
                        case 'location':
                            // Implementasi pencarian lokasi jika diperlukan
                            return true;
                        case 'date':
                            return str_contains(strtolower($item->observation_date), $search);
                        default:
                            return str_contains(strtolower($item->nama_latin), $search) ||
                                   str_contains(strtolower($item->nama_umum), $search) ||
                                   str_contains(strtolower($item->observation_date), $search);
                    }
                }

                return true;
            });
        }

        // Urutkan berdasarkan tanggal terbaru
        $allObservations = $allObservations->sortByDesc('observation_date');

        if ($isMapRequest) {
            // Jika request untuk map, kembalikan semua data
            return response()->json([
                'success' => true,
                'data' => $allObservations->values()
            ]);
        }

        // Jika bukan request map, lakukan paginasi untuk tabel
        $total = $allObservations->count();
        $paginatedObservations = $allObservations->forPage($page, $perPage);

        return response()->json([
            'success' => true,
            'data' => [
                'observations' => $paginatedObservations->values(),
                'total' => $total,
                'current_page' => $page,
                'per_page' => $perPage,
                'last_page' => ceil($total / $perPage)
            ]
        ]);

    } catch (\Exception $e) {
        \Log::error('Error in getUserObservations:', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return response()->json([
            'success' => false,
            'message' => 'Gagal mengambil data observasi'
        ], 500);
    }
}

private function getLocationName($latitude, $longitude)
{
    try {
        $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat={$latitude}&lon={$longitude}&zoom=18&addressdetails=1";
        $response = file_get_contents($url, false, stream_context_create([
            'http' => [
                'header' => 'User-Agent: FOBI/1.0'
            ]
        ]));

        $data = json_decode($response);
        return $data->display_name ?? null;
    } catch (\Exception $e) {
        return null;
    }
}

public function getSearchSuggestions(Request $request)
{
    try {
        $query = $request->get('query', '');
        $type = $request->get('type', 'species');

        if (empty($query)) {
            return response()->json([
                'success' => true,
                'data' => []
            ]);
        }

        if ($type === 'species') {
            // Cari di tabel taxas
            $taxaSuggestions = DB::table('taxas')
                ->where(function($q) use ($query) {
                    $q->where('scientific_name', 'LIKE', "%{$query}%")
                      ->orWhere('cname_species', 'LIKE', "%{$query}%");
                })
                ->select(
                    'id',
                    'scientific_name',
                    'cname_species as common_name',
                    DB::raw("'taxa' as type")
                )
                ->take(5);

            // Cari di database burungnesia (second)
            try {
                $birdSuggestions = DB::connection('second')
                    ->table('faunas')
                    ->where(function($q) use ($query) {
                        $q->where('nameLat', 'LIKE', "%{$query}%")
                          ->orWhere('nameId', 'LIKE', "%{$query}%");
                    })
                    ->select(
                        'id',
                        'nameLat as scientific_name',
                        'nameId as common_name',
                        DB::raw("'bird' as type")
                    )
                    ->take(5);

                $taxaSuggestions->union($birdSuggestions);
            } catch (\Exception $e) {
                \Log::error('Error querying bird database: ' . $e->getMessage());
            }

            // Cari di database kupunesia (third)
            try {
                $butterflySuggestions = DB::connection('third')
                    ->table('faunas')
                    ->where(function($q) use ($query) {
                        $q->where('nameLat', 'LIKE', "%{$query}%")
                          ->orWhere('nameId', 'LIKE', "%{$query}%");
                    })
                    ->select(
                        'id',
                        'nameLat as scientific_name',
                        'nameId as common_name',
                        DB::raw("'butterfly' as type")
                    )
                    ->take(5);

                $taxaSuggestions->union($butterflySuggestions);
            } catch (\Exception $e) {
                \Log::error('Error querying butterfly database: ' . $e->getMessage());
            }

            $suggestions = $taxaSuggestions->get();
        } else {
            // Suggestions lokasi dari Nominatim
            $suggestions = $this->getLocationSuggestions($query);
        }

        return response()->json([
            'success' => true,
            'data' => $suggestions
        ]);

    } catch (\Exception $e) {
        \Log::error('Error in getSearchSuggestions: ' . $e->getMessage());
        return response()->json([
            'success' => false,
            'message' => 'Gagal mendapatkan saran pencarian'
        ], 500);
    }
}

private function getLocationSuggestions($query)
{
    try {
        $url = "https://nominatim.openstreetmap.org/search?format=json&q=" . urlencode($query) . "&limit=5";
        $response = file_get_contents($url, false, stream_context_create([
            'http' => ['header' => 'User-Agent: FOBI/1.0']
        ]));

        return collect(json_decode($response))->map(function($item) {
            return [
                'id' => $item->place_id,
                'name' => $item->display_name,
                'lat' => $item->lat,
                'lon' => $item->lon
            ];
        });
    } catch (\Exception $e) {
        return collect([]);
    }
}

public function getGridObservations($id, Request $request)
{
    try {
        $zoom = $request->get('zoom', 5);
        $bounds = json_decode($request->get('bounds'), true);
        $search = $request->get('search');
        $searchType = $request->get('search_type', 'all');
        $dateFilter = $request->get('date');

        // Get observations with filters
        $observations = $this->getUserObservations($id, $request, true);

        // Apply bounds filter
        if ($bounds) {
            $observations = $observations->filter(function($obs) use ($bounds) {
                return $obs->latitude >= $bounds['_southWest']['lat'] &&
                       $obs->latitude <= $bounds['_northEast']['lat'] &&
                       $obs->longitude >= $bounds['_southWest']['lng'] &&
                       $obs->longitude <= $bounds['_northEast']['lng'];
            });
        }

        // Determine if we should show markers or grid
        $showMarkers = $zoom >= 12;

        if ($showMarkers) {
            // Return individual markers for high zoom levels
            return response()->json([
                'success' => true,
                'data' => [
                    'type' => 'markers',
                    'markers' => $observations->values(),
                    'grid' => []
                ]
            ]);
        } else {
            // Calculate grid size based on zoom
            $gridSize = match(true) {
                $zoom >= 10 => 0.05, // ~5km
                $zoom >= 8 => 0.1,   // ~10km
                default => 0.5,      // ~50km
            };

            // Generate grid
            $grid = [];
            foreach ($observations as $obs) {
                $latGrid = floor($obs->latitude / $gridSize) * $gridSize;
                $lonGrid = floor($obs->longitude / $gridSize) * $gridSize;
                $gridKey = "{$latGrid},{$lonGrid}";

                if (!isset($grid[$gridKey])) {
                    $grid[$gridKey] = [
                        'bounds' => [
                            '_southWest' => [
                                'lat' => $latGrid,
                                'lng' => $lonGrid
                            ],
                            '_northEast' => [
                                'lat' => $latGrid + $gridSize,
                                'lng' => $lonGrid + $gridSize
                            ]
                        ],
                        'count' => 0,
                        'observations' => []
                    ];
                }

                $grid[$gridKey]['count']++;
                $grid[$gridKey]['observations'][] = $obs;
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'type' => 'grid',
                    'grid' => array_values($grid),
                    'markers' => []
                ]
            ]);
        }

    } catch (\Exception $e) {
        \Log::error('Error in getGridObservations:', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return response()->json([
            'success' => false,
            'message' => 'Gagal mendapatkan data grid'
        ], 500);
    }
}
}
