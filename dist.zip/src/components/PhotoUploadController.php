<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserUpload;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\Fauna;
use Spatie\Image\Image;
use Spatie\Image\Enums\Fit;

class PhotoUploadController extends Controller
{
    public function uploadPhoto()
    {
        $search = request()->query('search', '');
        $nameId = request()->input('nameId');
        if (!empty($nameId)) {
            $uploads = UserUpload::where('nameId', 'like', '%' . $nameId . '%')->get();
        } else {
            $uploads = UserUpload::all();
        }

        $faunas = Fauna::all(); // Ambil data faunas untuk suggestion
        return view('profile.upload_photo', compact('faunas'));
    }

    public function storePhoto(Request $request)
    {
        $validatedData = $request->validate([
            'photo' => 'required|array',
            'photo.*' => 'file|image|max:15000',
            'nameId' => 'required|string|max:255',
            'location' => 'required|string|max:255',
            'gender' => 'nullable|string|max:255',
            'age' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ]);

        foreach ($request->file('photo') as $file) {
            $timestamp = microtime(true);
            $uuid = Str::uuid();
            $photoFileName = strtolower(str_replace(' ', '_', $request->input('nameId')))
                             . '_' . $timestamp . '_' . $uuid
                             . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('uploads/photo', $photoFileName);

            // Kompresi dan optimasi gambar
            $imagePath = storage_path('app/public/' . $path);
            $image = Image::load($imagePath);
            $fileSize = filesize($imagePath);

            if ($fileSize > 500 * 1024) {
                $image->fit(Fit::Contain, 800, 600)
                    ->quality(90);
            } else {
                $image->fit(Fit::Contain, 800, 600)
                    ->quality(90);
            }

            $image->optimize()->save($imagePath);

            $upload = new UserUpload();
            $upload->file_name = $photoFileName;
            $upload->photo_path = $path;
            $upload->nameId = $request->nameId;
            $upload->location = $request->input('location');
            $upload->gender = $request->input('gender');
            $upload->age = $request->input('age');
            $upload->notes = $request->input('notes');
            $upload->user_id = Auth::id();
            $upload->uname = auth()->user()->fname . ' ' . auth()->user()->lname;
            $upload->is_promoted = false; // Set is_promoted to false by default
            $upload->is_promoted_to_home = false; // Set is_promoted to false by default
            $upload->is_promoted_to_order = false; // Set is_promoted to false by default

            $upload->save();
        }

        return redirect('/profile#media')->with('success', 'Upload foto berhasil dikonfirmasi!');
    }
}
