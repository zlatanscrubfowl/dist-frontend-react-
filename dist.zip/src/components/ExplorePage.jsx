   // ExplorePage.jsx
   import React from 'react';

   const ExplorePage = () => {
     return (
       <div>
         <h1>Eksplorasi Saya</h1>
         {/* Konten halaman eksplorasi */}
       </div>
     );
   };

   export default ExplorePage;