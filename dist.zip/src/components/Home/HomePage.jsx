import React, { useState, useEffect, useCallback } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThLarge, faThList, faMap } from '@fortawesome/free-solid-svg-icons';
import GridView from './GridView';
import ListView from './ListView';
import MapView from './MapView';
import StatsBar from './StatsBar';
import { apiFetch } from '../../utils/api';
import { debounce } from 'lodash';

const HomePage = ({ searchParams, filterParams, onSearch }) => {
  const [view, setView] = useState('grid');
  const [stats, setStats] = useState({
    burungnesia: 0,
    kupunesia: 0,
    observasi: 0,
    fotoAudio: 0,
    spesies: 0,
    kontributor: 0,
  });
  const [markers, setMarkers] = useState([]);

  const debouncedSearch = useCallback(
    debounce((value) => {
      onSearch(value);
    }, 500),
    []
  );

  const fetchStats = async () => {
    const token = localStorage.getItem('jwt_token');
    const cachedStats = localStorage.getItem('cachedStats');

    if (cachedStats) {
      setStats(JSON.parse(cachedStats));
      return;
    }

    try {
      const [
        burungnesiaResponse,
        kupunesiaResponse,
        totalSpeciesResponse,
        totalContributorsResponse
      ] = await Promise.all([
        apiFetch('/burungnesia-count', {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
        apiFetch('/kupunesia-count', {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
        apiFetch('/total-species'),
        apiFetch('/total-contributors')
      ]);

      const burungnesiaData = await burungnesiaResponse.json();
      const kupunesiaData = await kupunesiaResponse.json();
      const totalSpeciesData = await totalSpeciesResponse.json();
      const totalContributorsData = await totalContributorsResponse.json();

      const newStats = {
        burungnesia: burungnesiaData.burungnesiaCount,
        kupunesia: kupunesiaData.kupunesiaCount,
        observasi: burungnesiaData.burungnesiaCount + kupunesiaData.kupunesiaCount,
        spesies: totalSpeciesData.totalSpecies,
        kontributor: totalContributorsData.totalContributors,
        fotoAudio: 0
      };

      setStats(newStats);
      localStorage.setItem('cachedStats', JSON.stringify(newStats));
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  useEffect(() => {
    if (searchParams) {
      console.log('Search params received in HomePage:', searchParams);
    }
  }, [searchParams]);

  const resetStats = () => {
    fetchStats();
  };

  return (
    <div>
      <div className="relative">
        <StatsBar
          stats={stats}
          onSearch={onSearch}
          searchParams={searchParams}
          filterParams={filterParams}
        />
        <div className="flex justify-center md:justify-end md:absolute md:right-4 md:top-30 space-x-1 bg-none p-1 cursor-pointer z-50 text-white">
          <button 
            onClick={() => { setView('map'); resetStats(); }} 
            className={`p-2 ${view === 'map' ? 'bg-[#4a7571]' : 'bg-[#679995]'} hover:bg-gray-300 shadow-inner`}
          >
            <FontAwesomeIcon icon={faMap} className="text-shadow-md" />
          </button>
          <button 
            onClick={() => { setView('grid'); resetStats(); }} 
            className={`p-2 ${view === 'grid' ? 'bg-[#4a7571]' : 'bg-[#679995]'} hover:bg-gray-300 shadow-inner`}
          >
            <FontAwesomeIcon icon={faThLarge} className="text-shadow-md" />
          </button>
          <button 
            onClick={() => { setView('list'); resetStats(); }} 
            className={`p-2 ${view === 'list' ? 'bg-[#4a7571]' : 'bg-[#679995]'} hover:bg-gray-300 shadow-inner`}
          >
            <FontAwesomeIcon icon={faThList} className="text-shadow-md" />
          </button>
        </div>
      </div>

      <div className="mt-0">
        {view === 'grid' && (
          <GridView
            searchParams={searchParams}
            filterParams={filterParams}
          />
        )}
        {view === 'list' && (
          <ListView
            searchParams={searchParams}
            filterParams={filterParams}
          />
        )}
        {view === 'map' && (
          <MapView
            markers={markers}
            setStats={setStats}
            searchParams={searchParams}
            filterParams={filterParams}
          />
        )}
      </div>
    </div>
  );
};

export default HomePage;
