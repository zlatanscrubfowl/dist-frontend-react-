import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, useMap } from 'react-leaflet';
import { useMarkers } from '../../hooks/useMarkers';
import { useMapZoom } from '../../hooks/useMapZoom';
import { useSidebar } from '../../hooks/useSidebar';
import { useGridData } from '../../hooks/useGridData';
import { MapControls } from '../Map/MapControls';
import { Sidebar } from '../Map/Sidebar';
import { SmallGridMarkers, GridRectangles } from '../Map/GridMarkers';
import { defaultMapConfig, redCircleIcon } from '../../utils/mapHelpers';
import 'leaflet/dist/leaflet.css';
import './MapView.css';
import { ZoomHandler } from '../Map/ZoomHandler';
import { calculateZoomLevel } from '../../utils/geoHelpers';

// Optimasi MapController dengan throttling
const MapController = ({ setVisibleBounds, setZoomLevel, setVisibleGrid }) => {
  const map = useMap();
  const updateRef = useRef(null);

  useEffect(() => {
    if (!map) return;

    const updateMapState = () => {
      if (updateRef.current) return;
      
      updateRef.current = requestAnimationFrame(() => {
        const currentZoom = map.getZoom();
        const bounds = map.getBounds();
        
        if (bounds && bounds._southWest && bounds._northEast) {
          setVisibleBounds(bounds);
        }
        
        setZoomLevel(currentZoom);

        // Sesuaikan threshold zoom level
        if (currentZoom > 12) {
          setVisibleGrid('markers');
        } else if (currentZoom > 10) {
          setVisibleGrid('small');
        } else if (currentZoom >= 8) {
          setVisibleGrid('medium');
        } else if (currentZoom >= 6) {
          setVisibleGrid('large');
        } else {
          setVisibleGrid('extraLarge');
        }

        updateRef.current = null;
      });
    };

    map.on('zoomend', updateMapState);
    map.on('moveend', updateMapState);
    map.on('load', updateMapState);

    return () => {
      map.off('zoomend', updateMapState);
      map.off('moveend', updateMapState);
      map.off('load', updateMapState);
      if (updateRef.current) {
        cancelAnimationFrame(updateRef.current);
      }
    };
  }, [map, setVisibleBounds, setZoomLevel, setVisibleGrid]);

  return null;
};

const MapView = ({ searchParams, filterParams, setStats }) => {
  const mapRef = useRef(null);
  const isMobile = window.innerWidth <= 768;

  // Custom Hooks
  const { mapMarkers, filterMarkers } = useMarkers();
  const { gridData, loading, updateGridData } = useGridData();
  const { currentZoom, handleZoom } = useMapZoom();
  const { sidebarData, toggleSidebar, loadMore } = useSidebar();

  const [visibleBounds, setVisibleBounds] = useState(null);
  const [zoomLevel, setZoomLevel] = useState(5);
  const [visibleGrid, setVisibleGrid] = useState('large');

  // Effect untuk update stats ketika grid berubah
  useEffect(() => {
    if (sidebarData.selectedGrid) {
      const gridData = sidebarData.selectedGrid.data || [];
      
      // Hitung stats seperti sebelumnya
      let burungnesiaCount = 0;
      let kupunesiaCount = 0;
      let taxaCount = 0;
      const uniqueSpecies = new Set();
      
      gridData.forEach(item => {
        if (item.source?.includes('burungnesia')) burungnesiaCount++;
        else if (item.source?.includes('kupunesia')) kupunesiaCount++;
        else if (item.source?.includes('taxa')) taxaCount++;
      });

      sidebarData.species.forEach(species => {
        uniqueSpecies.add(`${species.nameLat}_${species.nameId}`);
      });

      setStats({
        burungnesia: burungnesiaCount,
        kupunesia: kupunesiaCount,
        observasi: burungnesiaCount + kupunesiaCount + taxaCount,
        spesies: uniqueSpecies.size,
        kontributor: gridData.length
      });
    }
  }, [sidebarData.selectedGrid, sidebarData.species, setStats]);

  // Effect untuk update grid data dengan throttling
  useEffect(() => {
    const filteredMarkers = filterMarkers(mapMarkers, filterParams, searchParams);
    if (filteredMarkers?.length > 0 && visibleBounds) {
      updateGridData(filteredMarkers, zoomLevel, visibleBounds);
    }
  }, [mapMarkers, filterParams, searchParams, visibleBounds, zoomLevel, filterMarkers, updateGridData]);

  // Handler untuk map creation dengan ctrl/meta zoom
  const handleMapCreated = (map) => {
    mapRef.current = map;
    
    // Disable default scroll zoom
    map.scrollWheelZoom.disable();

    // Enable scroll zoom dengan ctrl/meta key
    const handleWheel = (e) => {
      if (e.ctrlKey || e.metaKey) {
        map.scrollWheelZoom.enable();
      } else {
        map.scrollWheelZoom.disable();
      }
    };

    map.getContainer().addEventListener('wheel', handleWheel);
    map.on('zoom', handleZoom);

    return () => {
      map.getContainer().removeEventListener('wheel', handleWheel);
      map.off('zoom', handleZoom);
    };
  };

  useEffect(() => {
    if (searchParams?.latitude && searchParams?.longitude) {
      const map = mapRef.current;
      if (map) {
        if (searchParams.boundingbox) {
          // Jika ada bounding box, gunakan fitBounds
          const bounds = [
            [searchParams.boundingbox[0], searchParams.boundingbox[2]],
            [searchParams.boundingbox[1], searchParams.boundingbox[3]]
          ];
          map.fitBounds(bounds, {
            padding: [50, 50],
            maxZoom: 12
          });
        } else {
          // Fallback ke setView jika tidak ada bounding box
          const zoomLevel = calculateZoomLevel(searchParams.calculatedRadius || searchParams.radius);
          map.setView(
            [searchParams.latitude, searchParams.longitude],
            zoomLevel
          );
        }
      }
    }
  }, [searchParams?.latitude, searchParams?.longitude, searchParams?.boundingbox, searchParams?.calculatedRadius]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[70vh] bg-gray-50">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 border-2 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-gray-600">Memuat peta...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row">
      <MapContainer
        {...defaultMapConfig}
        className={`h-[70vh] ${sidebarData.isOpen ? 'md:w-3/4 w-full' : 'w-full'}`}
        scrollWheelZoom={isMobile}
        whenCreated={handleMapCreated}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        <MapController 
          setVisibleBounds={setVisibleBounds}
          setZoomLevel={setZoomLevel}
          setVisibleGrid={setVisibleGrid}
        />

        <ZoomHandler 
          gridData={gridData}
          setVisibleGrid={setVisibleGrid}
          isMobile={isMobile}
        />

        <MapControls />

        {visibleGrid === 'markers' ? (
          <SmallGridMarkers 
            markers={mapMarkers} 
            icon={redCircleIcon}
            bounds={visibleBounds}
          />
        ) : (
          <GridRectangles 
            grid={gridData.tiles} 
            onGridClick={toggleSidebar}
            bounds={visibleBounds}
          />
        )}
      </MapContainer>

      {sidebarData.isOpen && (
        <Sidebar
          data={sidebarData}
          onClose={() => toggleSidebar()}
          onLoadMore={loadMore}
        />
      )}
    </div>
  );
};

export default React.memo(MapView);
