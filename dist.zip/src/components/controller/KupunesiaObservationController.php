<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Validation\Rule;

class KupunesiaObservationController extends Controller
{
    public function getChecklistDetail($id)
    {
        try {
            $userId = JWTAuth::user()->id;

            $checklist = DB::table('fobi_checklists_kupnes as fck')
                ->join('data_quality_assessments_kupnes as dqa', 'fck.id', '=', 'dqa.observation_id')
                ->join('fobi_users as fu', 'fck.fobi_user_id', '=', 'fu.id')
                ->join('faunas_kupnes as fk', 'fck.fauna_id', '=', 'fk.id')
                ->where('fck.id', $id)
                ->select(
                    'fck.*',
                    'dqa.grade',
                    'dqa.has_date',
                    'dqa.has_location',
                    'dqa.has_media',
                    'dqa.is_wild',
                    'dqa.location_accurate',
                    'dqa.recent_evidence',
                    'dqa.related_evidence',
                    'fu.uname as observer_name',
                    'fk.scientific_name',
                    'fk.iucn_red_list_category',
                    'fk.class',
                    'fk.order',
                    'fk.family',
                    'fk.genus',
                    'fk.species'
                )
                ->first();

            if (!$checklist) {
                return response()->json([
                    'success' => false,
                    'message' => 'Checklist tidak ditemukan'
                ], 404);
            }

            // Ambil media
            $medias = DB::table('kupunesia_checklist_media')
                ->where('checklist_id', $id)
                ->select(
                    'id',
                    'media_type',
                    DB::raw("CONCAT('" . asset('storage') . "/', file_path) as url")
                )
                ->get();

            // Ambil identifikasi
            $identifications = DB::table('kupunesia_identifications as ki')
                ->join('fobi_users as fu', 'ki.user_id', '=', 'fu.id')
                ->join('faunas_kupnes as fk', 'ki.taxon_id', '=', 'fk.id')
                ->where('ki.observation_id', $id)
                ->whereNull('ki.deleted_at')
                ->select(
                    'ki.*',
                    'fu.uname as identifier_name',
                    'fk.scientific_name',
                    DB::raw("CASE WHEN ki.photo_path IS NOT NULL
                        THEN CONCAT('" . asset('storage') . "/', ki.photo_path)
                        ELSE NULL END as photo_url")
                )
                ->orderBy('ki.created_at', 'desc')
                ->get();

            // Ambil komentar
            $comments = DB::table('kupunesia_comments as kc')
                ->join('fobi_users as fu', 'kc.user_id', '=', 'fu.id')
                ->where('kc.observation_id', $id)
                ->select(
                    'kc.*',
                    'fu.uname as commenter_name'
                )
                ->orderBy('kc.created_at', 'desc')
                ->get();

            // Ambil verifikasi lokasi
            $locationVerifications = DB::table('location_verifications')
                ->where('observation_id', $id)
                ->count();

            return response()->json([
                'success' => true,
                'data' => [
                    'checklist' => $checklist,
                    'medias' => $medias,
                    'identifications' => $identifications,
                    'comments' => $comments,
                    'location_verifications' => $locationVerifications
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getChecklistDetail: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil detail checklist'
            ], 500);
        }
    }



    private function getIdentificationsWithPhotos($observationId)
    {
        return DB::table('kupunesia_identifications as ki')
            ->join('fobi_users as u', 'ki.user_id', '=', 'u.id')
            ->join('faunas_kupnes as fk', 'ki.taxon_id', '=', 'fk.id')
            ->where('ki.observation_id', $observationId)
            ->whereNull('ki.deleted_at')
            ->select(
                'ki.*',
                'u.uname as identifier_name',
                'fk.scientific_name',
                DB::raw("CASE WHEN ki.photo_path IS NOT NULL
                    THEN CONCAT('" . asset('storage') . "/', ki.photo_path)
                    ELSE NULL END as photo_url")
            )
            ->orderBy('ki.created_at', 'desc')
            ->get();
    }

    private function updateChecklistTaxon($observationId)
    {
        try {
            // Ambil identifikasi dengan persetujuan terbanyak
            $mostAgreedIdentification = DB::table('kupunesia_identifications as ki')
                ->select(
                    'ki.taxon_id',
                    'fk.scientific_name',
                    'fk.iucn_red_list_category',
                    'fk.class',
                    'fk.order',
                    'fk.family',
                    'fk.genus',
                    'fk.species',
                    DB::raw('COUNT(ki2.id) as agreement_count')
                )
                ->join('faunas_kupnes as fk', 'ki.taxon_id', '=', 'fk.id')
                ->leftJoin('kupunesia_identifications as ki2', function($join) {
                    $join->on('ki.id', '=', 'ki2.agrees_with_id')
                        ->where('ki2.is_agreed', '=', true);
                })
                ->where('ki.observation_id', $observationId)
                ->whereNull('ki.deleted_at')
                ->where('ki.is_withdrawn', 0)
                ->groupBy('ki.taxon_id', 'fk.scientific_name', 'fk.iucn_red_list_category',
                         'fk.class', 'fk.order', 'fk.family', 'fk.genus', 'fk.species')
                ->orderBy('agreement_count', 'desc')
                ->first();

            if ($mostAgreedIdentification) {
                // Update checklist dengan taxon yang paling banyak disetujui
                DB::table('fobi_checklists_kupnes')
                    ->where('id', $observationId)
                    ->update([
                        'fauna_id' => $mostAgreedIdentification->taxon_id,
                        'scientific_name' => $mostAgreedIdentification->scientific_name,
                        'class' => $mostAgreedIdentification->class,
                        'order' => $mostAgreedIdentification->order,
                        'family' => $mostAgreedIdentification->family,
                        'genus' => $mostAgreedIdentification->genus,
                        'species' => $mostAgreedIdentification->species,
                        'iucn_status' => $mostAgreedIdentification->iucn_red_list_category,
                        'updated_at' => now()
                    ]);
            }

        } catch (\Exception $e) {
            Log::error('Error in updateChecklistTaxon: ' . $e->getMessage());
            throw $e;
        }
    }

    private function evaluateAndUpdateGrade($assessment, $agreementCount)
    {
        try {
            $oldGrade = $assessment->grade;

            // Update quality assessment
            DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $assessment->observation_id)
                ->update([
                    'grade' => $this->determineGrade($assessment, $agreementCount),
                    'updated_at' => now()
                ]);

            // Jika mencapai research grade, update IUCN status
            if ($oldGrade !== 'research grade' && $this->meetsResearchGradeCriteria($assessment, $agreementCount)) {
                $approvedTaxa = DB::table('kupunesia_identifications as ki')
                    ->join('faunas_kupnes as fk', 'ki.taxon_id', '=', 'fk.id')
                    ->where('ki.observation_id', $assessment->observation_id)
                    ->whereNull('ki.deleted_at')
                    ->where('ki.is_withdrawn', 0)
                    ->where(function($query) {
                        $query->where('ki.is_agreed', 1)
                              ->orWhere('ki.user_agreed', 1);
                    })
                    ->select('fk.iucn_red_list_category')
                    ->first();

                if ($approvedTaxa && $approvedTaxa->iucn_red_list_category) {
                    DB::table('fobi_checklists_kupnes')
                        ->where('id', $assessment->observation_id)
                        ->update([
                            'iucn_status' => $approvedTaxa->iucn_red_list_category
                        ]);
                }
            }

            Log::info('Grade evaluation result:', [
                'observation_id' => $assessment->observation_id,
                'old_grade' => $oldGrade,
                'new_grade' => $this->determineGrade($assessment, $agreementCount),
                'agreement_count' => $agreementCount
            ]);

        } catch (\Exception $e) {
            Log::error('Error in evaluateAndUpdateGrade:', [
                'error' => $e->getMessage(),
                'observation_id' => $assessment->observation_id ?? null
            ]);
            throw $e;
        }
    }

    private function meetsResearchGradeCriteria($assessment, $agreementCount)
    {
        return $assessment->has_date &&
               $assessment->has_location &&
               $assessment->has_media &&
               $agreementCount >= 2 &&
               $assessment->is_wild === true &&
               $assessment->location_accurate === true &&
               $assessment->recent_evidence === true &&
               $assessment->related_evidence === true;
    }

    private function meetsNeedsIdCriteria($assessment)
    {
        return $assessment->has_date &&
               $assessment->has_location &&
               $assessment->has_media;
    }

    public function verifyLocation(Request $request, $id)
    {
        $request->validate([
            'is_accurate' => 'required|boolean',
            'comment' => 'nullable|string|max:500'
        ]);

        try {
            DB::beginTransaction();
            
            $userId = JWTAuth::user()->id;
            
            // Cek apakah user sudah pernah memverifikasi
            $existingVerification = DB::table('location_verifications')
                ->where('observation_id', $id)
                ->where('user_id', $userId)
                ->first();

            if ($existingVerification) {
                throw new \Exception('Anda sudah memverifikasi lokasi ini sebelumnya');
            }

            // Simpan verifikasi lokasi
            DB::table('location_verifications')->insert([
                'observation_id' => $id,
                'user_id' => $userId,
                'is_accurate' => $request->is_accurate,
                'comment' => $request->comment,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Hitung total verifikasi akurat
            $accurateCount = DB::table('location_verifications')
                ->where('observation_id', $id)
                ->where('is_accurate', true)
                ->count();

            // Update quality assessment
            DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $id)
                ->update([
                    'location_accurate' => ($accurateCount >= 2),
                    'updated_at' => now()
                ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Verifikasi lokasi berhasil ditambahkan'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in verifyLocation: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function addComment(Request $request, $id)
    {
        $request->validate([
            'comment' => 'required|string|max:1000'
        ]);

        try {
            DB::beginTransaction();

            $userId = JWTAuth::user()->id;

            // Simpan komentar
            $commentId = DB::table('kupunesia_comments')->insertGetId([
                'observation_id' => $id,
                'user_id' => $userId,
                'comment' => $request->comment,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Ambil data komentar yang baru dibuat
            $newComment = DB::table('kupunesia_comments as kc')
                ->join('fobi_users as fu', 'kc.user_id', '=', 'fu.id')
                ->where('kc.id', $commentId)
                ->select(
                    'kc.*',
                    'fu.uname as commenter_name'
                )
                ->first();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Komentar berhasil ditambahkan',
                'data' => $newComment
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in addComment: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan komentar'
            ], 500);
        }
    }

    public function deleteComment($id, $commentId)
    {
        try {
            $userId = JWTAuth::user()->id;

            // Cek apakah komentar milik user
            $comment = DB::table('kupunesia_comments')
                ->where('id', $commentId)
                ->where('user_id', $userId)
                ->first();

            if (!$comment) {
                throw new \Exception('Komentar tidak ditemukan atau bukan milik Anda');
            }

            // Hapus komentar
            DB::table('kupunesia_comments')
                ->where('id', $commentId)
                ->delete();

            return response()->json([
                'success' => true,
                'message' => 'Komentar berhasil dihapus'
            ]);

        } catch (\Exception $e) {
            Log::error('Error in deleteComment: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getLocationName($id)
    {
        try {
            $checklist = DB::table('fobi_checklists_kupnes')
                ->where('id', $id)
                ->select('latitude', 'longitude')
                ->first();

            if (!$checklist) {
                throw new \Exception('Checklist tidak ditemukan');
            }

            $response = Http::get('https://nominatim.openstreetmap.org/reverse', [
                'format' => 'json',
                'lat' => $checklist->latitude,
                'lon' => $checklist->longitude,
                'zoom' => 18,
                'addressdetails' => 1
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return response()->json([
                    'success' => true,
                    'data' => [
                        'display_name' => $data['display_name'] ?? 'Lokasi tidak diketahui',
                        'address' => $data['address'] ?? null
                    ]
                ]);
            }

            throw new \Exception('Gagal mendapatkan nama lokasi');

        } catch (\Exception $e) {
            Log::error('Error in getLocationName: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Gagal mendapatkan nama lokasi'
            ], 500);
        }
    }

    private function determineGrade($assessment, $agreementCount)
    {
        if ($this->meetsResearchGradeCriteria($assessment, $agreementCount)) {
            return 'research grade';
        } else if ($this->meetsNeedsIdCriteria($assessment)) {
            return 'needs ID';
        }
        return 'casual';
    }

    public function addIdentification(Request $request, $checklistId)
    {
        $request->validate([
            'taxon_id' => 'required|exists:faunas_kupnes,id',
            'identification_level' => 'required|string',
            'comment' => 'nullable|string',
            'photo' => 'nullable|image|max:2048'
        ]);

        try {
            DB::beginTransaction();

            $user = JWTAuth::user();
            $photoPath = null;

            if ($request->hasFile('photo')) {
                $photoPath = $request->file('photo')->store('kupunesia/identification-photos', 'public');
            }

            // Simpan identifikasi baru
            $identificationId = DB::table('kupunesia_identifications')->insertGetId([
                'observation_id' => $checklistId,
                'user_id' => $user->id,
                'taxon_id' => $request->taxon_id,
                'identification_level' => $request->identification_level,
                'comment' => $request->comment,
                'photo_path' => $photoPath,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Update quality assessment
            $this->updateQualityAssessment($checklistId);

            DB::commit();

            // Ambil data identifikasi yang baru dibuat
            $newIdentification = DB::table('kupunesia_identifications as ki')
                ->join('fobi_users as fu', 'ki.user_id', '=', 'fu.id')
                ->join('faunas_kupnes as fk', 'ki.taxon_id', '=', 'fk.id')
                ->where('ki.id', $identificationId)
                ->select(
                    'ki.*',
                    'fu.uname as identifier_name',
                    'fk.scientific_name',
                    DB::raw("CASE WHEN ki.photo_path IS NOT NULL
                        THEN CONCAT('" . asset('storage') . "/', ki.photo_path)
                        ELSE NULL END as photo_url")
                )
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditambahkan',
                'data' => $newIdentification
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in addIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan identifikasi'
            ], 500);
        }
    }

    public function agreeWithIdentification($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            $user = JWTAuth::user();
            
            // Cek apakah identifikasi ada
            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan');
            }

            // Cek apakah user sudah pernah menyetujui identifikasi ini
            $existingAgreement = DB::table('kupunesia_identifications')
                ->where('observation_id', $checklistId)
                ->where('user_id', $user->id)
                ->where('agrees_with_id', $identificationId)
                ->first();

            if ($existingAgreement) {
                throw new \Exception('Anda sudah menyetujui identifikasi ini');
            }

            // Simpan persetujuan
            DB::table('kupunesia_identifications')->insert([
                'observation_id' => $checklistId,
                'user_id' => $user->id,
                'agrees_with_id' => $identificationId,
                'taxon_id' => $identification->taxon_id,
                'identification_level' => $identification->identification_level,
                'is_agreed' => true,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Update quality assessment
            $this->updateQualityAssessment($checklistId);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Berhasil menyetujui identifikasi'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in agreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function withdrawIdentification($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Cek apakah identifikasi milik user
            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->where('user_id', $user->id)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan atau bukan milik Anda');
            }

            // Tarik identifikasi
            DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->update([
                    'is_withdrawn' => true,
                    'updated_at' => now()
                ]);

            // Hapus semua persetujuan terkait
            DB::table('kupunesia_identifications')
                ->where('agrees_with_id', $identificationId)
                ->delete();

            // Update quality assessment
            $this->updateQualityAssessment($checklistId);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditarik'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in withdrawIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function disagreeWithIdentification(Request $request, $checklistId, $identificationId)
    {
        $request->validate([
            'comment' => 'required|string|max:500',
            'taxon_id' => 'required|exists:faunas_kupnes,id'
        ]);

        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Cek apakah identifikasi ada
            $identification = DB::table('kupunesia_identifications')
                ->where('id', $identificationId)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan');
            }

            // Cek apakah user sudah pernah tidak setuju dengan identifikasi ini
            $existingDisagreement = DB::table('kupunesia_identifications')
                ->where('observation_id', $checklistId)
                ->where('user_id', $user->id)
                ->where('disagrees_with_id', $identificationId)
                ->first();

            if ($existingDisagreement) {
                throw new \Exception('Anda sudah pernah tidak menyetujui identifikasi ini');
            }

            // Simpan ketidaksetujuan dengan identifikasi baru
            DB::table('kupunesia_identifications')->insert([
                'observation_id' => $checklistId,
                'user_id' => $user->id,
                'taxon_id' => $request->taxon_id,
                'disagrees_with_id' => $identificationId,
                'comment' => $request->comment,
                'is_disagreement' => true,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Update quality assessment
            $this->updateQualityAssessment($checklistId);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Berhasil menambahkan ketidaksetujuan'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in disagreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function cancelAgreement($checklistId, $identificationId)
    {
        try {
            DB::beginTransaction();

            $user = JWTAuth::user();

            // Cek apakah persetujuan ada
            $agreement = DB::table('kupunesia_identifications')
                ->where('observation_id', $checklistId)
                ->where('user_id', $user->id)
                ->where('agrees_with_id', $identificationId)
                ->first();

            if (!$agreement) {
                throw new \Exception('Persetujuan tidak ditemukan');
            }

            // Hapus persetujuan
            DB::table('kupunesia_identifications')
                ->where('id', $agreement->id)
                ->delete();

            // Update quality assessment
            $this->updateQualityAssessment($checklistId);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Persetujuan berhasil dibatalkan'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in cancelAgreement: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    private function updateQualityAssessment($checklistId)
    {
        try {
            // Hitung total identifikasi dan persetujuan
            $identificationStats = DB::table('kupunesia_identifications')
                ->where('observation_id', $checklistId)
                ->whereNull('deleted_at')
                ->where('is_withdrawn', 0)
                ->selectRaw('
                    COUNT(*) as total_identifications,
                    SUM(CASE WHEN is_agreed = 1 THEN 1 ELSE 0 END) as agreement_count
                ')
                ->first();

            // Ambil atau buat assessment
            $assessment = DB::table('data_quality_assessments_kupnes')
                ->where('observation_id', $checklistId)
                ->first();

            if (!$assessment) {
                // Buat assessment baru jika belum ada
                DB::table('data_quality_assessments_kupnes')->insert([
                    'observation_id' => $checklistId,
                    'grade' => 'needs ID',
                    'has_date' => true,
                    'has_location' => true,
                    'has_media' => true,
                    'is_wild' => true,
                    'location_accurate' => true,
                    'recent_evidence' => true,
                    'related_evidence' => true,
                    'identification_count' => $identificationStats->total_identifications,
                    'agreement_count' => $identificationStats->agreement_count,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            } else {
                // Update assessment yang sudah ada
                DB::table('data_quality_assessments_kupnes')
                    ->where('observation_id', $checklistId)
                    ->update([
                        'identification_count' => $identificationStats->total_identifications,
                        'agreement_count' => $identificationStats->agreement_count,
                        'grade' => $this->determineGrade($assessment, $identificationStats->agreement_count),
                        'updated_at' => now()
                    ]);
            }

            return true;

        } catch (\Exception $e) {
            Log::error('Error in updateQualityAssessment: ' . $e->getMessage());
            throw $e;
        }
    }
}