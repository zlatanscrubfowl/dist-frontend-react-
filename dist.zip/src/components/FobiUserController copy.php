<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\FobiUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyEmail;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class FobiUserController extends Controller
{
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'fname' => 'required|max:20',
            'lname' => 'required|max:20',
            'email' => 'required|email|max:50',
            'uname' => 'required|max:50|unique:users',
            'password' => 'required|min:6',
            'phone' => 'required|max:14',
            'organization' => 'required|max:50',
            'burungnesia_email' => 'nullable|email',
            'kupunesia_email' => 'nullable|email',
        ]);

        $burungnesiaUserId = null;
        $kupunesiaUserId = null;

        if ($request->burungnesia_email) {
            $burungnesiaUser = DB::connection('second')->table('users')->where('email', $request->burungnesia_email)->first();
            if ($burungnesiaUser) {
                $burungnesiaUserId = $burungnesiaUser->id;
            }
        }

        if ($request->kupunesia_email) {
            $kupunesiaUser = DB::connection('third')->table('users')->where('email', $request->kupunesia_email)->first();
            if ($kupunesiaUser) {
                $kupunesiaUserId = $kupunesiaUser->id;
            }
        }

        $user = FobiUser::create([
            'fname' => $request->fname,
            'lname' => $request->lname,
            'email' => $request->email,
            'burungnesia_email' => $request->burungnesia_email,
            'kupunesia_email' => $request->kupunesia_email,
            'uname' => $request->uname,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'organization' => $request->organization,
            'ip_addr' => $request->ip(),
            'level' => 1,
            'is_approved' => 0,
            'burungnesia_user_id' => $burungnesiaUserId,
            'kupunesia_user_id' => $kupunesiaUserId,
            'email_verification_token' => Str::random(60),
            'burungnesia_email_verification_token' => $request->burungnesia_email ? Str::random(60) : null,
            'kupunesia_email_verification_token' => $request->kupunesia_email ? Str::random(60) : null,
        ]);

        Mail::to($user->email)->send(new VerifyEmail($user, 'email_verification_token'));

        if ($request->burungnesia_email) {
            Mail::to($request->burungnesia_email)->send(new VerifyEmail($user, 'burungnesia_email_verification_token'));
        }

        if ($request->kupunesia_email) {
            Mail::to($request->kupunesia_email)->send(new VerifyEmail($user, 'kupunesia_email_verification_token'));
        }

        return response()->json(['success' => 'Registrasi berhasil! Silakan cek semua email Anda untuk verifikasi.']);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        try {
            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'Invalid credentials'], 401);
            }

            // Ambil data pengguna yang sedang login
            $user = JWTAuth::user();

            // Kembalikan token dan data pengguna
            return response()->json([
                'token' => $token,
                'user' => [
                    'id' => $user->id,
                    'uname' => $user->uname,
                    'fname' => $user->fname,
                    'lname' => $user->lname,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'organization' => $user->organization,
                    'is_approved' => $user->is_approved,
                    'burungnesia_user_id' => $user->burungnesia_user_id,
                    'kupunesia_user_id' => $user->kupunesia_user_id,
                    'level' => $user->level,
                    'ip_addr' => $user->ip_addr,
                    'bio' => $user->bio,
                    'profile_picture' => $user->profile_picture,
                    // Tambahkan data lain yang diperlukan
                ]
            ]);
        } catch (JWTException $e) {
            return response()->json(['error' => 'Could not create token'], 500);
        }
    }

    public function verifyEmail($token, $type)
    {
        $user = FobiUser::where($type, $token)->first();

        if (!$user) {
            return response()->json(['error' => 'Token verifikasi tidak valid.'], 400);
        }

        if ($type === 'email_verification_token') {
            $user->email_verified_at = now();
            $user->email_verification_token = null;
        } elseif ($type === 'burungnesia_email_verification_token') {
            $user->burungnesia_email_verified_at = now();
            $user->burungnesia_email_verification_token = null;
        } elseif ($type === 'kupunesia_email_verification_token') {
            $user->kupunesia_email_verified_at = now();
            $user->kupunesia_email_verification_token = null;
        }

        if ($user->email_verified_at &&
            (!$user->burungnesia_email || $user->burungnesia_email_verified_at) &&
            (!$user->kupunesia_email || $user->kupunesia_email_verified_at)) {
            $user->is_approved = 1;
        }

        $user->save();

        return response()->json(['success' => 'Email Anda telah diverifikasi.']);
    }

    public function logout(Request $request)
    {
        try {
            // Dapatkan token dari request
            $token = JWTAuth::getToken();

            // Periksa apakah token ada
            if (!$token) {
                return response()->json(['error' => 'Token not provided'], 400);
            }

            // Invalidate token
            JWTAuth::invalidate($token);

            return response()->json(['success' => 'User logged out successfully']);
        } catch (JWTException $e) {
            return response()->json(['error' => 'Failed to logout, please try again'], 500);
        }
    }
    public function getUser($id)
{
    $user = FobiUser::find($id);
    if (!$user) {
        return response()->json(['error' => 'Pengguna tidak ditemukan'], 404);
    }
    return response()->json($user);
}
}
