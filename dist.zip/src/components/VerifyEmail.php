<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\FobiUser;

class VerifyEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $tokenType;
    private $frontendUrl;

    public function __construct(FobiUser $user, $tokenType)
    {
        $this->user = $user;
        $this->tokenType = $tokenType;
        $this->frontendUrl = env('FRONTEND_URL', 'http://localhost:5173'); // Sesuaikan dengan URL frontend Anda
    }

    public function build()
    {
        try {
            $token = $this->getToken();
            $verificationUrl = $this->frontendUrl . '/verify-email/' . $token . '/' . $this->tokenType;
            
            \Log::info('Building verification email', [
                'token_type' => $this->tokenType,
                'url' => $verificationUrl
            ]);
    
            return $this->view('emails.verify')
                        ->subject('Verifikasi Email FOBI')
                        ->with([
                            'user' => $this->user,
                            'verificationUrl' => $verificationUrl,
                            'tokenType' => $this->tokenType
                        ]);
        } catch (\Exception $e) {
            \Log::error('Error building verification email:', [
                'error' => $e->getMessage(),
                'token_type' => $this->tokenType
            ]);
            throw $e;
        }
    }
    private function getToken()
    {
        switch ($this->tokenType) {
            case 'email_verification_token':
                return $this->user->email_verification_token;
            case 'burungnesia_email_verification_token':
                return $this->user->burungnesia_email_verification_token;
            case 'kupunesia_email_verification_token':
                return $this->user->kupunesia_email_verification_token;
            default:
                throw new \Exception('Invalid token type');
        }
    }
}