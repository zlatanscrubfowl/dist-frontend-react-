import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes, faCamera } from '@fortawesome/free-solid-svg-icons';

function EditProfileModal({ isOpen, onClose, userData, onSave }) {
    const [formData, setFormData] = useState({
        bio: userData?.bio || '',
        profile_picture: null,
        previewUrl: userData?.profile_picture || null
    });

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFormData({
                ...formData,
                profile_picture: file,
                previewUrl: URL.createObjectURL(file)
            });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formDataToSend = new FormData();
        formDataToSend.append('bio', formData.bio);
        if (formData.profile_picture) {
            formDataToSend.append('profile_picture', formData.profile_picture);
        }

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/api/profile/update`, {
                method: 'POST',
                body: formDataToSend,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (response.ok) {
                onSave();
                onClose();
            }
        } catch (error) {
            console.error('Error updating profile:', error);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">Edit Profil</h2>
                    <button onClick={onClose}>
                        <FontAwesomeIcon icon={faTimes} className="text-gray-500" />
                    </button>
                </div>

                <form onSubmit={handleSubmit}>
                    {/* Foto Profil */}
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Foto Profil
                        </label>
                        <div className="relative w-32 h-32 mx-auto">
                            <div className="w-full h-full rounded-full overflow-hidden bg-gray-100">
                                {formData.previewUrl ? (
                                    <img
                                        src={formData.previewUrl}
                                        alt="Preview"
                                        className="w-full h-full object-cover"
                                    />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center">
                                        <FontAwesomeIcon icon={faCamera} className="text-gray-400 text-3xl" />
                                    </div>
                                )}
                            </div>
                            <label className="absolute bottom-0 right-0 bg-teal-600 rounded-full p-2 cursor-pointer">
                                <FontAwesomeIcon icon={faCamera} className="text-white" />
                                <input
                                    type="file"
                                    className="hidden"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                />
                            </label>
                        </div>
                    </div>

                    {/* Bio */}
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Bio
                        </label>
                        <textarea
                            value={formData.bio}
                            onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                            className="w-full h-32 p-2 border rounded focus:ring-2 focus:ring-teal-500"
                            placeholder="Tulis bio Anda di sini..."
                        />
                    </div>

                    {/* Tombol Submit */}
                    <div className="flex justify-end gap-2">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
                        >
                            Batal
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700"
                        >
                            Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default EditProfileModal;