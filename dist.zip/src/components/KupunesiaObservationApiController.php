<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Tymon\JWTAuth\Facades\JWTAuth;

class KupunesiaObservationApiController extends Controller
{
    public function storeChecklistAndFauna(Request $request)
    {
        try {
            $request->validate([
                'latitude' => 'required|numeric',
                'longitude' => 'required|numeric',
                'tujuan_pengamatan' => 'required|integer',
                'fauna_id.*' => 'required|integer',
                'count.*' => 'required|integer',
                'notes.*' => 'nullable|string',
                'observer' => 'nullable|string',
                'completed' => 'nullable|integer',
                'start_time' => 'nullable|date_format:H:i',
                'end_time' => 'nullable|date_format:H:i',
                'active' => 'nullable|integer',
                'additional_note' => 'nullable|string',
                'tgl_pengamatan' => 'nullable|date',
                'images.*.*' => 'nullable|file|mimes:jpeg,png,jpg,gif|max:2048',
            ]);

            Log::info('Request data:', $request->all());

            $userId = JWTAuth::parseToken()->authenticate()->id;
            $fobiUser = DB::table('fobi_users')->where('id', $userId)->first();

            if (!$fobiUser) {
                return response()->json(['error' => 'User tidak ditemukan.'], 404);
            }

            $kupunesiaUserId = $fobiUser->kupunesia_user_id;

            DB::transaction(function () use ($request, $userId, $kupunesiaUserId) {
                // Simpan ke database Fobi dengan tabel baru
                $checklistId = DB::table('fobi_checklists_kupnes')->insertGetId([
                    'fobi_user_id' => $userId,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'tujuan_pengamatan' => $request->tujuan_pengamatan,
                    'observer' => $request->observer,
                    'additional_note' => $request->additional_note,
                    'active' => $request->active ?? 1,
                    'tgl_pengamatan' => $request->tgl_pengamatan,
                    'start_time' => $request->start_time,
                    'end_time' => $request->end_time,
                    'completed' => $request->completed ?? 0,
                    'can_edit' => 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // Pastikan data adalah array
                $faunaIds = is_array($request->fauna_id) ? $request->fauna_id : [$request->fauna_id];
                $counts = is_array($request->count) ? $request->count : [$request->count];
                $notes = is_array($request->notes) ? $request->notes : [$request->notes];

                foreach ($faunaIds as $index => $faunaId) {
                    // Simpan ke fobi_checklist_faunasv2
                    DB::table('fobi_checklist_faunasv2')->insert([
                        'checklist_id' => $checklistId,
                        'fauna_id' => $faunaId,
                        'count' => $counts[$index],
                        'notes' => $notes[$index],
                        'breeding' => 0,
                        'breeding_type_id' => null,
                        'breeding_note' => null,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);

                    // Handle images dengan tabel baru
                    if ($request->hasFile("images.$index")) {
                        foreach ($request->file("images.$index") as $imageFile) {
                            $imagePath = $imageFile->store('uploads', 'public');
                            DB::table('fobi_checklist_fauna_imgs_kupnes')->insert([
                                'checklist_id' => $checklistId,
                                'fauna_id' => $faunaId,
                                'images' => asset('storage/' . $imagePath),
                                'status' => 0,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    }
                }

                // Simpan ke database Third (Kupunesia) tetap sama
                $checklistIdThird = DB::connection('third')->table('checklists')->insertGetId([
                    'user_id' => $kupunesiaUserId,
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'tujuan_pengamatan' => $request->tujuan_pengamatan,
                    'observer' => $request->observer,
                    'additional_note' => $request->additional_note,
                    'active' => $request->active,
                    'tgl_pengamatan' => $request->tgl_pengamatan,
                    'start_time' => $request->start_time,
                    'end_time' => $request->end_time,
                    'completed' => $request->completed,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                foreach ($faunaIds as $index => $faunaId) {
                    DB::connection('third')->table('checklist_fauna')->insert([
                        'checklist_id' => $checklistIdThird,
                        'fauna_id' => $faunaId,
                        'count' => $counts[$index],
                        'notes' => $notes[$index],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            });

            return response()->json(['success' => 'Data berhasil diunggah ke kedua database!'], 201);
        } catch (\Exception $e) {
            Log::error('Error uploading data: ' . $e->getMessage());
            return response()->json(['error' => 'Terjadi kesalahan saat mengunggah data.'], 500);
        }
    }
    public function getFaunaId(Request $request)
    {
        try {
            $name = $request->input('name');

            // Coba cari di database third (Kupunesia) terlebih dahulu
            $faunas = DB::connection('third')
                ->table('faunas')
                ->where('nameId', 'like', "%{$name}%")
                ->orWhere('nameLat', 'like', "%{$name}%")
                ->select('id', 'nameId', 'nameLat')
                ->limit(10)
                ->get();

            if ($faunas->isEmpty()) {
                // Jika tidak ditemukan, coba cari di database fobi
                $faunas = DB::table('faunas')
                    ->where('nameId', 'like', "%{$name}%")
                    ->orWhere('nameLat', 'like', "%{$name}%")
                    ->select('id', 'nameId', 'nameLat')
                    ->limit(10)
                    ->get();
            }

            return response()->json([
                'success' => true,
                'data' => $faunas->map(function($fauna) {
                    return [
                        'id' => $fauna->id,
                        'nameId' => $fauna->nameId,
                        'nameLat' => $fauna->nameLat,
                        'displayName' => $fauna->nameId . ' (' . $fauna->nameLat . ')'
                    ];
                })
            ]);

        } catch (\Exception $e) {
            Log::error('Error searching fauna: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan saat mencari data fauna.'
            ], 500);
        }
    }
}
