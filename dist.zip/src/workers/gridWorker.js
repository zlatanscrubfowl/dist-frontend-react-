// Fungsi helper untuk generate grid
function generateGrid(markers, cellSize) {
  const grid = {};
  
  markers.forEach(marker => {
    const lat = parseFloat(marker.latitude);
    const lng = parseFloat(marker.longitude);
    
    const gridX = Math.floor(lng / cellSize);
    const gridY = Math.floor(lat / cellSize);
    const key = `${gridX}:${gridY}`;
    
    if (!grid[key]) {
      grid[key] = {
        bounds: {
          minLat: gridY * cellSize,
          maxLat: (gridY + 1) * cellSize,
          minLng: gridX * cellSize,
          maxLng: (gridX + 1) * cellSize
        },
        data: []
      };
    }
    
    grid[key].data.push(marker);
  });
  
  return Object.values(grid);
}

// Worker event handler
self.onmessage = function(e) {
  const { markers } = e.data;
  
  const smallGrid = generateGrid(markers, 0.02);
  const mediumGrid = generateGrid(markers, 0.05);
  const largeGrid = generateGrid(markers, 0.2);
  const extraLargeGrid = generateGrid(markers, 0.5);

  self.postMessage({
    smallGrid,
    mediumGrid,
    largeGrid,
    extraLargeGrid
  });
}; 