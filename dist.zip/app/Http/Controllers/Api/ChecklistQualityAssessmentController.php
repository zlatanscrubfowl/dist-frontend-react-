<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Tymon\JWTAuth\Facades\JWTAuth;

class ChecklistQualityAssessmentController extends Controller
{
    private function getChecklistTable($source)
    {
        return match($source) {
            'burungnesia' => 'fobi_checklists',
            'kupunesia' => 'fobi_checklists_kupnes',
            default => 'fobi_checklist_taxas'
        };
    }

    private function getAssessmentTable($source)
    {
        return match($source) {
            'burungnesia' => 'data_quality_assessments',
            'kupunesia' => 'data_quality_assessments_kupnes',
            default => 'taxa_quality_assessments'
        };
    }

    private function checkHasMedia($id, $source)
    {
        if ($source === 'burungnesia') {
            return DB::table('fobi_checklist_fauna_imgs')
                ->where('checklist_id', $id)
                ->exists() ||
                DB::table('fobi_checklist_sounds')
                    ->where('checklist_id', $id)
                    ->exists();
        } elseif ($source === 'kupunesia') {
            return DB::table('fobi_checklist_fauna_imgs_kupnes')
                ->where('checklist_id', $id)
                ->exists();
        } else {
            return DB::table('fobi_checklist_media')
                ->where('checklist_id', $id)
                ->exists();
        }
    }

    private function getActualId($id, $source)
    {
        if ($source === 'burungnesia' && str_starts_with($id, 'BN')) {
            return substr($id, 2);
        }
        if ($source === 'kupunesia' && str_starts_with($id, 'KP')) {
            return substr($id, 2);
        }
        return $id;
    }

    public function getAssessmentConfig($source)
    {
        return match($source) {
            'burungnesia' => [
                'table' => 'data_quality_assessments',
                'id_column' => 'observation_id',
                'fauna_column' => 'fauna_id'
            ],
            'kupunesia' => [
                'table' => 'data_quality_assessments_kupnes',
                'id_column' => 'observation_id',
                'fauna_column' => 'fauna_id'
            ],
            default => [
                'table' => 'taxa_quality_assessments',
                'id_column' => 'taxa_id',
                'fauna_column' => 'taxon_id'
            ]
        };
    }


    private function calculateGrade($stats, $hasMedia)
    {
        // Jika tidak ada identifikasi
        if ($stats->total_identifications == 0) {
            return 'casual';
        }

        // Jika ada media dan minimal 2 persetujuan
        if ($hasMedia && $stats->agreement_count >= 2) {
            return 'research grade';
        }

        // Jika ada media dan ada identifikasi
        if ($hasMedia && $stats->total_identifications > 0) {
            return 'needs ID';
        }

        // Jika ada identifikasi tapi tidak ada media
        if ($stats->total_identifications > 0) {
            return 'low quality ID';
        }

        return 'casual';
    }

    private function determineGrade($totalIdentifications, $agreementCount, $hasMedia, $hasLocation, $hasDate)
    {
        // Jika memenuhi semua kriteria research grade
        if ($hasMedia && $hasLocation && $hasDate && $agreementCount >= 2) {
            return 'research grade';
        }

        // Jika memenuhi kriteria needs ID
        if ($hasMedia && $hasLocation && $hasDate && $totalIdentifications > 0) {
            return 'needs ID';
        }

        // Jika ada identifikasi tapi tidak memenuhi semua kriteria
        if ($totalIdentifications >= 2 && $agreementCount == 1 && $hasMedia && $hasLocation && $hasDate) {
            return 'low quality ID';
        }

        return 'casual';
    }

    private function meetsResearchGradeCriteria($agreementCount, $hasMedia, $hasLocation, $hasDate)
    {
        return $agreementCount >= 2 && $hasMedia && $hasLocation && $hasDate;
    }

    private function meetsNeedsIdCriteria($totalIdentifications, $agreementCount, $hasMedia, $hasLocation, $hasDate)
    {
        return $totalIdentifications > 0 && $hasMedia && $hasLocation && $hasDate;
    }

    private function meetsLowQualityIdCriteria($agreementCount, $hasMedia, $hasLocation, $hasDate)
    {
        return $agreementCount > 0 && (!$hasMedia || !$hasLocation || !$hasDate);
    }

    // Method untuk mendapatkan status quality assessment
    public function getQualityAssessment($id)
    {
        try {
            $source = request()->query('source', $this->determineSource($id));
            $actualId = $this->getActualId($id, $source);
            $config = $this->getAssessmentConfig($source);

            // Get fauna/taxa ID first
            $faunaId = null;
            if ($source === 'burungnesia') {
                $faunaId = DB::table('fobi_checklist_faunasv1')
                    ->where('checklist_id', $actualId)
                    ->value('fauna_id');
            } elseif ($source === 'kupunesia') {
                $faunaId = DB::table('fobi_checklist_faunasv2')
                    ->where('checklist_id', $actualId)
                    ->value('fauna_id');
            } else {
                $faunaId = DB::table('fobi_checklist_taxas')
                    ->where('id', $actualId)
                    ->value('taxa_id');
            }

            // Get existing assessment
            $assessment = DB::table($config['table'])
                ->where($config['id_column'], $actualId)
                ->where($config['fauna_column'], $faunaId)
                ->first();

            if (!$assessment) {
                // Calculate initial assessment
                $stats = DB::table('taxa_identifications')
                    ->where('checklist_id', $actualId)
                    ->selectRaw('
                        COUNT(CASE WHEN agrees_with_id IS NOT NULL THEN 1 END) as agreement_count
                    ')
                    ->first();

                $hasMedia = $this->checkHasMedia($actualId, $source);
                $hasLocation = $this->checkHasLocation($actualId, $source);
                $hasDate = $this->checkHasDate($actualId, $source);

                $grade = $this->determineGrade(
                    0, // total identifications tidak digunakan
                    $stats->agreement_count ?? 0,
                    $hasMedia,
                    $hasLocation,
                    $hasDate
                );

                // Create new assessment
                $newAssessment = [
                    $config['id_column'] => $actualId,
                    $config['fauna_column'] => $faunaId,
                    'grade' => $grade,
                    'has_media' => $hasMedia,
                    'has_location' => $hasLocation,
                    'has_date' => $hasDate,
                    'agreement_count' => $stats->agreement_count ?? 0,
                    'created_at' => now(),
                    'updated_at' => now()
                ];

                DB::table($config['table'])->insert($newAssessment);
                $assessment = (object)$newAssessment;
            }

            // Format response
            $formattedAssessment = [
                'id' => $assessment->id ?? null,
                'grade' => $assessment->grade ?? 'casual',
                'has_media' => $assessment->has_media ?? false,
                'has_location' => $assessment->has_location ?? false,
                'has_date' => $assessment->has_date ?? false,
                'agreement_count' => $assessment->agreement_count ?? 0
            ];

            return response()->json([
                'success' => true,
                'data' => $formattedAssessment
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getQualityAssessment: ' . $e->getMessage(), [
                'id' => $id,
                'source' => $source ?? 'unknown',
                'exception' => $e
            ]);

            // Return default assessment on error
            return response()->json([
                'success' => true,
                'data' => [
                    'grade' => 'casual',
                    'has_media' => false,
                    'has_location' => false,
                    'has_date' => false,
                    'agreement_count' => 0
                ]
            ]);
        }
    }

    private function checkHasLocation($id, $source)
    {
        $table = $this->getChecklistTable($source);
        return DB::table($table)
            ->where('id', $id)
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->exists();
    }

    private function checkHasDate($id, $source)
    {
        $table = $this->getChecklistTable($source);

        // Sesuaikan kolom berdasarkan source
        $dateColumn = match($source) {
            'fobi' => 'created_at',  // Gunakan created_at untuk FOBI
            'burungnesia', 'kupunesia' => 'tgl_pengamatan'
        };

        return DB::table($table)
            ->where('id', $id)
            ->whereNotNull($dateColumn)
            ->exists();
    }

    // Method untuk batch update quality assessments
    public function batchUpdateQualityAssessments(Request $request)
    {
        try {
            $request->validate([
                'observation_ids' => 'required|array',
                'observation_ids.*' => 'required|string'
            ]);

            $results = [];
            foreach ($request->observation_ids as $id) {
                $source = $this->determineSource($id);
                try {
                    $grade = $this->updateQualityAssessment($id, $source);
                    $results[$id] = [
                        'success' => true,
                        'grade' => $grade
                    ];
                } catch (\Exception $e) {
                    $results[$id] = [
                        'success' => false,
                        'error' => $e->getMessage()
                    ];
                }
            }

            return response()->json([
                'success' => true,
                'data' => $results
            ]);

        } catch (\Exception $e) {
            Log::error('Error in batchUpdateQualityAssessments: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memperbarui quality assessments'
            ], 500);
        }
    }

    // Method untuk menentukan sumber data berdasarkan ID
    private function determineSource($id)
    {
        if (str_starts_with($id, 'BN')) return 'burungnesia';
        if (str_starts_with($id, 'KP')) return 'kupunesia';
        return 'fobi';
    }

    // Method untuk mendapatkan statistik quality assessment
    public function getQualityStats(Request $request)
    {
        try {
            $source = $request->input('source', 'all');

            $stats = [];
            $sources = $source === 'all' ? ['fobi', 'burungnesia', 'kupunesia'] : [$source];

            foreach ($sources as $src) {
                $table = match($src) {
                    'fobi' => 'taxa_quality_assessments',
                    'burungnesia' => 'data_quality_assessments',
                    'kupunesia' => 'data_quality_assessments_kupnes'
                };

                $stats[$src] = DB::table($table)
                    ->select(
                        DB::raw('COUNT(*) as total'),
                        DB::raw("COUNT(CASE WHEN grade = 'research grade' THEN 1 END) as research_grade"),
                        DB::raw("COUNT(CASE WHEN grade = 'needs ID' THEN 1 END) as needs_id"),
                        DB::raw("COUNT(CASE WHEN grade = 'low quality ID' THEN 1 END) as low_quality"),
                        DB::raw("COUNT(CASE WHEN grade = 'casual' THEN 1 END) as casual")
                    )
                    ->first();
            }

            return response()->json([
                'success' => true,
                'data' => $stats
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getQualityStats: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil statistik quality assessment'
            ], 500);
        }
    }

    public function assessQuality($id)
    {
        try {
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id, $source);
            $config = $this->getAssessmentConfig($source);

            // Ambil data checklist
            $checklistTable = $this->getChecklistTable($source);
            $assessmentTable = $this->getAssessmentTable($source);

            // Cek kriteria
            $hasMedia = $this->checkHasMedia($actualId, $source);
            $hasLocation = $this->checkHasLocation($actualId, $source);
            $hasDate = $this->checkHasDate($actualId, $source);

            // Hitung statistik identifikasi
            $stats = DB::table('taxa_identifications')
                ->where(function($query) use ($source, $actualId) {
                    if ($source === 'burungnesia') {
                        $query->where('burnes_checklist_id', $actualId);
                    } elseif ($source === 'kupunesia') {
                        $query->where('kupnes_checklist_id', $actualId);
                    } else {
                        $query->where('checklist_id', $actualId);
                    }
                })
                ->selectRaw('
                    COUNT(*) as total_identifications,
                    COUNT(CASE WHEN agrees_with_id IS NOT NULL THEN 1 END) as agreement_count
                ')
                ->first();

            // Tentukan grade
            $grade = $this->determineGrade(
                $stats->total_identifications ?? 0,
                $stats->agreement_count ?? 0,
                $hasMedia,
                $hasLocation,
                $hasDate
            );

            // Persiapkan data assessment sesuai dengan source
            $assessmentData = [
                'grade' => $grade,
                'has_media' => $hasMedia,
                'has_location' => $hasLocation,
                'has_date' => $hasDate,
                'agreement_count' => $stats->agreement_count ?? 0,
                'updated_at' => now()
            ];

            // Tambahkan kolom ID sesuai dengan source
            if ($source === 'burungnesia') {
                $assessmentData['observation_id'] = $actualId;
                $assessmentData['fauna_id'] = DB::table('fobi_checklist_faunasv1')
                    ->where('checklist_id', $actualId)
                    ->value('fauna_id');
            } elseif ($source === 'kupunesia') {
                $assessmentData['observation_id'] = $actualId;
                $assessmentData['fauna_id'] = DB::table('fobi_checklist_faunasv2')
                    ->where('checklist_id', $actualId)
                    ->value('fauna_id');
            } else {
                $assessmentData['taxa_id'] = $actualId;
                $assessmentData['taxon_id'] = DB::table('fobi_checklist_taxas')
                    ->where('id', $actualId)
                    ->value('taxa_id');
            }

            // Update atau insert assessment berdasarkan source
            if ($source === 'burungnesia' || $source === 'kupunesia') {
                DB::table($assessmentTable)
                    ->updateOrInsert(
                        ['observation_id' => $actualId],
                        $assessmentData
                    );
            } else {
                DB::table($assessmentTable)
                    ->updateOrInsert(
                        ['taxa_id' => $actualId],
                        $assessmentData
                    );
            }

            return response()->json([
                'success' => true,
                'message' => 'Quality assessment berhasil diperbarui',
                'data' => [
                    'grade' => $grade,
                    'has_media' => $hasMedia,
                    'has_location' => $hasLocation,
                    'has_date' => $hasDate,
                    'agreement_count' => $stats->agreement_count ?? 0
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in assessQuality: ' . $e->getMessage(), [
                'id' => $id,
                'source' => $source ?? 'unknown',
                'exception' => $e
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memperbarui quality assessment'
            ], 500);
        }
    }

    public function updateQualityAssessment($id)
    {
        try {
            $source = request()->query('source', 'fobi');
            $actualId = $this->getActualId($id, $source);
            $config = $this->getAssessmentConfig($source);

            // Dapatkan identifikasi dengan persetujuan terbanyak
            $mostAgreedIdentification = DB::table('taxa_identifications as ti')
                ->select(
                    'ti.taxon_id',
                    't.scientific_name',
                    't.burnes_fauna_id',
                    't.kupnes_fauna_id',
                    DB::raw('COUNT(ti2.id) as agreement_count')
                )
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->leftJoin('taxa_identifications as ti2', 'ti.id', '=', 'ti2.agrees_with_id')
                ->where(function($query) use ($source, $actualId) {
                    if ($source === 'burungnesia') {
                        $query->where('ti.burnes_checklist_id', $actualId);
                    } elseif ($source === 'kupunesia') {
                        $query->where('ti.kupnes_checklist_id', $actualId);
                    } else {
                        $query->where('ti.checklist_id', $actualId);
                    }
                })
                ->whereNull('ti.is_withdrawn')
                ->groupBy('ti.taxon_id', 't.scientific_name', 't.burnes_fauna_id', 't.kupnes_fauna_id')
                ->orderBy('agreement_count', 'desc')
                ->first();

            // Hitung total statistik identifikasi
            $stats = DB::table('taxa_identifications')
                ->where(function($query) use ($source, $actualId) {
                    if ($source === 'burungnesia') {
                        $query->where('burnes_checklist_id', $actualId);
                    } elseif ($source === 'kupunesia') {
                        $query->where('kupnes_checklist_id', $actualId);
                    } else {
                        $query->where('checklist_id', $actualId);
                    }
                })
                ->selectRaw('
                    COUNT(*) as total_identifications,
                    COUNT(CASE WHEN agrees_with_id IS NOT NULL THEN 1 END) as agreement_count,
                    COUNT(DISTINCT user_id) as unique_identifiers
                ')
                ->first();

            // Cek kriteria
            $hasMedia = $this->checkHasMedia($actualId, $source);
            $hasLocation = $this->checkHasLocation($actualId, $source);
            $hasDate = $this->checkHasDate($actualId, $source);
            
            // Tentukan grade
            $grade = $this->determineGrade(
                $stats->total_identifications,
                $stats->agreement_count,
                $hasMedia,
                $hasLocation,
                $hasDate
            );

            // Update fauna/taxa ID hanya jika memenuhi kriteria (minimal 2 persetujuan)
            if ($mostAgreedIdentification && $mostAgreedIdentification->agreement_count >= 2) {
                if ($source === 'burungnesia') {
                    // Update fobi_checklists
                    DB::table('fobi_checklists')
                        ->where('id', $actualId)
                        ->update(['scientific_name' => $mostAgreedIdentification->scientific_name]);
                    
                    // Update fobi_checklist_faunasv1
                    DB::table('fobi_checklist_faunasv1')
                        ->where('checklist_id', $actualId)
                        ->update(['fauna_id' => $mostAgreedIdentification->burnes_fauna_id]);

                } elseif ($source === 'kupunesia') {
                    // Update fobi_checklists_kupnes
                    DB::table('fobi_checklists_kupnes')
                        ->where('id', $actualId)
                        ->update(['scientific_name' => $mostAgreedIdentification->scientific_name]);
                    
                    // Update fobi_checklist_faunasv2
                    DB::table('fobi_checklist_faunasv2')
                        ->where('checklist_id', $actualId)
                        ->update(['fauna_id' => $mostAgreedIdentification->kupnes_fauna_id]);

                } else {
                    // Update fobi_checklist_taxas
                    $currentTaxa = DB::table('fobi_checklist_taxas')
                        ->where('id', $actualId)
                        ->first();

                    if ($currentTaxa->taxa_id != $mostAgreedIdentification->taxon_id) {
                        DB::table('fobi_checklist_taxas')
                            ->where('id', $actualId)
                            ->update([
                                'original_taxa_id' => $currentTaxa->taxa_id,
                                'taxa_id' => $mostAgreedIdentification->taxon_id,
                                'scientific_name' => $mostAgreedIdentification->scientific_name
                            ]);
                    }
                }
            }

            // Update atau insert assessment
            $assessmentData = [
                $config['id_column'] => $actualId,
                'fauna_id' => $mostAgreedIdentification && $mostAgreedIdentification->agreement_count >= 2 
                    ? match($source) {
                        'burungnesia' => $mostAgreedIdentification->burnes_fauna_id ?? $this->getFallbackFaunaId($actualId, 'burungnesia'),
                        'kupunesia' => $mostAgreedIdentification->kupnes_fauna_id ?? $this->getFallbackFaunaId($actualId, 'kupunesia'),
                        default => $mostAgreedIdentification->taxon_id
                    } 
                    : $this->getFallbackFaunaId($actualId, $source),
                'grade' => $grade,
                'has_media' => $hasMedia,
                'has_location' => $hasLocation,
                'has_date' => $hasDate,
                'agreement_count' => $stats->agreement_count,
                'updated_at' => now()
            ];

            DB::table($config['table'])
                ->updateOrInsert(
                    [$config['id_column'] => $actualId],
                    $assessmentData
                );

            return response()->json([
                'success' => true,
                'message' => 'Quality assessment berhasil diperbarui',
                'data' => [
                    'grade' => $grade,
                    'total_identifications' => $stats->total_identifications,
                    'agreement_count' => $stats->agreement_count,
                    'unique_identifiers' => $stats->unique_identifiers
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in updateQualityAssessment: ' . $e->getMessage(), [
                'id' => $id,
                'source' => $source ?? 'unknown',
                'exception' => $e
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memperbarui quality assessment'
            ], 500);
        }
    }

    private function getFallbackFaunaId($actualId, $source)
    {
        try {
            if ($source === 'burungnesia') {
                $checklist = DB::table('fobi_checklist_faunasv1')
                    ->where('checklist_id', $actualId)
                    ->first();
                return $checklist->fauna_id ?? null;
            } elseif ($source === 'kupunesia') {
                $checklist = DB::table('fobi_checklist_faunasv2')
                    ->where('checklist_id', $actualId)
                    ->first();
                return $checklist->fauna_id ?? null;
            }
            return null;
        } catch (\Exception $e) {
            Log::error('Error getting fallback fauna_id: ' . $e->getMessage());
            return null;
        }
    }

    private function updateChecklistTaxon($id, $source)
    {
        try {
            $actualId = $this->getActualId($id, $source);

            // Base query untuk identifikasi dengan persetujuan terbanyak
            $query = DB::table('taxa_identifications as ti')
                ->select(
                    'ti.taxon_id',
                    't.scientific_name',
                    't.iucn_red_list_category',
                    't.class',
                    't.order',
                    't.family',
                    't.genus',
                    't.species',
                    't.burnes_fauna_id',
                    't.kupnes_fauna_id',
                    DB::raw('COUNT(ti2.id) as agreement_count')
                )
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->leftJoin('taxa_identifications as ti2', 'ti.id', '=', 'ti2.agrees_with_id');

            // Sesuaikan where clause berdasarkan sumber
            if ($source === 'burungnesia') {
                $query->where('ti.burnes_checklist_id', $actualId);
            } elseif ($source === 'kupunesia') {
                $query->where('ti.kupnes_checklist_id', $actualId);
            } else {
                $query->where('ti.checklist_id', $actualId);
            }

            $mostAgreedIdentification = $query
                ->groupBy(
                    'ti.taxon_id', 't.scientific_name', 't.iucn_red_list_category',
                    't.class', 't.order', 't.family', 't.genus', 't.species',
                    't.burnes_fauna_id', 't.kupnes_fauna_id'
                )
                ->orderBy('agreement_count', 'desc')
                ->first();

            if ($mostAgreedIdentification) {
                // Khusus untuk fobi_checklist_taxas, simpan taxa_id lama
                if ($source === 'fobi') {
                    $currentChecklist = DB::table('fobi_checklist_taxas')
                        ->where('id', $actualId)
                        ->first();

                    if ($currentChecklist && $currentChecklist->taxa_id != $mostAgreedIdentification->taxon_id) {
                        // Update dengan menyimpan taxa_id lama ke original_taxa_id
                        DB::table('fobi_checklist_taxas')
                            ->where('id', $actualId)
                            ->update([
                                'original_taxa_id' => $currentChecklist->taxa_id,
                                'taxa_id' => $mostAgreedIdentification->taxon_id,
                                'scientific_name' => $mostAgreedIdentification->scientific_name,
                                'class' => $mostAgreedIdentification->class,
                                'order' => $mostAgreedIdentification->order,
                                'family' => $mostAgreedIdentification->family,
                                'genus' => $mostAgreedIdentification->genus,
                                'species' => $mostAgreedIdentification->species,
                                'updated_at' => now()
                            ]);
                    }
                } else {
                    // Update untuk sumber lain seperti biasa
                    $baseUpdateData = [
                        'scientific_name' => $mostAgreedIdentification->scientific_name,
                        'class' => $mostAgreedIdentification->class,
                        'order' => $mostAgreedIdentification->order,
                        'family' => $mostAgreedIdentification->family,
                        'genus' => $mostAgreedIdentification->genus,
                        'species' => $mostAgreedIdentification->species,
                        'updated_at' => now()
                    ];

                    if ($source === 'burungnesia') {
                        DB::table('fobi_checklists')
                            ->where('id', $actualId)
                            ->update($baseUpdateData);

                        DB::table('fobi_checklist_faunasv1')
                            ->where('checklist_id', $actualId)
                            ->update([
                                'fauna_id' => $mostAgreedIdentification->burnes_fauna_id,
                                'updated_at' => now()
                            ]);
                    } elseif ($source === 'kupunesia') {
                        DB::table('fobi_checklists_kupnes')
                            ->where('id', $actualId)
                            ->update($baseUpdateData);

                        DB::table('fobi_checklist_faunasv2')
                            ->where('checklist_id', $actualId)
                            ->update([
                                'fauna_id' => $mostAgreedIdentification->kupnes_fauna_id,
                                'updated_at' => now()
                            ]);
                    }
                }
            }

            return true;

        } catch (\Exception $e) {
            Log::error('Error updating checklist taxon: ' . $e->getMessage());
            throw $e;
        }
    }

    public function updateImprovementStatus(Request $request, $id)
    {
        try {
            $request->validate([
                'can_be_improved' => 'required|boolean'
            ]);

            $source = request()->query('source', $this->determineSource($id));
            $actualId = $this->getActualId($id, $source);
            $config = $this->getAssessmentConfig($source);

            // Hitung jumlah identifikasi dan persetujuan
            $identificationStats = DB::table('taxa_identifications')
                ->where(function($query) use ($source, $actualId) {
                    if ($source === 'burungnesia') {
                        $query->where('burnes_checklist_id', $actualId);
                    } elseif ($source === 'kupunesia') {
                        $query->where('kupnes_checklist_id', $actualId);
                    } else {
                        $query->where('checklist_id', $actualId);
                    }
                })
                ->selectRaw('
                    COUNT(*) as total_identifications,
                    COUNT(CASE WHEN agrees_with_id IS NOT NULL THEN 1 END) as agreement_count
                ')
                ->first();

            // Cek keberadaan media dan lokasi berdasarkan sumber
            $hasMedia = $this->checkHasMedia($actualId, $source);
            $hasLocation = $this->checkHasLocation($actualId, $source);
            $hasDate = $this->checkHasDate($actualId, $source);

            // Ambil atau buat assessment sesuai sumber
            $assessment = DB::table($config['table'])->where($config['id_column'], $actualId)->first();

            if (!$assessment) {
                // Buat assessment baru
                $assessmentData = [
                    $config['id_column'] => $actualId,
                    'grade' => 'needs ID',
                    'has_media' => $hasMedia,
                    'has_location' => $hasLocation,
                    'has_date' => $hasDate,
                    'is_wild' => true,
                    'location_accurate' => true,
                    'recent_evidence' => true,
                    'related_evidence' => true,
                    'can_be_improved' => $request->can_be_improved,
                    'created_at' => now(),
                    'updated_at' => now()
                ];

                DB::table($config['table'])->insert($assessmentData);
                $assessment = (object)$assessmentData;
            } else {
                // Update assessment yang ada
                $updateData = [
                    'can_be_improved' => $request->can_be_improved,
                    'updated_at' => now()
                ];

                // Evaluasi grade berdasarkan can_be_improved dan kriteria lainnya
                if ($request->can_be_improved) {
                    if ($this->meetsNeedsIdCriteria(
                        $identificationStats->total_identifications,
                        $identificationStats->agreement_count,
                        $hasMedia,
                        $hasLocation,
                        $hasDate
                    )) {
                        $updateData['grade'] = 'needs ID';
                    }
                } else {
                    if ($this->meetsResearchGradeCriteria(
                        $identificationStats->agreement_count,
                        $hasMedia,
                        $hasLocation,
                        $hasDate
                    )) {
                        $updateData['grade'] = 'research grade';
                    } else if ($this->meetsLowQualityIdCriteria(
                        $identificationStats->agreement_count,
                        $hasMedia,
                        $hasLocation,
                        $hasDate
                    )) {
                        $updateData['grade'] = 'low quality ID';
                    }
                }

                DB::table($config['table'])
                    ->where($config['id_column'], $actualId)
                    ->update($updateData);

                // Refresh assessment data
                $assessment = DB::table($config['table'])
                    ->where($config['id_column'], $actualId)
                    ->first();
            }

            // Update checklist taxon jika grade berubah
            $this->updateChecklistTaxon($id, $source);

            return response()->json([
                'success' => true,
                'data' => $assessment,
                'message' => 'Status berhasil diperbarui'
            ]);

        } catch (\Exception $e) {
            Log::error('Error updating improvement status: ' . $e->getMessage(), [
                'id' => $id,
                'source' => $source ?? 'unknown',
                'exception' => $e
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memperbarui status'
            ], 500);
        }
    }
}
