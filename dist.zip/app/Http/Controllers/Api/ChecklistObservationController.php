<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Api\ChecklistQualityAssessmentController;

class ChecklistObservationController extends Controller
{

    protected $qualityAssessmentController;

    public function __construct(ChecklistQualityAssessmentController $qualityAssessmentController)
    {
        $this->qualityAssessmentController = $qualityAssessmentController;
    }

    public function getObservationDetail($id)
    {
        try {
            $source = request()->query('source', $this->determineSource($id));
            $userId = JWTAuth::user()->id;
            $actualId = $this->getActualId($id, $source);

            // Get quality assessment
            $assessmentConfig = $this->qualityAssessmentController->getAssessmentConfig($source);
            $assessment = DB::table($assessmentConfig['table'])
                ->where($assessmentConfig['id_column'], $actualId)
                ->first();

            // Get checklist details
            $checklistConfig = $this->getChecklistConfig($source);

            // Build query based on source
            if ($source === 'burungnesia') {
                $checklist = DB::table('fobi_checklists as c')
                    ->join('fobi_checklist_faunasv1 as f', 'c.id', '=', 'f.checklist_id')
                    ->leftJoin('taxas as t', 'f.fauna_id', '=', 't.burnes_fauna_id')
                    ->leftJoin('faunas', 'f.fauna_id', '=', 'faunas.id')
                    ->leftJoin('data_quality_assessments as qa', function($join) {
                        $join->on('f.fauna_id', '=', 'qa.fauna_id')
                             ->where('qa.observation_id', DB::raw('c.id'));
                    })
                    ->leftJoin('fobi_users as u', 'c.fobi_user_id', '=', 'u.id')
                    ->select([
                        'c.id',
                        'f.fauna_id',
                        'c.latitude',
                        'c.longitude',
                        'c.location_details',
                        'u.uname as observer',
                        'c.additional_note as notes',
                        'c.tgl_pengamatan as observation_date',
                        DB::raw('COALESCE(t.scientific_name, faunas.nameLat) as scientific_name'),
                        'qa.grade',
                        DB::raw('CASE WHEN qa.grade = "research grade" THEN t.iucn_red_list_category ELSE NULL END as iucn_status'),
                        'c.created_at',
                        'c.updated_at'
                    ])
                    ->where('c.id', $actualId)
                    ->first();

                // Get media
                if ($checklist) {
                    $media = [
                        'images' => DB::table('fobi_checklist_fauna_imgs')
                            ->where('checklist_id', $actualId)
                            ->get(),
                        'sounds' => DB::table('fobi_checklist_sounds')
                            ->where('checklist_id', $actualId)
                            ->get()
                    ];

                    // Attach media to checklist
                    $checklist->media = $media;
                }
            } elseif ($source === 'kupunesia') {
                $checklist = DB::table('fobi_checklists_kupnes as c')
                    ->join('fobi_checklist_faunasv2 as f', 'c.id', '=', 'f.checklist_id')
                    ->leftJoin('taxas as t', 'f.fauna_id', '=', 't.kupnes_fauna_id')
                    ->leftJoin('faunas_kupnes', 'f.fauna_id', '=', 'faunas_kupnes.id')
                    ->leftJoin('data_quality_assessments_kupnes as qa', function($join) {
                        $join->on('f.fauna_id', '=', 'qa.fauna_id')
                             ->where('qa.observation_id', DB::raw('c.id'));
                    })
                    ->leftJoin('fobi_users as u', 'c.fobi_user_id', '=', 'u.id')
                    ->select([
                        'c.id',
                        'f.fauna_id',
                        'c.latitude',
                        'c.longitude',
                        'c.location_details',
                        'u.uname as observer',
                        'c.additional_note as notes',
                        'c.tgl_pengamatan as observation_date',
                        DB::raw('COALESCE(t.scientific_name, faunas_kupnes.nameLat) as scientific_name'),
                        'qa.grade',
                        DB::raw('CASE WHEN qa.grade = "research grade" THEN t.iucn_red_list_category ELSE NULL END as iucn_status'),
                        'c.created_at',
                        'c.updated_at'
                    ])
                    ->where('c.id', $actualId)
                    ->first();

                // Get media untuk Kupunesia (hanya gambar)
                if ($checklist) {
                    $media = [
                        'images' => DB::table('fobi_checklist_fauna_imgs_kupnes')
                            ->where('checklist_id', $actualId)
                            ->select([
                                'id',
                                'images',
                                'checklist_id',
                                'created_at',
                                'updated_at'
                            ])
                            ->get()
                    ];

                    // Attach media to checklist
                    $checklist->media = $media;
                }
            } else {
                // Query untuk FOBI
                $checklist = DB::table('fobi_checklist_taxas as c')
                    ->leftJoin('taxas as t', 'c.taxa_id', '=', 't.id')
                    ->leftJoin('taxa_quality_assessments as qa', 'c.id', '=', 'qa.taxa_id')
                    ->leftJoin('fobi_users as u', 'c.user_id', '=', 'u.id')
                    ->select([
                        'c.id',
                        'c.taxa_id as fauna_id',
                        'c.latitude',
                        'c.longitude',
                        'c.observation_details as location_details',
                        'u.uname as observer',
                        'c.created_at as observation_date',
                        't.scientific_name',
                        't.class',
                        't.order',
                        't.family',
                        't.genus',
                        't.species',
                        'qa.grade',
                        DB::raw('CASE WHEN qa.grade = "research grade" THEN t.iucn_red_list_category ELSE NULL END as iucn_status'),
                        'c.created_at',
                        'c.updated_at'
                    ])
                    ->where('c.id', $actualId)
                    ->first();

                // Get media untuk FOBI
                if ($checklist) {
                    $media = [
                        'images' => DB::table('fobi_checklist_media')
                            ->where('checklist_id', $actualId)
                            ->where('media_type', 'photo')
                            ->select([
                                'id',
                                DB::raw("CONCAT('".config('app.url')."', '/storage/', file_path) as images"),
                                'checklist_id',
                                'created_at',
                                'updated_at'
                            ])
                            ->get(),
                        'sounds' => DB::table('fobi_checklist_media')
                            ->where('checklist_id', $actualId)
                            ->where('media_type', 'audio')
                            ->select([
                                'id',
                                DB::raw("CONCAT('".config('app.url')."', '/storage/', spectrogram) as spectrogram_url"),
                                DB::raw("CONCAT('".config('app.url')."', '/storage/', file_path) as url"),
                                'checklist_id',
                                'created_at',
                                'updated_at'
                            ])
                            ->get()
                    ];

                    // Attach media ke checklist
                    $checklist->media = $media;
                }
            }

            // Log untuk debugging
            Log::info('Checklist found', ['checklist' => $checklist]);

            // Get identifications dengan parameter yang benar
            $identifications = DB::table('taxa_identifications as i')
                ->join('fobi_users as u', 'i.user_id', '=', 'u.id')
                ->leftJoin('taxas as t', 'i.taxon_id', '=', 't.id')
                ->where(function($query) use ($actualId, $source) {
                    if ($source === 'burungnesia') {
                        $query->where('i.burnes_checklist_id', $actualId);
                    } elseif ($source === 'kupunesia') {
                        $query->where('i.kupnes_checklist_id', $actualId);
                    } else {
                        $query->where('i.checklist_id', $actualId);
                    }
                })
                ->select(
                    'i.*',
                    'u.uname as identifier_name',
                    't.scientific_name',
                    DB::raw('(SELECT COUNT(*) FROM taxa_identifications WHERE agrees_with_id = i.id) as agreement_count'),
                    DB::raw('EXISTS(SELECT 1 FROM taxa_identifications WHERE agrees_with_id = i.id AND user_id = ?) as user_agreed')
                )
                ->addBinding($userId, 'select')
                ->get();

            // Format response
            if ($checklist) {
                $formattedChecklist = [
                    'id' => $checklist->id,
                    'fauna_id' => $checklist->fauna_id,
                    'latitude' => $checklist->latitude ? (float)$checklist->latitude : null,
                    'longitude' => $checklist->longitude ? (float)$checklist->longitude : null,
                    'location_details' => $checklist->location_details ?? $checklist->observation_details ?? null,
                    'observer' => $checklist->observer ?? 'Pengamat tidak diketahui',
                    'notes' => $checklist->notes ?? null,
                    'observation_date' => $checklist->observation_date ?? $checklist->created_at,
                    'scientific_name' => $checklist->scientific_name ?? 'Nama tidak tersedia',
                    'class' => $checklist->class ?? null,
                    'order' => $checklist->order ?? null,
                    'family' => $checklist->family ?? null,
                    'genus' => $checklist->genus ?? null,
                    'species' => $checklist->species ?? null,
                    'grade' => $checklist->grade ?? 'casual',
                    'iucn_status' => $checklist->iucn_status,
                    'created_at' => $checklist->created_at,
                    'updated_at' => $checklist->updated_at,
                    'media' => $checklist->media ?? ['images' => [], 'sounds' => []]
                ];

                return response()->json([
                    'success' => true,
                    'data' => [
                        'checklist' => $formattedChecklist,
                        'identifications' => $identifications ?? [],
                        'media' => $checklist->media ?? ['images' => [], 'sounds' => []],
                        'quality_assessment' => $assessment
                    ]
                ]);
            }

        } catch (\Exception $e) {
            Log::error('Error in getObservationDetail: ' . $e->getMessage(), [
                'id' => $id,
                'source' => $source ?? 'unknown',
                'exception' => $e,
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil detail observasi'
            ], 500);
        }
    }

    private function determineSource($id)
    {
        if (str_starts_with($id, 'BN')) return 'burungnesia';
        if (str_starts_with($id, 'KP')) return 'kupunesia';
        return 'fobi';
    }

    private function getChecklistTable($source)
    {
        return match($source) {
            'burungnesia' => 'fobi_checklists',
            'kupunesia' => 'fobi_checklists_kupnes',
            default => 'fobi_checklist_taxas'
        };
    }

    private function getMediaTables($source)
    {
        return match($source) {
            'burungnesia' => [
                'images' => 'fobi_checklist_fauna_imgs',
                'sounds' => 'fobi_checklist_sounds'
            ],
            'kupunesia' => [
                'images' => 'fobi_checklist_fauna_imgs_kupnes'
            ],
            default => [
                'images' => 'fobi_checklist_media'
            ]
        };
    }

    private function getTaxaTables($source)
    {
        return match($source) {
            'burungnesia' => [
                'primary' => 'taxas',
                'fallback' => 'faunas'
            ],
            'kupunesia' => [
                'primary' => 'taxas',
                'fallback' => 'faunas_kupnes'
            ],
            default => [
                'primary' => 'taxas'
            ]
        };
    }

    private function getAssessmentTable($source)
    {
        return match($source) {
            'burungnesia' => 'data_quality_assessments',
            'kupunesia' => 'data_quality_assessments_kupnes',
            default => 'taxa_quality_assessments'
        };
    }

    private function getFobiObservation($id)
    {
        return DB::table('fobi_checklist_taxas as fct')
            ->join('fobi_users as fu', 'fct.user_id', '=', 'fu.id')
            ->join('taxas as t', 'fct.taxa_id', '=', 't.id')
            ->where('fct.id', $id)
            ->select(
                'fct.*',
                'fu.uname as observer_name',
                't.scientific_name'
            )
            ->first();
    }

    private function getBurungnesiaObservation($id)
    {
        return DB::table('fobi_checklists as fc')
            ->join('fobi_checklist_faunasv1 as fcf', 'fc.id', '=', 'fcf.checklist_id')
            ->join('fobi_users as fu', 'fc.fobi_user_id', '=', 'fu.id')
            ->where('fc.id', $id)
            ->select(
                'fc.*',
                'fcf.fauna_id',
                'fcf.count',
                'fcf.notes',
                'fu.uname as observer_name'
            )
            ->first();
    }

    private function getKupunesiaObservation($id)
    {
        return DB::table('fobi_checklists_kupnes as fck')
            ->join('fobi_checklist_faunasv2 as fcf', 'fck.id', '=', 'fcf.checklist_id')
            ->join('fobi_users as fu', 'fck.fobi_user_id', '=', 'fu.id')
            ->where('fck.id', $id)
            ->select(
                'fck.*',
                'fcf.fauna_id',
                'fcf.count',
                'fcf.notes',
                'fu.uname as observer_name'
            )
            ->first();
    }

    public function addIdentification(Request $request, $id)
    {
        try {
            $request->validate([
                'taxon_id' => 'required|exists:taxas,id',
                'burnes_fauna_id' => 'nullable|integer',
                'kupnes_fauna_id' => 'nullable|integer',
                'comment' => 'nullable|string|max:500',
                'photo' => 'nullable|image|max:5120' // Max 5MB
            ]);

            DB::beginTransaction();

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id);

            // Handle photo upload jika ada
            $photoPath = null;
            if ($request->hasFile('photo')) {
                $photo = $request->file('photo');
                $filename = time() . '_' . $photo->getClientOriginalName();
                $path = $photo->storeAs(
                    'identification_photos/' . $source,
                    $filename,
                    'public'
                );
                $photoPath = $path;
            }

            // Ambil data taxa berdasarkan source
            $taxaQuery = DB::table('taxas')->where('id', $request->taxon_id);
            
            if ($source === 'burungnesia') {
                $taxaQuery->whereNotNull('burnes_fauna_id');
                $faunaId = 'burnes_fauna_id';
            } elseif ($source === 'kupunesia') {
                $taxaQuery->whereNotNull('kupnes_fauna_id');
                $faunaId = 'kupnes_fauna_id';
            } else {
                // Untuk FOBI, kita hanya perlu taxon_rank
                $faunaId = null;
            }

            // Sesuaikan select berdasarkan source
            if ($faunaId) {
                $taxon = $taxaQuery->select('taxon_rank', $faunaId)->first();
            } else {
                $taxon = $taxaQuery->select('taxon_rank')->first();
            }

            if (!$taxon) {
                throw new \Exception('Taxa tidak valid untuk sumber data ini');
            }

            // Base identification data
            $identificationData = [
                'user_id' => $userId,
                'taxon_id' => $request->taxon_id,
                'comment' => $request->comment,
                'identification_level' => $taxon->taxon_rank,
                'photo_path' => $photoPath,
                'created_at' => now(),
                'updated_at' => now(),
                'checklist_id' => null,
                'burnes_checklist_id' => null,
                'kupnes_checklist_id' => null,
                'burnes_fauna_id' => null,
                'kupnes_fauna_id' => null
            ];

            // Set values based on source
            if ($source === 'burungnesia') {
                $identificationData['burnes_checklist_id'] = $actualId;
                $identificationData['burnes_fauna_id'] = $taxon->burnes_fauna_id;
            } elseif ($source === 'kupunesia') {
                $identificationData['kupnes_checklist_id'] = $actualId;
                $identificationData['kupnes_fauna_id'] = $taxon->kupnes_fauna_id;
            } else {
                $identificationData['checklist_id'] = $actualId;
            }

            $identificationId = DB::table('taxa_identifications')->insertGetId($identificationData);

            // Update quality assessment
            $this->qualityAssessmentController->updateQualityAssessment($actualId, $source);

            DB::commit();

            // Ambil data identifikasi yang baru dibuat dengan foto
            $newIdentification = DB::table('taxa_identifications as ti')
                ->join('fobi_users as fu', 'ti.user_id', '=', 'fu.id')
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->where('ti.id', $identificationId)
                ->select(
                    'ti.*',
                    'fu.uname as identifier_name',
                    't.scientific_name',
                    't.burnes_fauna_id',
                    't.kupnes_fauna_id',
                    DB::raw('0 as agreement_count'),
                    DB::raw('false as user_agreed'),
                    DB::raw("CASE 
                        WHEN ti.photo_path IS NOT NULL THEN CONCAT('" . config('app.url') . "/storage/', ti.photo_path)
                        ELSE NULL 
                    END as photo_url")
                )
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditambahkan',
                'data' => $newIdentification
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            // Hapus file foto jika ada error
            if (isset($photoPath) && Storage::disk('public')->exists($photoPath)) {
                Storage::disk('public')->delete($photoPath);
            }
            Log::error('Error in addIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function agreeWithIdentification(Request $request, $id, $identificationId)
    {
        try {
            DB::beginTransaction();

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id);

            // Cek apakah identifikasi ada
            $identification = DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan');
            }

            // Cek apakah user sudah pernah setuju
            $existingAgreementQuery = DB::table('taxa_identifications')
                ->where('user_id', $userId)
                ->where('agrees_with_id', $identificationId);

            // Sesuaikan where clause berdasarkan source
            if ($source === 'burungnesia') {
                $existingAgreementQuery->where('burnes_checklist_id', $actualId);
            } elseif ($source === 'kupunesia') {
                $existingAgreementQuery->where('kupnes_checklist_id', $actualId);
            } else {
                $existingAgreementQuery->where('checklist_id', $actualId);
            }

            $existingAgreement = $existingAgreementQuery->first();

            if ($existingAgreement) {
                throw new \Exception('Anda sudah menyetujui identifikasi ini');
            }

            // Siapkan data persetujuan
            $agreementData = [
                'user_id' => $userId,
                'taxon_id' => $identification->taxon_id,
                'burnes_fauna_id' => $identification->burnes_fauna_id,
                'kupnes_fauna_id' => $identification->kupnes_fauna_id,
                'agrees_with_id' => $identificationId,
                'created_at' => now(),
                'updated_at' => now(),
                'checklist_id' => null,
                'burnes_checklist_id' => null,
                'kupnes_checklist_id' => null,
                'identification_level' => $identification->identification_level
            ];

            // Set ID yang sesuai berdasarkan source
            if ($source === 'burungnesia') {
                $agreementData['burnes_checklist_id'] = $actualId;
            } elseif ($source === 'kupunesia') {
                $agreementData['kupnes_checklist_id'] = $actualId;
            } else {
                $agreementData['checklist_id'] = $actualId;
            }

            // Simpan persetujuan
            DB::table('taxa_identifications')->insert($agreementData);

            // Hitung jumlah persetujuan
            $agreementCount = DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->count();

            // Update quality assessment dengan actual ID
            $this->qualityAssessmentController->updateQualityAssessment($actualId, $source);

            DB::commit();

            // Ambil data identifikasi yang diperbarui
            $updatedIdentification = DB::table('taxa_identifications as ti')
                ->join('fobi_users as fu', 'ti.user_id', '=', 'fu.id')
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->where('ti.id', $identificationId)
                ->select(
                    'ti.*',
                    'fu.uname as identifier_name',
                    't.scientific_name',
                    DB::raw("$agreementCount as agreement_count"),
                    DB::raw('true as user_agreed')
                )
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Berhasil menyetujui identifikasi',
                'data' => $updatedIdentification
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in agreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function withdrawIdentification(Request $request, $id, $identificationId)
    {
        try {
            DB::beginTransaction();

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id);

            // Cek apakah identifikasi ada dan milik user
            $identification = DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->where('user_id', $userId)
                ->whereNull('agrees_with_id')
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan atau bukan milik Anda');
            }

            // Update status is_withdrawn menjadi true alih-alih menghapus
            DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->update([
                    'is_withdrawn' => true,
                    'updated_at' => now()
                ]);

            // Hapus semua persetujuan untuk identifikasi ini
            DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->delete();

            $this->qualityAssessmentController->updateQualityAssessment($actualId, $source);
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Identifikasi berhasil ditarik'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in withdrawIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    private function getObservationMedia($id, $source)
    {
        try {
            $mediaTable = match($source) {
                'fobi' => 'fobi_checklist_media',
                'burungnesia' => 'fobi_checklist_fauna_imgs',
                'kupunesia' => 'fobi_checklist_fauna_imgs_kupnes', // Sesuaikan jika berbeda
            };

            $audioTable = match($source) {
                'fobi' => 'fobi_checklist_media',
                'burungnesia' => 'fobi_checklist_sounds',
                'kupunesia' => 'fobi_checklist_sounds', // Sesuaikan jika berbeda
            };

            // Get images
            $images = DB::table($mediaTable)
                ->where('checklist_id', $id)
                ->select('id', 'file_path as url', DB::raw("'image' as type"))
                ->get();

            // Get audio
            $audio = DB::table($audioTable)
                ->where('checklist_id', $id)
                ->select(
                    'id',
                    'file_path as url',
                    'spectrogram_path',
                    DB::raw("'audio' as type")
                )
                ->get();

            // Transform URLs
            $medias = $images->concat($audio)->map(function($media) {
                $media->url = asset('storage/' . $media->url);
                if (isset($media->spectrogram_path)) {
                    $media->spectrogram = asset('storage/' . $media->spectrogram_path);
                }
                return $media;
            });

            return $medias;

        } catch (\Exception $e) {
            Log::error('Error in getObservationMedia: ' . $e->getMessage());
            throw $e;
        }
    }

    public function searchTaxa(Request $request)
    {
        try {
            $request->validate([
                'q' => 'required|string|min:2'
            ]);

            $query = $request->input('q');
            $source = $request->input('source', 'fobi');

            // Base query
            $results = DB::table('taxas')
                ->where(function($q) use ($query) {
                    $q->where('scientific_name', 'like', "%{$query}%")
                      ->orWhere('cname_species', 'like', "%{$query}%");
                });

            // Filter berdasarkan sumber jika bukan fobi
            if ($source === 'burungnesia') {
                $results->whereNotNull('burnes_fauna_id')
                       ->leftJoin('faunas', 'taxas.burnes_fauna_id', '=', 'faunas.id')
                       ->select(
                           'taxas.id',
                           DB::raw('COALESCE(taxas.scientific_name, faunas.nameLat) as scientific_name'),
                           'taxas.cname_species',
                           'taxas.burnes_fauna_id',
                           'taxas.kupnes_fauna_id'
                       );
            } elseif ($source === 'kupunesia') {
                $results->whereNotNull('kupnes_fauna_id')
                       ->leftJoin('faunas_kupnes', 'taxas.kupnes_fauna_id', '=', 'faunas_kupnes.id')
                       ->select(
                           'taxas.id',
                           DB::raw('COALESCE(taxas.scientific_name, faunas_kupnes.nameLat) as scientific_name'),
                           'taxas.cname_species',
                           'taxas.burnes_fauna_id',
                           'taxas.kupnes_fauna_id'
                       );
            } else {
                $results->select(
                    'id',
                    'scientific_name',
                    'cname_species as common_name',
                    'burnes_fauna_id',
                    'kupnes_fauna_id'
                );
            }

            $results = $results->limit(10)->get();

            return response()->json([
                'success' => true,
                'data' => $results
            ]);

        } catch (\Exception $e) {
            Log::error('Error in searchTaxa: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mencari taxa: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getObservations(Request $request)
    {
        try {
            $request->validate([
                'source' => 'required|in:fobi,burungnesia,kupunesia',
                'per_page' => 'nullable|integer|min:1|max:100',
                'page' => 'nullable|integer|min:1',
                'sort' => 'nullable|in:latest,oldest',
                'taxon_id' => 'nullable|exists:taxas,id',
                'user_id' => 'nullable|exists:fobi_users,id'
            ]);

            $perPage = $request->input('per_page', 20);
            $source = $request->input('source');
            $sort = $request->input('sort', 'latest');

            $query = match($source) {
                'fobi' => DB::table('fobi_checklist_taxas as fct')
                    ->join('fobi_users as fu', 'fct.user_id', '=', 'fu.id')
                    ->join('taxas as t', 'fct.taxa_id', '=', 't.id')
                    ->join('taxa_quality_assessments as tqa', 'fct.id', '=', 'tqa.taxa_id')
                    ->select(
                        'fct.*',
                        'fu.uname as observer_name',
                        't.scientific_name',
                        'tqa.grade',
                        'tqa.identification_count'
                    ),

                'burungnesia' => DB::table('fobi_checklists as fc')
                    ->join('fobi_checklist_faunasv1 as fcf', 'fc.id', '=', 'fcf.checklist_id')
                    ->join('fobi_users as fu', 'fc.fobi_user_id', '=', 'fu.id')
                    ->join('data_quality_assessments as dqa', 'fc.id', '=', 'dqa.observation_id')
                    ->select(
                        'fc.*',
                        'fcf.fauna_id',
                        'fcf.count',
                        'fu.uname as observer_name',
                        'dqa.grade',
                        'dqa.identification_count'
                    ),

                'kupunesia' => DB::table('fobi_checklists_kupnes as fck')
                    ->join('fobi_checklist_faunasv2 as fcf', 'fck.id', '=', 'fcf.checklist_id')
                    ->join('fobi_users as fu', 'fck.fobi_user_id', '=', 'fu.id')
                    ->join('data_quality_assessments_kupnes as dqa', 'fck.id', '=', 'dqa.observation_id')
                    ->select(
                        'fck.*',
                        'fcf.fauna_id',
                        'fcf.count',
                        'fu.uname as observer_name',
                        'dqa.grade',
                        'dqa.identification_count'
                    )
            };

            // Apply filters
            if ($request->has('user_id')) {
                $query->where('fu.id', $request->user_id);
            }

            if ($request->has('taxon_id')) {
                $query->where('taxa_id', $request->taxon_id);
            }

            // Apply sorting
            $query->orderBy('created_at', $sort === 'latest' ? 'desc' : 'asc');

            // Get paginated results
            $observations = $query->paginate($perPage);

            // Add media to each observation
            foreach ($observations as $observation) {
                $observation->medias = $this->getObservationMedia($observation->id, $source);
            }

            return response()->json([
                'success' => true,
                'data' => $observations->items(),
                'meta' => [
                    'current_page' => $observations->currentPage(),
                    'per_page' => $observations->perPage(),
                    'total' => $observations->total(),
                    'last_page' => $observations->lastPage()
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getObservations: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil data observasi'
            ], 500);
        }
    }

    public function getObservationStatistics(Request $request)
    {
        try {
            $request->validate([
                'source' => 'required|in:fobi,burungnesia,kupunesia',
                'period' => 'nullable|in:daily,weekly,monthly,yearly',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'user_id' => 'nullable|exists:fobi_users,id'
            ]);

            $source = $request->input('source');
            $period = $request->input('period', 'monthly');
            $startDate = $request->input('start_date', now()->subMonth());
            $endDate = $request->input('end_date', now());
            $userId = $request->input('user_id');

            // Tentukan format date berdasarkan period
            $dateFormat = match($period) {
                'daily' => '%Y-%m-%d',
                'weekly' => '%Y-%u',
                'monthly' => '%Y-%m',
                'yearly' => '%Y'
            };

            // Base query berdasarkan sumber
            $query = match($source) {
                'fobi' => DB::table('fobi_checklist_taxas')
                    ->join('taxa_quality_assessments', 'fobi_checklist_taxas.id', '=', 'taxa_quality_assessments.taxa_id'),

                'burungnesia' => DB::table('fobi_checklists')
                    ->join('data_quality_assessments', 'fobi_checklists.id', '=', 'data_quality_assessments.observation_id'),

                'kupunesia' => DB::table('fobi_checklists_kupnes')
                    ->join('data_quality_assessments_kupnes', 'fobi_checklists_kupnes.id', '=', 'data_quality_assessments_kupnes.observation_id')
            };

            // Filter berdasarkan tanggal dan user
            $query->whereBetween('created_at', [$startDate, $endDate]);
            if ($userId) {
                $query->where($source === 'fobi' ? 'user_id' : 'fobi_user_id', $userId);
            }

            // Statistik dasar
            $basicStats = $query->select([
                DB::raw('COUNT(*) as total_observations'),
                DB::raw('COUNT(DISTINCT ' . ($source === 'fobi' ? 'user_id' : 'fobi_user_id') . ') as total_observers'),
                DB::raw("COUNT(CASE WHEN grade = 'research grade' THEN 1 END) as research_grade_count"),
                DB::raw("COUNT(CASE WHEN grade = 'needs ID' THEN 1 END) as needs_id_count"),
                DB::raw('AVG(identification_count) as avg_identifications')
            ])->first();

            // Trend observasi berdasarkan periode
            $trends = $query->select([
                DB::raw("DATE_FORMAT(created_at, '$dateFormat') as period"),
                DB::raw('COUNT(*) as count'),
                DB::raw("COUNT(CASE WHEN grade = 'research grade' THEN 1 END) as research_grade_count")
            ])
            ->groupBy('period')
            ->orderBy('period')
            ->get();

            // Top taxa/species
            $topTaxa = match($source) {
                'fobi' => DB::table('fobi_checklist_taxas')
                    ->join('taxas', 'fobi_checklist_taxas.taxa_id', '=', 'taxas.id')
                    ->select('taxas.scientific_name', DB::raw('COUNT(*) as count'))
                    ->groupBy('taxa_id', 'scientific_name')
                    ->orderByDesc('count')
                    ->limit(10)
                    ->get(),

                'burungnesia' => DB::table('fobi_checklists')
                    ->join('fobi_checklist_faunasv1', 'fobi_checklists.id', '=', 'fobi_checklist_faunasv1.checklist_id')
                    ->join('taxas', 'fobi_checklist_faunasv1.fauna_id', '=', 'taxas.burnes_fauna_id')
                    ->select('taxas.scientific_name', DB::raw('COUNT(*) as count'))
                    ->groupBy('fauna_id', 'scientific_name')
                    ->orderByDesc('count')
                    ->limit(10)
                    ->get(),

                'kupunesia' => DB::table('fobi_checklists_kupnes')
                    ->join('fobi_checklist_faunasv2', 'fobi_checklists_kupnes.id', '=', 'fobi_checklist_faunasv2.checklist_id')
                    ->join('taxas', 'fobi_checklist_faunasv2.fauna_id', '=', 'taxas.kupnes_fauna_id')
                    ->select('taxas.scientific_name', DB::raw('COUNT(*) as count'))
                    ->groupBy('fauna_id', 'scientific_name')
                    ->orderByDesc('count')
                    ->limit(10)
                    ->get()
            };

            return response()->json([
                'success' => true,
                'data' => [
                    'basic_stats' => $basicStats,
                    'trends' => $trends,
                    'top_taxa' => $topTaxa
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getObservationStatistics: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil statistik observasi'
            ], 500);
        }
    }

    public function getComments($id)
    {
        try {
            $source = $this->determineSource($id);
            
            // Buat query berdasarkan source dan ID
            $query = DB::table('observation_comments as c')
                ->join('fobi_users as u', 'c.user_id', '=', 'u.id')
                ->select(
                    'c.id',
                    'c.comment',
                    'c.created_at',
                    'c.updated_at',
                    'u.uname as user_name'
                );

            // Filter berdasarkan source
            if (str_starts_with($id, 'BN')) {
                $query->where('c.burnes_checklist_id', (int)substr($id, 2));
            } elseif (str_starts_with($id, 'KP')) {
                $query->where('c.kupnes_checklist_id', (int)substr($id, 2));
            } else {
                $query->where('c.observation_id', (int)$id);
            }

            $comments = $query->orderBy('c.created_at', 'desc')->get();

            return response()->json([
                'success' => true,
                'data' => $comments
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting comments: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil komentar'
            ], 500);
        }
    }

    // Method untuk menambah komentar
    public function addComment(Request $request, $id)
    {
        try {
            $request->validate([
                'comment' => 'required|string|max:1000'
            ]);

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            
            // Tentukan actual ID dan kolom yang sesuai
            $commentData = [
                'user_id' => $userId,
                'comment' => $request->comment,
                'source' => $source,
                'created_at' => now(),
                'updated_at' => now()
            ];

            // Set ID berdasarkan source
            if (str_starts_with($id, 'BN')) {
                $commentData['burnes_checklist_id'] = (int)substr($id, 2);
            } elseif (str_starts_with($id, 'KP')) {
                $commentData['kupnes_checklist_id'] = (int)substr($id, 2);
            } else {
                $commentData['observation_id'] = (int)$id;
            }

            // Insert komentar
            $commentId = DB::table('observation_comments')->insertGetId($commentData);

            // Ambil data komentar yang baru dibuat
            $comment = DB::table('observation_comments as c')
                ->join('fobi_users as u', 'c.user_id', '=', 'u.id')
                ->where('c.id', $commentId)
                ->select(
                    'c.id',
                    'c.comment',
                    'c.created_at',
                    'c.updated_at',
                    'u.uname as user_name'
                )
                ->first();

            return response()->json([
                'success' => true,
                'data' => $comment,
                'message' => 'Komentar berhasil ditambahkan'
            ]);

        } catch (\Exception $e) {
            Log::error('Error adding comment: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat menambahkan komentar'
            ], 500);
        }
    }

    private function getRelatedLocations($taxaId)
    {
        try {
            $source = $this->determineSource($taxaId);

            // Tentukan tabel yang akan digunakan berdasarkan sumber
            $checklistTable = $this->getChecklistTable($source);
            $assessmentTable = match($source) {
                'burungnesia' => 'burnes_quality_assessments',
                'kupunesia' => 'kupnes_quality_assessments',
                default => 'taxa_quality_assessments'
            };

            // Query untuk mendapatkan lokasi terkait
            $relatedLocations = DB::table("$checklistTable as c")
                ->leftJoin("$assessmentTable as qa", 'c.id', '=', 'qa.taxa_id')
                ->where('c.taxa_id', $taxaId)
                ->select(
                    'c.id',
                    'c.latitude',
                    'c.longitude',
                    'c.scientific_name',
                    'c.created_at',
                    DB::raw('COALESCE(qa.grade, "needs ID") as grade')
                )
                ->whereNotNull('c.latitude')
                ->whereNotNull('c.longitude')
                ->get();

            // Format response
            $formattedLocations = $relatedLocations->map(function($location) {
                return [
                    'id' => $location->id,
                    'latitude' => (float)$location->latitude,
                    'longitude' => (float)$location->longitude,
                    'scientific_name' => $location->scientific_name,
                    'created_at' => $location->created_at,
                    'grade' => $location->grade
                ];
            });

            return response()->json([
                'success' => true,
                'data' => $formattedLocations
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting related locations: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil lokasi terkait'
            ], 500);
        }
    }

    private function getChecklistConfig($source)
    {
        return match($source) {
            'burungnesia' => [
                'table' => 'fobi_checklists',
                'fauna_table' => 'fobi_checklist_faunasv1',
                'id_column' => 'id',
                'columns' => [
                    'fobi_checklists.id',
                    'fobi_checklist_faunasv1.fauna_id as taxa_id',
                    'fobi_checklists.latitude',
                    'fobi_checklists.longitude',
                    'fobi_checklists.location_details',
                    'fobi_checklists.observer',
                    'fobi_checklists.additional_note as notes',
                    'fobi_checklists.tgl_pengamatan as observation_date',
                    'fobi_checklists.created_at',
                    'fobi_checklists.updated_at'
                ]
            ],
            'kupunesia' => [
                'table' => 'fobi_checklists_kupnes',
                'fauna_table' => 'fobi_checklist_faunasv2',
                'id_column' => 'id',
                'columns' => [
                    'fobi_checklists_kupnes.id',
                    'fobi_checklist_faunasv2.fauna_id as taxa_id',
                    'fobi_checklists_kupnes.latitude',
                    'fobi_checklists_kupnes.longitude',
                    'fobi_checklists_kupnes.location_details',
                    'fobi_checklists_kupnes.observer',
                    'fobi_checklists_kupnes.additional_note as notes',
                    'fobi_checklists_kupnes.tgl_pengamatan as observation_date',
                    'fobi_checklists_kupnes.created_at',
                    'fobi_checklists_kupnes.updated_at'
                ]
            ],
            default => [
                'table' => 'fobi_checklist_taxas',
                'id_column' => 'id',
                'columns' => ['*']
            ]
        };
    }

    private function getMediaForChecklist($checklistId, $source)
    {
        $media = [];

        try {
            if ($source === 'burungnesia') {
                $images = DB::table('fobi_checklist_fauna_imgs')
                    ->where('checklist_id', $checklistId)
                    ->get();
                $sounds = DB::table('fobi_checklist_sounds')
                    ->where('checklist_id', $checklistId)
                    ->get();

                $media['images'] = $images;
                $media['sounds'] = $sounds;
            }
            elseif ($source === 'kupunesia') {
                $images = DB::table('fobi_checklist_fauna_imgs_kupnes')
                    ->where('checklist_id', $checklistId)
                    ->get();

                $media['images'] = $images;
            }
            else {
                $media['images'] = DB::table('fobi_checklist_media')
                    ->where('checklist_id', $checklistId)
                    ->get();
            }
        } catch (\Exception $e) {
            Log::error('Error getting media: ' . $e->getMessage(), [
                'checklist_id' => $checklistId,
                'source' => $source
            ]);
            // Return empty arrays if there's an error
            $media['images'] = [];
            if ($source === 'burungnesia') {
                $media['sounds'] = [];
            }
        }

        return $media;
    }

    private function getActualId($id)
    {
        if (is_string($id)) {
            if (str_starts_with($id, 'BN')) {
                return (int)substr($id, 2);
            } elseif (str_starts_with($id, 'KP')) {
                return (int)substr($id, 2);
            }
        }
        return (int)$id;
    }

    private function getTaxaInfo($taxaId, $source)
    {
        // Coba cari di tabel taxas dulu
        $taxaInfo = DB::table('taxas')
            ->where('id', $taxaId)
            ->first();

        // Jika tidak ditemukan, cek di tabel alternatif sesuai source
        if (!$taxaInfo) {
            $table = match($source) {
                'burungnesia' => 'faunas',
                'kupunesia' => 'faunas_kupnes',
                default => null
            };

            if ($table) {
                $taxaInfo = DB::table($table)
                    ->where('id', $taxaId)
                    ->first();
            }
        }

        return $taxaInfo;
    }

    public function cancelAgreement($id, $identificationId)
    {
        try {
            DB::beginTransaction();

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id);

            // Cek apakah identifikasi yang akan dibatalkan ada
            $identification = DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan');
            }

            // Cek dan hapus persetujuan berdasarkan agrees_with_id
            $agreementQuery = DB::table('taxa_identifications')
                ->where('user_id', $userId)
                ->where('agrees_with_id', $identificationId);

            // Sesuaikan query berdasarkan sumber
            if ($source === 'burungnesia') {
                $agreementQuery->where('burnes_checklist_id', $actualId);
            } elseif ($source === 'kupunesia') {
                $agreementQuery->where('kupnes_checklist_id', $actualId);
            } else {
                $agreementQuery->where('checklist_id', $actualId);
            }

            $deleted = $agreementQuery->delete();

            if (!$deleted) {
                throw new \Exception('Persetujuan tidak ditemukan');
            }

            // Hitung ulang jumlah persetujuan
            $agreementCount = DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->count();

            // Update quality assessment
            $this->qualityAssessmentController->updateQualityAssessment($actualId, $source);

            // Ambil data identifikasi yang diperbarui
            $updatedIdentification = DB::table('taxa_identifications as ti')
                ->join('fobi_users as fu', 'ti.user_id', '=', 'fu.id')
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->where('ti.id', $identificationId)
                ->select(
                    'ti.*',
                    'fu.uname as identifier_name',
                    't.scientific_name',
                    DB::raw("$agreementCount as agreement_count"),
                    DB::raw('false as user_agreed')
                )
                ->first();

            if (!$updatedIdentification) {
                throw new \Exception('Gagal mengambil data identifikasi yang diperbarui');
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Persetujuan berhasil dibatalkan',
                'data' => [
                    'identification' => $updatedIdentification,
                    'agreement_count' => $agreementCount,
                    'user_agreed' => false
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in cancelAgreement: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function disagreeWithIdentification(Request $request, $id, $identificationId)
    {
        try {
            DB::beginTransaction();

            $userId = JWTAuth::user()->id;
            $source = $this->determineSource($id);
            $actualId = $this->getActualId($id);

            // Validasi request
            $request->validate([
                'taxon_id' => 'required|exists:taxas,id',
                'comment' => 'required|string|max:500',
                'identification_level' => 'required|string'
            ]);

            // Cek identifikasi yang akan ditolak
            $identification = DB::table('taxa_identifications')
                ->where('id', $identificationId)
                ->first();

            if (!$identification) {
                throw new \Exception('Identifikasi tidak ditemukan');
            }

            // Ambil data taxa
            $taxon = DB::table('taxas')
                ->where('id', $request->taxon_id)
                ->select('taxon_rank', 'burnes_fauna_id', 'kupnes_fauna_id')
                ->first();

            if (!$taxon) {
                throw new \Exception('Taxa tidak valid');
            }

            // Siapkan data disagreement
            $disagreementData = [
                'user_id' => $userId,
                'taxon_id' => $request->taxon_id,
                'comment' => $request->comment,
                'identification_level' => $request->identification_level,
                'disagrees_with_id' => $identificationId,
                'created_at' => now(),
                'updated_at' => now(),
                'checklist_id' => null,
                'burnes_checklist_id' => null,
                'kupnes_checklist_id' => null,
                'burnes_fauna_id' => $taxon->burnes_fauna_id,
                'kupnes_fauna_id' => $taxon->kupnes_fauna_id
            ];

            // Set ID yang sesuai berdasarkan source
            if ($source === 'burungnesia') {
                $disagreementData['burnes_checklist_id'] = $actualId;
            } elseif ($source === 'kupunesia') {
                $disagreementData['kupnes_checklist_id'] = $actualId;
            } else {
                $disagreementData['checklist_id'] = $actualId;
            }

            // Simpan disagreement
            DB::table('taxa_identifications')->insert($disagreementData);

            // Hitung jumlah persetujuan untuk identifikasi yang ditolak
            $agreementCount = DB::table('taxa_identifications')
                ->where('agrees_with_id', $identificationId)
                ->count();

            // Update quality assessment
            $this->qualityAssessmentController->updateQualityAssessment($actualId, $source);

            DB::commit();

            // Ambil data identifikasi yang diperbarui
            $updatedIdentification = DB::table('taxa_identifications as ti')
                ->join('fobi_users as fu', 'ti.user_id', '=', 'fu.id')
                ->join('taxas as t', 'ti.taxon_id', '=', 't.id')
                ->where('ti.id', $identificationId)
                ->select(
                    'ti.*',
                    'fu.uname as identifier_name',
                    't.scientific_name',
                    DB::raw("$agreementCount as agreement_count"),
                    DB::raw('false as user_agreed')
                )
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Penolakan identifikasi berhasil disimpan',
                'data' => $updatedIdentification
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in disagreeWithIdentification: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    private function getIdentificationsWithPhotos($id, $source = null)
    {
        if (!$source) {
            $source = $this->determineSource($id);
        }
        $actualId = $this->getActualId($id);
        $userId = optional(JWTAuth::user())->id;

        $query = DB::table('taxa_identifications as i')
            ->join('fobi_users as u', 'i.user_id', '=', 'u.id')
            ->leftJoin('taxas as t', 'i.taxon_id', '=', 't.id')
            ->select(
                'i.*',
                'u.uname as identifier_name',
                't.scientific_name',
                DB::raw("CASE 
                    WHEN i.photo_path IS NOT NULL THEN CONCAT('" . config('app.url') . "/storage/', i.photo_path)
                    ELSE NULL 
                END as photo_url")
            );

        // Sesuaikan where clause berdasarkan sumber
        if ($source === 'burungnesia') {
            $query->where('i.burnes_checklist_id', $actualId);
        } elseif ($source === 'kupunesia') {
            $query->where('i.kupnes_checklist_id', $actualId);
        } else {
            $query->where('i.checklist_id', $actualId);
        }

        // Tambahkan perhitungan agreement_count dan user_agreed
        $query->addSelect(DB::raw('(SELECT COUNT(*) FROM taxa_identifications WHERE agrees_with_id = i.id) as agreement_count'));
        $query->addSelect(DB::raw('EXISTS(SELECT 1 FROM taxa_identifications WHERE agrees_with_id = i.id AND user_id = ?) as user_agreed'))
            ->addBinding($userId, 'select');

        return $query->orderBy('i.created_at', 'desc')->get();
    }

    public function getNeedsIdObservations(Request $request)
    {
        try {
            $perPage = $request->input('per_page', 20);
            $sort = $request->input('sort', 'latest');

            // Query untuk FOBI
            $fobiQuery = DB::table('fobi_checklist_taxas as fct')
                ->join('fobi_users as fu', 'fct.user_id', '=', 'fu.id')
                ->leftJoin('taxa_quality_assessments as tqa', function($join) {
                    $join->on('fct.id', '=', 'tqa.observation_id')
                         ->where('tqa.type', '=', 'fobi');
                })
                ->leftJoin('taxas as t', 'fct.taxa_id', '=', 't.id')
                ->where(function($query) {
                    $query->where('tqa.grade', 'needs id')
                          ->orWhere('tqa.grade', 'low quality id');
                })
                ->select([
                    'fct.id',
                    'fct.taxa_id as fauna_id',
                    'fu.uname as observer',
                    'tqa.grade',
                    'fct.created_at',
                    DB::raw("'fobi' as type"),
                    DB::raw("'fobi' as source"),
                    't.scientific_name as title',
                    't.description',
                    'tqa.identification_count as identifications_count',
                    DB::raw('(SELECT JSON_ARRAYAGG(fi.url) FROM fobi_images fi WHERE fi.taxa_id = fct.taxa_id) as images')
                ]);

            // Query untuk Burungnesia
            $burungnesiaQuery = DB::table('fobi_checklists as fc')
                ->join('fobi_checklist_faunasv1 as fcf', 'fc.id', '=', 'fcf.checklist_id')
                ->join('fobi_users as fu', 'fc.fobi_user_id', '=', 'fu.id')
                ->leftJoin('data_quality_assessments as dqa', 'fc.id', '=', 'dqa.observation_id')
                ->leftJoin('faunas as f', 'fcf.fauna_id', '=', 'f.id')
                ->where(function($query) {
                    $query->where('dqa.grade', 'needs id')
                          ->orWhere('dqa.grade', 'low quality id');
                })
                ->select([
                    DB::raw("CONCAT('BN', fc.id) as id"),
                    'fcf.fauna_id',
                    'fu.uname as observer',
                    'dqa.grade',
                    'fc.created_at',
                    DB::raw("'bird' as type"),
                    DB::raw("'burungnesia' as source"),
                    'f.nameLat as title',
                    'f.description',
                    'dqa.identification_count as identifications_count',
                    DB::raw('(SELECT JSON_ARRAYAGG(fci.url) FROM fobi_checklist_fauna_imgs fci WHERE fci.checklist_id = fc.id) as images')
                ]);

            // Query untuk Kupunesia
            $kupunesiaQuery = DB::table('fobi_checklists_kupnes as fck')
                ->join('fobi_checklist_faunasv2 as fcf', 'fck.id', '=', 'fcf.checklist_id')
                ->join('fobi_users as fu', 'fck.fobi_user_id', '=', 'fu.id')
                ->leftJoin('data_quality_assessments_kupnes as dqa', 'fck.id', '=', 'dqa.observation_id')
                ->leftJoin('faunas_kupnes as fk', 'fcf.fauna_id', '=', 'fk.id')
                ->where(function($query) {
                    $query->where('dqa.grade', 'needs id')
                          ->orWhere('dqa.grade', 'low quality id');
                })
                ->select([
                    DB::raw("CONCAT('KP', fck.id) as id"),
                    'fcf.fauna_id',
                    'fu.uname as observer',
                    'dqa.grade',
                    'fck.created_at',
                    DB::raw("'butterfly' as type"),
                    DB::raw("'kupunesia' as source"),
                    'fk.nameLat as title',
                    'fk.description',
                    'dqa.identification_count as identifications_count',
                    DB::raw('(SELECT JSON_ARRAYAGG(fci.url) FROM fobi_checklist_fauna_imgs_kupnes fci WHERE fci.checklist_id = fck.id) as images')
                ]);

            // Gabungkan semua query
            $query = $fobiQuery
                ->union($burungnesiaQuery)
                ->union($kupunesiaQuery);

            // Tambahkan sorting dan pagination
            $observations = DB::query()
                ->fromSub($query, 'combined_observations')
                ->orderBy('created_at', $sort === 'latest' ? 'desc' : 'asc')
                ->paginate($perPage);

            // Format data untuk response
            $formattedObservations = collect($observations->items())->map(function($item) {
                return [
                    'id' => $item->id,
                    'fauna_id' => $item->fauna_id,
                    'observer' => $item->observer,
                    'title' => $item->title ?? 'Tidak ada nama',
                    'description' => $item->description ?? '',
                    'type' => $item->type,
                    'source' => $item->source,
                    'created_at' => $item->created_at,
                    'images' => json_decode($item->images) ?? [],
                    'quality' => [
                        'grade' => strtolower($item->grade),
                        'has_media' => !empty(json_decode($item->images)),
                        'needs_id' => strtolower($item->grade) === 'needs id',
                        'is_wild' => true,
                        'location_accurate' => true
                    ],
                    'identifications_count' => $item->identifications_count ?? 0
                ];
            });

            return response()->json([
                'success' => true,
                'data' => $formattedObservations,
                'meta' => [
                    'current_page' => $observations->currentPage(),
                    'per_page' => $observations->perPage(),
                    'total' => $observations->total(),
                    'last_page' => $observations->lastPage(),
                    'has_more' => $observations->hasMorePages()
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error in getNeedsIdObservations: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat mengambil data observasi'
            ], 500);
        }
    }
}
