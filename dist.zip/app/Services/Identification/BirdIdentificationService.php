<?php

namespace App\Services\Identification;

use Illuminate\Support\Facades\DB;

class BirdIdentificationService implements IdentificationServiceInterface
{
    public function getObservation($id)
    {
        return DB::table('burnes_checklists')
            ->join('burnes.faunas', 'burnes_checklists.fauna_id', '=', 'burnes.faunas.id')
            ->where('burnes_checklists.id', $id)
            ->first();
    }

    public function addIdentification($checklistId, array $data)
    {
        return DB::table('bird_identifications')->insertGetId([
            'checklist_id' => $checklistId,
            'fauna_id' => $data['fauna_id'],
            'user_id' => auth()->id(),
            'comment' => $data['comment'] ?? null,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }

    // ... implementasi method lainnya ...
} 