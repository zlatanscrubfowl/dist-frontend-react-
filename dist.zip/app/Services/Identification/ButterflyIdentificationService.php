<?php

namespace App\Services\Identification;

use Illuminate\Support\Facades\DB;

class ButterflyIdentificationService implements IdentificationServiceInterface
{
    public function getObservation($id)
    {
        return DB::table('kupnes_checklists')
            ->join('kupnes.faunas', 'kupnes_checklists.fauna_id', '=', 'kupnes.faunas.id')
            ->where('kupnes_checklists.id', $id)
            ->first();
    }

    public function addIdentification($checklistId, array $data)
    {
        return DB::table('butterfly_identifications')->insertGetId([
            'checklist_id' => $checklistId,
            'fauna_id' => $data['fauna_id'],
            'user_id' => auth()->id(),
            'comment' => $data['comment'] ?? null,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }

    // ... implementasi method lainnya ...
} 